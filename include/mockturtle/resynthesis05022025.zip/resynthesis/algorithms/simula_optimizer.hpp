/* mockturtle: C++ logic network library
 * Copyright (C) 2018-2023  EPFL
 *
 * Permission is hereby granted, free of charge, to any person
 * obtaining a copy of this software and associated documentation
 * files (the "Software"), to deal in the Software without
 * restriction, including without limitation the rights to use,
 * copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following
 * conditions:
 *
 * The above copyright notice and this permission notice shall be
 * included in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
 * OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
 * HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
 * WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 */
 
/*!
  \file simula_optimizer.hpp
  \brief Inplace rewrite

  \author Andrea Costamagna
*/

#pragma once

#include "../boolean/dependency_cut.hpp"
#include "../boolean/spfd_manager.hpp"
#include "../../algorithms/cut_enumeration.hpp"
#include "../../algorithms/cut_enumeration/rewrite_cut.hpp"

#include <fmt/format.h>
#include <kitty/dynamic_truth_table.hpp>
#include <kitty/npn.hpp>
#include <kitty/operations.hpp>
#include <kitty/static_truth_table.hpp>

namespace mockturtle
{

/*! \brief Parameters for Rewrite.
 *
 * The data structure `rewrite_params` holds configurable parameters with
 * default arguments for `rewrite`.
 */
struct simula_optimizer_params
{
  simula_optimizer_params()
  {
    /* 0 < Cut limit < 16 */
    cut_enumeration_ps.cut_limit = 8;
    cut_enumeration_ps.minimize_truth_table = true;
  }

  /*! \brief Cut enumeration parameters. */
  cut_enumeration_params cut_enumeration_ps{};

  /*! \brief If true, candidates are only accepted if they do not increase logic depth. */
  bool preserve_depth{ false };

  /*! \brief Allow rewrite with multiple structures */
  bool allow_multiple_structures{ true };

  /*! \brief Allow zero-gain substitutions */
  bool allow_zero_gain{ false };

  /*! \brief Use satisfiability don't cares for optimization. */
  bool use_dont_cares{ false };

  /*! \brief Window size for don't cares calculation. */
  uint32_t window_size{ 8u };

  /*! \brief Be verbose. */
  bool verbose{ false };

  int effort{ 1 };
  bool greedy{ false };
  bool time{ false };
};

/*! \brief Statistics for rewrite.
 *
 * The data structure `rewrite_stats` provides data collected by running
 * `rewrite`.
 */
struct simula_optimizer_stats
{
  /*! \brief Total runtime. */
  stopwatch<>::duration time_total{ 0 };

  /*! \brief Expected gain. */
  uint32_t estimated_gain{ 0 };

  /*! \brief Candidates */
  uint32_t candidates{ 0 };

  void report() const
  {
    std::cout << fmt::format( "[i] total time       = {:>5.2f} secs\n", to_seconds( time_total ) );
  }
};

template<class Ntk, class Database_t, class Analyzer_t, uint32_t num_vars, uint32_t cube_size>
class simula_optimizer
{
  using node = typename Ntk::node;
  using signal = typename Ntk::signal;
  using cost = typename Analyzer_t::cost;
  static constexpr cost zero_cost = Analyzer_t::zero_cost;
  static constexpr uint32_t extra_space = 20;
  static constexpr uint32_t offset = 2;
  using cut_t = static_dependency_cut<Ntk, num_vars>;
  using network_cuts_t = std::vector<cut_t>;
  using truth_table_t = kitty::static_truth_table<num_vars>;
  using signature_t = kitty::static_truth_table<cube_size>;
  using word_t = kitty::static_truth_table<6u>;

public:
  simula_optimizer( std::shared_ptr<Ntk> pntk, std::shared_ptr<Database_t> pdatabase, std::shared_ptr<Analyzer_t> panalyzer, simula_optimizer_params const& ps, simula_optimizer_stats& st )
    : pntk( pntk ),
      pDatabase( pdatabase ),
      pAnalyzer( panalyzer ),
      ps( ps ),
      st( st ),
      cuts( extra_space ),
      spfd_manager(),
      best_reward( zero_cost ),
      node_to_sim( *pntk ),
      node_to_word( *pntk ),
      num_cex( 1 ),
      proj_functions(),
      best_leaves(),
      best_list( num_vars ),
      list_simulator_sign(),
      list_simulator_word()
  {
    add_event = pntk->events().register_add_event( [&]( const auto& n ) {
      signal f = pntk->make_signal( n );
      node_to_sim.resize();
      node_to_word.resize();
      simulate_rec( f, node_to_sim, list_simulator_sign );
    } );

    modified_event = pntk->events().register_modified_event( [&]( const auto& n, auto children ) {
      signal f = pntk->make_signal( n );
      node_to_sim.resize();
      node_to_word.resize();
      simulate_rec( f, node_to_sim, list_simulator_sign );
    } );
    init();
  }

  ~simula_optimizer()
  {
    pntk->events().release_add_event( add_event );
    pntk->events().release_modified_event( modified_event );
  }

  void init()
  {
    /* reserve and initialize the signatures for exhaustive window simulation */
    node_to_sim.resize();
    node_to_word.resize();
    node const n0 = pntk->get_node( pntk->get_constant( false ) );
    node const n1 = pntk->get_node( pntk->get_constant( true ) );
    signature_t sig0;
    word_t word0;
    node_to_sim[n0] = sig0;
    node_to_sim[n1] = ~sig0;
    node_to_word[n0] = word0;
    node_to_word[n1] = ~word0;
    
    std::default_random_engine::result_type seed = 42;

    pntk->foreach_pi( [&]( auto pi, auto ii ){
      kitty::create_random( node_to_sim[pi], seed++ );
      seed += ii;
      kitty::create_random( node_to_word[pi], seed++ );
      seed += ii;
    } );

    for( int i = 0; i < num_vars; ++i )
    {
      kitty::create_nth_var( proj_functions[i], i );
    }

    simulate_network( node_to_sim, list_simulator_sign );
  }

  template<class Tt_t>
  void simulate_network( incomplete_node_map<Tt_t, Ntk> & sims, aig_list_simulator<Tt_t> & simulator )
  {
    pntk->incr_trav_id();
    pntk->foreach_po( [&]( auto fo, auto io ){
      simulate_rec( fo, sims, simulator );
    } );  
  }

  template<class Tt_t>
  void simulate_rec( signal f, incomplete_node_map<Tt_t, Ntk> & sims, aig_list_simulator<Tt_t> & simulator )
  {
    node n = pntk->get_node( f );

    if( sims.has( n ) )
      return;

    if( pntk->is_pi( n ) || ( pntk->visited( n ) == pntk->trav_id() ) )
      return;

    std::vector<Tt_t*> sim_ptrs;
    pntk->foreach_fanin( n, [&]( auto fi, auto ii ){
      node ni = pntk->get_node( fi );
      simulate_rec( fi, sims, simulator );

      sim_ptrs.push_back( &sims[ni] );
    } );
    
    auto const alist = pntk->get_binding( n ).list;
    simulator( sims[n], alist, sim_ptrs );
    pntk->set_visited( n, pntk->trav_id() );
  }

  template<class WinManager_t>
  void analyze( node const& n, WinManager_t const& window_manager )
  {
    std::array<node, num_vars> times;
    std::array<node, num_vars> leaves;
    std::array<node, num_vars> perm_leaves;
    std::array<uint8_t, num_vars> permutation;

    best_reward = zero_cost;
    /* terminate if the window is not valid */
    if( !window_manager.is_valid() )
    {
      return;
    }
    if( window_manager.leaves.size() < 2 )
    {
      return;
    }

//    print_simulation( window_manager );

//    if( window_manager.mffc.size() == 1 )
//    {
//      return;
//    }
//    if( window_manager.leaves.size() == window_manager.divs.size() )
//    {
//      return;
//    }
    if( !compute_dependency_cuts( n, window_manager ) )
    {
      return;
    }

    for ( auto const& cut : cuts )
    {
      /* extract the cut leaves and functionality */
      auto const leaves = cut.get_leaves();

//for( auto l : leaves )
//  std::cout << l << " ";
//std::cout << std::endl;

      auto cost_curr = pAnalyzer->evaluate( n, window_manager.leaves );
      auto const& func = cut.get_function();
      auto const& care = cut.get_careset();
//kitty::print_binary( care );
//std::cout << std::endl;

      std::vector<uint64_t> dont_cares;
      for( int m = 0; m < func.num_bits(); ++m )
      {
        if( kitty::get_bit( care, m ) == 0 )
          dont_cares.push_back( m );
      }
      uint64_t const num_funcs = 1u << dont_cares.size();

      for( uint64_t m = 0; m < num_funcs; ++m )
      {
       // std::cout << m << "/" << num_funcs << std::endl;
        truth_table_t onset = func & care;
        truth_table_t tmp = onset | ~onset;

        for( int dc = 0; dc < dont_cares.size(); ++dc )
        {
          if( (( m >> dc ) & 0x1) == 0x1 )
            kitty::set_bit( onset, dont_cares[dc] );
          else
            kitty::clear_bit( onset, dont_cares[dc] );
        }

        auto ttnew = onset;
        int cnt = 0;
        for( int j{0}; j < num_vars; ++j )
        {
          if( !pntk->is_null( leaves[j] ) )
          {
            cnt++;
            auto tt_leaf = node_to_sim[leaves[j]];
            auto tt_root = node_to_sim[n];
            if( kitty::equal( tt_root, tt_leaf ) )
            {
              cost cost_cand = pAnalyzer->evaluate_rewiring( leaves[j], n );
              cost reward = pAnalyzer->compare( cost_curr, cost_cand );

              if( ( reward > best_reward ) )
              {
                mapped_list list( num_vars );
                list.create_po( list.pi_at( j ) );
                best_list = list;
                best_reward = reward;
                best_leaves = leaves;
              }
            }
          }
        }

        /* extract the database entries */
        auto res = pDatabase->get_entry( onset );
        if( res )
        {
          auto perm = std::get<0>( *res );
          auto entry = std::get<1>( *res );

          for ( auto j = 0u; j < num_vars; ++j )
          {
            permutation[perm[j]] = j;
          }

          for( int i = 0; i < num_vars; ++i )
          {
            auto const l = leaves[i];
            perm_leaves[permutation[i]] = l;
            times[permutation[i]] = !pntk->is_null( l ) ? pAnalyzer->get_time( l ) : std::numeric_limits<double>::max();
          }

          pDatabase->foreach_list( entry, [&]( auto list, auto index ){
            auto const symm = pDatabase->get_symm( entry );
            list.match_times( times, symm );

            cost cost_cand = pAnalyzer->evaluate( list, perm_leaves, n );
            cost reward = pAnalyzer->compare( cost_curr, cost_cand );
            if( ( reward > best_reward ) )
            {
              best_reward = reward;
              best_list = list;
              best_leaves = perm_leaves;
            }
          } );
          //std::cout << std::endl;
        }

        if( ps.effort == 0 )
        {
          m = num_funcs - 1;
        }
      }
    }
  }

  template<class WinManager_t>
  void print_simulation( WinManager_t const& window_manager )
  {
    std::cout << "leaves" << std::endl;
    window_manager.foreach_leaf( [&]( auto l, auto i ){
      std::cout << l << " ";
      kitty::print_binary( node_to_sim[l] );
      std::cout << std::endl;
    } );

    std::cout << "divs" << std::endl;
    window_manager.foreach_divisor( [&]( auto d, auto i ){
      std::cout << d << " ";
      kitty::print_binary( node_to_sim[d] );
      std::cout << std::endl;
    } );

    std::cout << "mffc" << std::endl;
    window_manager.foreach_mffc( [&]( auto m, auto i ){
      std::cout << m << " ";
      kitty::print_binary( node_to_sim[m] );
      std::cout << std::endl;
    } );
  }

  template<class WinManager_t>
  bool compute_dependency_cuts( node n, WinManager_t const& window_manager )
  {
    /* prepare the data */
    cuts.clear();
    /* call greedy support selection */
    /* call greedy support selection */
    if( ps.greedy == true )
      return greedy_support_selection( n, window_manager );
    else if( ps.time == true )
      return time_support_selection( n, window_manager );
    else
      return pivot_support_selection( n, window_manager );

  }

  template<class WinManager_t>
  bool pivot_support_selection( node const& n, WinManager_t const& window_manager )
  {
    bool found = false;
    window_manager.foreach_divisor( [&]( auto piv, auto i ){
      if( found )
        return true;

      /* initialize the spfd manager */
      signature_t const & sign = node_to_sim[n];
      spfd_manager.init( sign );
      
      signature_t const& sig = node_to_sim[piv];
      auto min_cost = spfd_manager.evaluate( sig );
      spfd_manager.update( sig );
      std::array<node, num_vars> leaves;
      leaves[0] = piv;
      int cnt = 1;

      /* prepare the data */
      node candidate = pntk->get_null();
      while( !spfd_manager.is_covered() && !spfd_manager.is_saturated() )
      {
        bool found_new = false;
        window_manager.foreach_divisor( [&]( auto d, auto i ){
          if( !ps.preserve_depth || ( pAnalyzer->get_time( d ) < pAnalyzer->get_time( n ) ) )
          {
            signature_t const& sig = node_to_sim[d];
            auto const cost_div = spfd_manager.evaluate( sig );
            if( cost_div < min_cost )
            {
              found_new = true;
              min_cost = cost_div;
              candidate = d;
            }
          }
        } );
        if( !found_new )
        {
          return true;
        }
        signature_t const& sig = node_to_sim[candidate];
        spfd_manager.update( sig );
        leaves[cnt++] = candidate;
      }
      if( spfd_manager.is_covered() )
      {
        while( cnt < num_vars )
          leaves[cnt++] = pntk->get_null();
  
        auto [func, care] = compute_function( n, leaves );
        cuts.emplace_back( n, leaves, func, care );
        found = true;
      }
      return true;
    } );

    return found;
  }

  template<class WinManager_t>
  bool time_support_selection( node const& n, WinManager_t const& window_manager )
  {
    /* initialize the spfd manager */
    signature_t const & sign = node_to_sim[n];
    spfd_manager.init( sign );
    /* prepare the data */
    std::array<node, num_vars> leaves;
    auto min_cost = spfd_manager.get_num_edges();
    node candidate = pntk->get_null();
    int cnt = 0;

    while( !spfd_manager.is_covered() && !spfd_manager.is_saturated() )
    {
      auto min_time = std::numeric_limits<double>::max();
      bool found_new = false;
      window_manager.foreach_divisor( [&]( auto d, auto i ){
        if( !ps.preserve_depth || ( pAnalyzer->get_time( d ) < pAnalyzer->get_time( n ) ) )
        {
          signature_t const& sig = node_to_sim[d];
          auto const cost_div = spfd_manager.evaluate( sig );
          if( ( cost_div < min_cost ) && ( pAnalyzer->get_time( d ) < min_time ) )
          {
            found_new = true;
            min_cost = cost_div;
            candidate = d;
            min_time = pAnalyzer->get_time( d );
          }
        }
      } );
      if( !found_new )
      {
        return false;
      }
      signature_t const& sig = node_to_sim[candidate];
      spfd_manager.update( sig );
      leaves[cnt++] = candidate;
    }
    if( spfd_manager.is_covered() )
    {
      while( cnt < num_vars )
      {
        leaves[cnt++] = pntk->get_null();
      }
      auto [func, care] = compute_function( n, leaves );
      cuts.emplace_back( n, leaves, func, care );
    }
    return true;
  }


  template<class WinManager_t>
  bool greedy_support_selection( node const& n, WinManager_t const& window_manager )
  {
    /* initialize the spfd manager */
    signature_t const & sign = node_to_sim[n];
    spfd_manager.init( sign );
    /* prepare the data */
    std::array<node, num_vars> leaves;
    auto min_cost = spfd_manager.get_num_edges();
    node candidate = pntk->get_null();
    int cnt = 0;
    while( !spfd_manager.is_covered() && !spfd_manager.is_saturated() )
    {
      bool found_new = false;
      window_manager.foreach_divisor( [&]( auto d, auto i ){
        if( !ps.preserve_depth || ( pAnalyzer->get_time( d ) < pAnalyzer->get_time( n ) ) )
        {
          signature_t const& sig = node_to_sim[d];
          auto const cost_div = spfd_manager.evaluate( sig );
          if( cost_div < min_cost )
          {
            found_new = true;
            min_cost = cost_div;
            candidate = d;
          }
        }
      } );
      if( !found_new )
      {
        return false;
      }
      signature_t const& sig = node_to_sim[candidate];
      spfd_manager.update( sig );
      leaves[cnt++] = candidate;
    }
    if( spfd_manager.is_covered() )
    {
      while( cnt < num_vars )
      {
        leaves[cnt++] = pntk->get_null();
      }
      auto [func, care] = compute_function( n, leaves );
      cuts.emplace_back( n, leaves, func, care );
    }
    return true;
  }



  std::tuple<truth_table_t, truth_table_t> compute_function( node const& n, std::array<node, num_vars> const& leaves )
  {
    signature_t const& root_signature = node_to_sim[n];
    uint32_t num_minterms = 1u << num_vars;
    truth_table_t func;
    truth_table_t care;
    truth_table_t temp;
    func ^= func;
    care ^= care;
    signature_t mask;
    for( uint32_t m = 0; m < num_minterms; ++m )
    {
      mask |= ~mask;
      temp |= ~temp;
      for( uint32_t v = 0; v < num_vars; ++v )
      {
        if( !pntk->is_null( leaves[v] ) )
        {
          signature_t const& sig = node_to_sim[leaves[v]];
          bool polarity = ( ( m >> v ) & 0x1 ) > 0;
          mask &= polarity ? sig : ~sig;
          temp &= polarity ? proj_functions[v] : ~proj_functions[v];
        }
      }
      if( kitty::count_ones( mask ) != 0 )
      {
        care |= temp;
      }
      if( kitty::count_ones( mask & root_signature ) > 0 )
      {
        func |= temp;
      }
    }
    return std::make_tuple( func, care );
  }

public:
  bool has_candidate()
  {
    return best_reward > zero_cost;
  }

  cost get_reward() const
  {
    return best_reward;
  }

  mapped_list get_list() const
  {
    return best_list;
  }

  std::array<node, num_vars> get_leaves() const
  {
    return best_leaves;
  }

  void add_pattern( std::vector<bool> const& cex )
  {
    uint32_t bit = num_cex - 1;
    pntk->foreach_pi( [&]( auto pi, auto ii ){
      if( cex[ii] )
        kitty::set_bit( node_to_word[pi], bit );
      else
        kitty::clear_bit( node_to_word[pi], bit );
    } );
    num_cex++;
    if( ( num_cex % 64u ) == 0 )
    {
      simulate_network( node_to_word, list_simulator_word );
    }
    uint32_t const num_blocks = 1u << ( cube_size - 6u );
    uint32_t block = ( num_cex / 64 ) % num_blocks;
  }

private:
  std::shared_ptr<Ntk> pntk;
  std::shared_ptr<Database_t> pDatabase;
  std::shared_ptr<Analyzer_t> pAnalyzer;
  simula_optimizer_params const& ps;
  simula_optimizer_stats & st;
  network_cuts_t cuts;
  spfd_manager_t<cube_size, num_vars> spfd_manager;

  incomplete_node_map<signature_t, Ntk> node_to_sim;
  incomplete_node_map<word_t, Ntk> node_to_word;

  aig_list_simulator<signature_t> list_simulator_sign;
  aig_list_simulator<word_t> list_simulator_word;

  uint32_t num_cex;

  std::array<truth_table_t, num_vars> proj_functions;
  std::array<node, num_vars> best_leaves;
  mapped_list best_list;
  cost best_reward;

  /* events */
  std::shared_ptr<typename network_events<Ntk>::add_event_type> add_event;
  std::shared_ptr<typename network_events<Ntk>::modified_event_type> modified_event;

};

} /* namespace mockturtle */