/* mockturtle: C++ logic network library
 * Copyright (C) 2018-2022  EPFL
 *
 * Permission is hereby granted, free of charge, to any person
 * obtaining a copy of this software and associated documentation
 * files (the "Software"), to deal in the Software without
 * restriction, including without limitation the rights to use,
 * copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following
 * conditions:
 *
 * The above copyright notice and this permission notice shall be
 * included in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
 * OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
 * HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
 * WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 */

/*!
  \file timing.hpp
  \brief Compute timing information of a network.

  This engine can be used for power analysis of mapped network.
  For each node, the following information is stored:
  - The sensing time : the first time at which a transition can happen
  - The arrival time : the first time at which the output is stable
  - A vector of simulation patterns identifying quantized timesteps in this interval
  The class has the following template parameters:
  \param N : number of timesteps used for simulating each signal
  \param I : number of inputs to be used for simulating the static truth table ( 2^I input pairs )

  \author Andrea Costamagna
*/

#pragma once

#include "../../utils/node_map.hpp"
#include "../database/mapped_list.hpp"
#include "placement_utils.hpp"
#include "particle.hpp"
#include "kernels.hpp"
#include <math.h>
#include <set>
#include <queue>
#include <array>

namespace mockturtle
{

struct placement_params 
{
  /*! \brief Precision */
  double eps { 0.01 };
  double area_density { 0.04 };
  double rest_length;
  int num_bins;
  int route_range;
  double unit_length;
  double min_position;
  double max_position;
  double slot_length;
  double amplitude_hard;
  double rescaling_route;
  double rescaling_diffn;
  double k_place{ 100 };
  double ratio_wire_route;
  double ratio_wire_diffn;
  int num_placers{3};
  bool anchor{true};
};

struct placement_stats 
{
  /*! \brief Precision */
  double eps { 0.001 };
  double unit_length;
  double slot_length;
  double area_density { 0.55 };
  double k_place;
  double k_global;
  int num_bins;
};

/* Whatever you do the placer should always be up-to-date*/
template<class Ntk, uint32_t Nx, uint32_t Ny>
class placement_storage_t
{
    static constexpr int slots_per_bin = 25;
public: 

  using node = typename Ntk::node;
  using signal = typename Ntk::signal;
  static constexpr uint32_t size_kernel = 7u;

  placement_storage_t( Ntk & ntk, placement_params ips, int seed )
    : ntk( ntk ),
      placement( ntk ),
      gen( seed ),
      seed( seed ),
      ps( ips )
  {
    auto const & lib = ntk.get_library();
    /* Find Dmax, the diameter needed to store the largest cell */
    ps.slot_length = 0;
    for ( auto g : lib )
    {
      if ( g.area > 0 )
      {
        ps.slot_length = std::max( 2*sqrt( g.area  / M_PI ), ps.slot_length );
      }
    }
    /* extract the side length of one bin */
    ps.unit_length = ps.slot_length * sqrt( slots_per_bin );
    /* extract the number of bins needed to store the cells satisfying the density constraint */
    ps.num_bins = int( std::max( 1.0, ceil( sqrt( ((double)ntk.area()) / ( ps.area_density * pow( ps.unit_length, 2) ) ) ) ));
    ps.num_bins = std::max( ps.num_bins, 2 );
    assert( ps.num_bins < Nx );
    
    /* Find the rest distance of the lattice */
    ps.rest_length = ps.num_bins * ps.unit_length / ( (double)ntk.size() - 1 );
    /* Number of bins over which the interaction is evaluated */
    ps.route_range = 1;
    ps.ratio_wire_route = 0;
    ps.ratio_wire_diffn = 0;
    ps.amplitude_hard = 1000;

    ps.min_position = 0;
    ps.max_position = ( ps.num_bins * ps.unit_length ) - ps.eps;

    kernel.set( ps.slot_length, ps.slot_length, ps.num_bins * ps.unit_length );

    _init();
  }

  placement_storage_t( placement_storage_t<Ntk, Nx, Ny> && other )
    : placement_storage_t( other.get_ntk(), other.get_params(), other.get_seed() )
  {}

  Ntk & get_ntk()
  {
    return ntk;
  }

  placement_params & get_params()
  {
    return ps;
  }

  int get_seed()
  {
    return seed;
  }

  int get_num_bins()
  {
    return ps.num_bins;
  }

  int get_slots_per_bin()
  {
    return slots_per_bin;
  }

  double get_unit_length()
  {
    return ps.unit_length;
  }

  void print_params()
  {
    std::cout << "=========================================" << std::endl;
    std::cout << "=========================================" << std::endl;
    printf( "eps                %5.3f \n", ps.eps );
    printf( "area_density       %5.3f\n",  ps.area_density );
    printf( "rest_length        %5.3f\n",  ps.rest_length );
    printf( "k_place           %5d\n",    ps.k_place );
    printf( "num_bins           %5d\n",    ps.num_bins );
    printf( "route_range        %5d\n",    ps.route_range );
    printf( "unit_length        %5.3f\n",  ps.unit_length );
    printf( "min_position       %5.3f\n",  ps.min_position );
    printf( "max_position       %5.3f\n",  ps.max_position );
    printf( "slot_length        %5.3f\n",  ps.slot_length );
    printf( "amplitude_hard     %5.3f\n",  ps.amplitude_hard );
    printf( "rescaling_route     %5.3f\n", ps.rescaling_route );
    printf( "rescaling_diffn     %5.3f\n", ps.rescaling_diffn );
    printf( "ratio_wire_route    %5.3f\n", ps.ratio_wire_route );
    printf( "ratio_wire_diffn    %5.3f\n", ps.ratio_wire_diffn );
    printf( "num_placers        %5d\n",    ps.num_placers );
    std::cout << "=========================================" << std::endl;
    std::cout << "=========================================" << std::endl;

  }

  void _init()
  {
    placement.resize();
    randomize_positions();
    add_event = ntk.events().register_add_event( [&]( const auto& n ) {
      placement.resize();
      std::vector<node> nodes;
      ntk.foreach_fanin( n, [&]( auto fv, auto iv ){
        node const nv = ntk.get_node( fv );
        nodes.emplace_back( nv );
      } );
      vector_t<double> q = get_baricenter( nodes );
      particle_t u( q );

      add_particle( n, u );
    } );

    modified_event = ntk.events().register_modified_event( [&]( const auto& n, auto old_children ) {
      placement.resize();
    } );

    delete_event = ntk.events().register_delete_event( [&]( const auto& n ) {
      placement.resize();
    } );
  }

  ~placement_storage_t()
  {
    if ( add_event )
    {
      ntk.events().release_add_event( add_event );
    }

    if ( modified_event )
    {
      ntk.events().release_modified_event( modified_event );
    }

    if ( delete_event )
    {
      ntk.events().release_delete_event( delete_event );
    }
  }

  vector_t<double> get_baricenter( std::vector<node> & nodes )
  {
    vector_t<double> q { 0, 0 };
    for ( node const & n : nodes )
    {
      particle_t & u = placement[n];
      vector_t<double> & qu = u.get_position();
      q = q + qu; 
    }
    q = q.times( 1.0/( ( double )nodes.size() ) );
    return q;
  }

  void compute_density_matrix()
  {
    reset_density_matrix();
    /* Remember to manually reset it */
    ntk.foreach_node( [&]( auto n ){
      add_density( placement[n] );
      return true;
    } );
  }

  void compute_forces_diffn()
  {
    compute_density_matrix();
    /* Remember to manually reset it */
    ntk.foreach_node( [&]( auto n ){
      add_gradient( placement[n] );
      return true;
    } );
  }


  double compute_hpwl()
  {
    double hpwl=0;
    ntk.foreach_gate( [&]( auto nu ){
      if ( ntk.is_dead( nu ) )
        return true;
      ntk.foreach_fanin( nu, [&]( auto fv, auto iv ){
        auto nv = ntk.get_node( fv );
        if ( !ntk.is_dead( nv ) )
        { 
          auto & u = placement[nu];
          auto & v = placement[nv];
          auto & qu = u.get_position();
          auto & qv = v.get_position();
          hpwl += std::max( qu[0], qv[0] )-std::min( qu[0], qv[0] );
          hpwl += std::max( qu[1], qv[1] )-std::min( qu[1], qv[1] );
        }
      } );
      return true;
    } );

    return hpwl;
  }

  void project_to_side( vector_t<double> & q )
  {
    vector_t<double> o { 0.5*ps.max_position, 0.5*ps.max_position };
    vector_t<double> d = q - o;
    double norm = d.norm2();
    q = d.times( 0.5*ps.max_position/norm );
    q = q + o;
  }

  void project_to_side( particle_t & u )
  {
    vector_t<double> & q = u.get_position();
    project_to_side( q );
  }

  void randomize_positions()
  {
    ntk.foreach_node( [&]( auto n ){
      vector_t<double> q = find_free_coords();
      particle_t u( q );
      if ( !is_inside(q) || ( ps.anchor ) && (ntk.is_pi( n ) || ntk.is_po( n )) )
        project_to_side( u );

      add_particle( n, u );
      return true;
    } );
  }

  vector_t<double> find_free_coords()
  {
    std::uniform_real_distribution<> distr( ps.min_position, ps.max_position );
    vector_t<double> q { 0, 0 };
    bool success = false;
    while ( !success )
    {
      q[0] = distr( gen );
      q[1] = distr( gen );
      if ( is_inside( q ) )
      {
        success = true;
      }
    }
    return q;
  }

  int count( int x, int y )
  {
    return grid[x][y].size();
  }

  bool is_inside( vector_t<double> & q )
  {
    //return ( q[0] >= 0.0 ) && ( q[1] >= 0.0 ) && ( q[0] <= (ps.max_position + ps.eps) ) && ( q[1] <= (ps.max_position + ps.eps) );
    vector_t<double> o { 0.5*ps.max_position, 0.5*ps.max_position };
    vector_t<double> dq = q - o;
    double dist = dq.norm2();
    return dist < 0.5*ps.max_position;
  }

  bool is_inside( particle_t & u )
  {
    vector_t<double> & q = u.get_position();
    return is_inside( q );
  }

  bin_t get_bin( particle_t & u )
  {
    vector_t<double> & q = u.get_position();
    return get_bin( q );
  }

  bin_t get_bin( vector_t<double> & q )
  {
    if ( !is_inside( q ) )
      project_to_side( q );
      
    int x = floor( q[0] / ps.unit_length );
    int y = floor( q[1] / ps.unit_length );
    return bin_t{ x, y };
  }

  void add_particle( node const& n, particle_t & u )
  {
    if ( !is_inside(u) || ( ps.anchor ) && (ntk.is_pi( n ) || ntk.is_po( n )) )
      project_to_side( u );
    placement.resize();
    u.set_range( ntk.get_range( n ) );
    placement[n] = u;
    bin_t B = get_bin( u );
    grid[B.x][B.y].insert( n );
  }

  void reset_density_matrix()
  {
    for ( int x = 0; x < ps.num_bins; ++x )
    {
      for ( int y = 0; y < ps.num_bins; ++y )
      {
        density_matrix[x][y] = 0;
      }   
    }
  }

  void reset_moments()
  {
    /* Remember to manually reset it */
    ntk.foreach_node( [&]( auto n ){
      placement[n].reset_moment();
      return true;
    } );
  }

  double compute_cost_place()
  {
    /* you should have computed the densities before */
    double cost = 0;
    ntk.foreach_gate( [&]( node nu ){
      particle_t & u = placement[nu];
      vector_t<double> & qu = u.get_position();
      ntk.foreach_fanin( nu, [&]( signal fv, uint32_t iv ){
        node nv = ntk.get_node( fv );
        particle_t & v = placement[nv];
        vector_t<double> & qv = v.get_position();
        vector_t<double> ruv = qu - qv;
        double Rd = ps.rest_length;//get_range( u, v );
        cost += 0.5 * ps.k_place * pow( ruv.norm2() - Rd, 2 );
      } );
    } );
    return cost;
  }

  bin_t get_bin( int x, int y, int diagonal )
  {
    x = std::max( 0, std::min( x + diagonal, ps.num_bins - 1 ));
    y = std::max( 0, std::min( y + diagonal, ps.num_bins - 1 ));
    return bin_t{ x, y };
  }

  bin_t get_bin( bin_t & B, int diagonal )
  {
    return get_bin( B.x, B.y, diagonal );
  }

  double compute_cost_legal( particle_t & u, particle_t & v )
  {
    vector_t<double> qu = u.get_position();
    vector_t<double> qv = v.get_position();
    double Qu = u.get_charge();
    double Qv = v.get_charge();
    vector_t<double> quv = qu - qv;
    double const ruv = quv.norm2();
    double const Ruv = sqrt(2)*get_range( u, v );
    double const Rd = ps.slot_length;


    double const El = ps.amplitude_hard * exp( -pow( ruv, 2 )/( 2 * pow( Rd, 2 ) ) ) / ( 2 * M_PI * pow( Rd, 2 ) );

    double const res = El;
    return res;
  }

  double compute_cost_route( particle_t & u, particle_t & v )
  {
    vector_t<double> qu = u.get_position();
    vector_t<double> qv = v.get_position();
    double Qu = u.get_charge();
    double Qv = v.get_charge();
    vector_t<double> quv = qu - qv;
    double const ruv = quv.norm2();
    double const Ruv = sqrt(2)*get_range( u, v );
    double const Ru = u.get_range() + ( Qu * 0.1 * ps.slot_length );
    double const Rv = v.get_range() + ( Qv * 0.1 * ps.slot_length );
    double const Rd = sqrt( pow( Ru, 2 ) + pow( Rv, 2 ) );

    double const Ec = exp( -pow( ruv, 2 )/( 2 * pow( Rd, 2 ) ) ) / ( 2 * M_PI * pow( Rd, 2 ) );

    double const res = Ec;
    return res;
  }

  double compute_cost_route( node const& n )
  {
    particle_t & u = placement[n];
    double res = 0;
    bin_t Bi = get_bin( u );
    bin_t Bl = get_bin( Bl, -ps.route_range );
    bin_t Br = get_bin( Br, +ps.route_range );
    for ( int x = Bl.x; x < Br.x; x++ )
    {
      for ( int y = Bl.y; y < Br.y; ++y )
      {
        auto nodes_v = grid[x][y];
        for ( auto nv : nodes_v )
        {
          particle_t & v = placement[nv];
          res += 0.5*compute_cost_route( u, v );
        }
      }
    }
    return res;
  }

  double compute_cost_legal( node const& n )
  {
    particle_t & u = placement[n];
    double res = 0;
    bin_t Bi = get_bin( u );
    bin_t Bl = get_bin( Bl, -ps.route_range );
    bin_t Br = get_bin( Br, +ps.route_range );
    for ( int x = Bl.x; x < Br.x; x++ )
    {
      for ( int y = Bl.y; y < Br.y; ++y )
      {
        auto nodes_v = grid[x][y];
        for ( auto nv : nodes_v )
        {
          particle_t & v = placement[nv];
          res += 0.5*compute_cost_legal( u, v );
        }
      }
    }
    return res;
  }


  double compute_cost_route( bin_t & Bi, bin_t & Bl, bin_t & Br )
  {
    double cost = 0;
    auto nodes_u = grid[Bi.x][Bi.y];
    for ( int x = Bl.x; x < Br.x; x++ )
    {
      for ( int y = Bl.y; y < Br.y; ++y )
      {
        auto nodes_v = grid[x][y];
        for ( auto nu : nodes_u )
        {
          for ( auto nv : nodes_v )
          {
            if ( ( nu > nv ) )
              continue;
            cost += compute_cost_route( placement[nu], placement[nv] );
          }
        }
      }
    }
    return cost;
  }

  double compute_cost_legal( bin_t & Bi, bin_t & Bl, bin_t & Br )
  {
    double cost = 0;
    auto nodes_u = grid[Bi.x][Bi.y];
    for ( int x = Bl.x; x < Br.x; x++ )
    {
      for ( int y = Bl.y; y < Br.y; ++y )
      {
        auto nodes_v = grid[x][y];
        for ( auto nu : nodes_u )
        {
          for ( auto nv : nodes_v )
          {
            if ( ( nu > nv ) )
              continue;
            cost += compute_cost_legal( placement[nu], placement[nv] );
          }
        }
      }
    }
    return cost;
  }

  void update_charges()
  {
    ntk.foreach_node( [&]( auto n ){
      placement[n].set_charge( ntk.get_degree( n ) );
      return true;
    } );
  }

  double compute_cost_route()
  {
    /* you should have computed the densities before */
    double cost = 0;
    for ( int x = 0; x < ps.num_bins; ++x )
    {
      for ( int y = 0; y < ps.num_bins; ++y )
      {
        auto Bi = get_bin( x, y, +0 );
        auto Bl = get_bin( x, y, -ps.route_range );
        auto Br = get_bin( x, y, ps.route_range );
        cost += compute_cost_route( Bi, Bl, Br );
      }
    }
    return cost;
  }

  double compute_cost_diffn()
  {
    compute_density_matrix();
    double Nt = ntk.area() / ( (double)pow( ps.num_bins, 2 ) );
    double res = 0;
    for ( int x = 0; x < ps.num_bins; ++x )
    {
      for ( int y = 0; y < ps.num_bins; ++y )
      {
        res += pow( density_matrix[x][y] - Nt, 2 );
      } 
    }
    return res;
  }

  double compute_cost_legal()
  {
    /* you should have computed the densities before */
    double cost = 0;
    for ( int x = 0; x < ps.num_bins; ++x )
    {
      for ( int y = 0; y < ps.num_bins; ++y )
      {
        auto Bi = get_bin( x, y, +0 );
        auto Bl = get_bin( x, y, -ps.route_range );
        auto Br = get_bin( x, y, ps.route_range );
        cost += compute_cost_legal( Bi, Bl, Br );
      }
    }
    return cost;
  }

  double compute_cost_place( particle_t & u, particle_t & v )
  {
    /* you should have computed the densities before */
    vector_t<double> & qu = u.get_position();
    vector_t<double> & qv = v.get_position();
    vector_t<double> ruv = qu - qv;
    double Rd = ps.rest_length;///sqrt(3);
    double const res = 0.5 * ps.k_place * pow( ruv.norm2() - Rd, 2 );
    return res;
  }

  double compute_cost_place( node n )
  {
    /* you should have computed the densities before */
    double cost = 0;
    particle_t & u = placement[n];
    vector_t<double> & qu = u.get_position();
    ntk.foreach_fanin( n, [&]( signal fv, uint32_t iv ){
      node nv = ntk.get_node( fv );
      particle_t & v = placement[nv];
      cost += 0.5*compute_cost_place( u, v );
    } );
    ntk.foreach_fanout( n, [&]( signal fv, uint32_t iv ){
      node nv = ntk.get_node( fv );
      particle_t & v = placement[nv];
      cost += 0.5*compute_cost_place( u, v );
     } );
    return cost;
  }

  double compute_cost()
  {
    update_charges();
    double const cost_legal = compute_cost_legal();
    double const cost_route = compute_cost_route();
    double const cost_place = compute_cost_place();
    //double const cost_diffn = compute_cost_diffn();
    ps.rescaling_route = ps.ratio_wire_route*(cost_place / cost_route);
    //ps.rescaling_diffn = ps.ratio_wire_diffn*(cost_place / cost_diffn);
    double cost_total = ps.rescaling_route*cost_route + cost_place;
    //std::cout << " Legal: " << cost_legal << 
    //             " Route: " << cost_route << 
    //             " Place: " << cost_place << std::endl;
    //             " Diffn: " << cost_diffn << std::endl;
    return cost_total;
  }

  vector_t<double> compute_force_place( particle_t & u, particle_t & v )
  {
    vector_t<double> & qu = u.get_position();
    vector_t<double> & qv = v.get_position();
    vector_t<double> ruv = qu - qv;
    double Rd = ps.rest_length;
    vector_t<double> dF = ruv.times( -ps.k_place * ( 1 - Rd/ruv.norm2() ) );
    return dF;
  }

  void compute_forces_place()
  {
    /* you should have computed the densities before */
    vector_t<double> dU { 0, 0 };
    ntk.foreach_gate( [&]( node nu ){
      particle_t & u = placement[nu];
      vector_t<double> & qu = u.get_position();
      vector_t<double> & Fu = u.get_force();
      ntk.foreach_fanin( nu, [&]( signal fv, uint32_t iv ){
        node nv = ntk.get_node( fv );
        particle_t & v = placement[nv];
        vector_t<double> & Fv = v.get_force();
        vector_t<double> dF = compute_force_place( u, v );
        Fu = Fu + dF;
        Fv = Fv - dF;
      } );
    } );
  }

  void reset_forces()
  {
    /* Remember to manually reset it */
    ntk.foreach_node( [&]( auto n ){
      placement[n].reset_force();
      return true;
    } );
  }

  double get_range( particle_t & u, particle_t & v )
  {
    double Ru = u.get_range();
    double Rv = v.get_range();
    double Ruv = sqrt( pow( Ru, 2 ) + pow( Rv, 2 ) );
    return Ruv;
  }

  vector_t<double> compute_force_legal( particle_t & u, particle_t & v )
  {
    double const Ruv = sqrt(2) * get_range( u, v );
    vector_t<double> & qu = u.get_position();
    vector_t<double> & qv = v.get_position();
    vector_t<double> quv = qu - qv;
    double ruv = quv.norm2();       
    double const Rd = ps.slot_length;
    double const Fl = ps.amplitude_hard * ( 2 * M_PI * pow( Rd, 4 ) ) *exp( -pow( ruv,2 )/( 2 * pow( Rd, 2 ) ) );
    vector_t<double> dF = quv.times( Fl );
    return dF;
  }

  void compute_force_legal( particle_t & u )
  {
    double & Qu = u.get_charge();
    vector_t<double> & qu = u.get_position();
    vector_t<double> & Fu = u.get_force();
    double const & Au = u.get_area();

    auto Bi = get_bin( u );
    auto Bl = get_bin( Bi, -ps.route_range );
    auto Br = get_bin( Bi, +ps.route_range );
    for ( double x = Bl.x; x < Br.x; x++ )
    {
      for ( double y = Bl.y; y < Br.y; y++ )
      {
        auto nodesv = grid[x][y];
        for ( auto nv : nodesv )
        {
          particle_t & v = placement[nv];
          if ( &u == &v )
            continue;
          vector_t<double> dF = compute_force_legal( u, v );
          Fu = Fu + dF;
        }
      }
    }
  }

  vector_t<double> compute_force_route( particle_t & u, particle_t & v )
  {
    double const Ruv = sqrt(2) * get_range( u, v );
    vector_t<double> & qu = u.get_position();
    vector_t<double> & qv = v.get_position();
    double & Qu = u.get_charge();
    double & Qv = v.get_charge();
    vector_t<double> quv = qu - qv;
    double ruv = quv.norm2();       
    double const Ru = u.get_range() + ( Qu * 0.1 * ps.slot_length );
    double const Rv = v.get_range() + ( Qv * 0.1 * ps.slot_length );
    double const Rd = sqrt( pow( Ru, 2 ) + pow( Rv, 2 ) );
    double const Fc = (ps.rescaling_route / ( 2 * M_PI * pow( Rd, 4 ) )) *exp( -pow( ruv,2 )/( 2 * pow( Rd, 2 ) ) );
    vector_t<double> dF = quv.times( Fc );
    return dF;
  }

  void compute_force_route( particle_t & u )
  {
    double & Qu = u.get_charge();
    vector_t<double> & qu = u.get_position();
    vector_t<double> & Fu = u.get_force();
    double const & Au = u.get_area();

    auto Bi = get_bin( u );
    auto Bl = get_bin( Bi, -ps.route_range );
    auto Br = get_bin( Bi, +ps.route_range );
    for ( double x = Bl.x; x < Br.x; x++ )
    {
      for ( double y = Bl.y; y < Br.y; y++ )
      {
        auto nodesv = grid[x][y];
        for ( auto nv : nodesv )
        {
          particle_t & v = placement[nv];
          if ( &u == &v )
            continue;
          vector_t<double> dF = compute_force_route( u, v );
          Fu = Fu + dF;
        }
      }
    }
  }

  void compute_forces_route()
  {
    /* Remember to manually reset it */
    ntk.foreach_node( [&]( auto n ){
      placement[n].set_charge( ntk.get_degree( n ) );
      compute_force_route( placement[n] );
      return true;
    } );
  }

  void compute_forces_legal()
  {
    /* Remember to manually reset it */
    ntk.foreach_node( [&]( auto n ){
      placement[n].set_charge( ntk.get_degree( n ) );
      compute_force_legal( placement[n] );
      return true;
    } );
  }

  void compute_forces()
  {
    reset_forces();
    update_charges();
    compute_forces_legal();
    compute_forces_place();
    compute_forces_route();
//    compute_forces_diffn();
  }

  void add_density( particle_t & u )
  {
    vector_t<double> q = u.get_position();
    vector_t<double> dmin = kernel.get_delta_min( q );
    vector_t<double> dmax = kernel.get_delta_max( q );
    
    double dx = dmin[0];
    while ( dx <= dmax[0] )
    {
      double dy = dmin[1];
      while ( dy <= dmax[1] )
      {
        vector_t<double> dq { dx, dy };
        vector_t<double> qnew = q + dq;
        if ( is_inside( qnew ) )
        {
          auto B = get_bin( qnew );
          double const & Au = u.get_area();
          double const K = kernel.kernel_field( qnew, q );
          density_matrix[B.x][B.y] += K * Au;
        }
        dy += ps.slot_length;
      }
      dx += ps.slot_length;
    }
  }

  void add_gradient( particle_t & u )
  {
    double Nt = ntk.area() / ( (double)pow( ps.num_bins, 2 ) );

    vector_t<double> q = u.get_position();
    vector_t<double> dmin = kernel.get_delta_min( q );
    vector_t<double> dmax = kernel.get_delta_max( q );
    for ( double dx = dmin[0]; dx <= dmax[0]; dx += ps.slot_length )
    {
      for ( double dy = dmin[1]; dy <= dmax[1]; dy += ps.slot_length )
      {
        vector_t<double> dq { dx, dy };
        vector_t<double> qnew = q + dq;
        if ( is_inside( qnew ) )
        {
          auto B = get_bin( qnew );
          double const & Au = u.get_area();
          vector_t<double> dU = kernel.kernel_grads( qnew, q );
          vector_t<double> dF = dU.times( -2*Au*ps.rescaling_diffn*( density_matrix[B.x][B.y] - Nt ) );
          auto & Fu = u.get_force();
          Fu = Fu + dF;
        }
      }
    }
  }


  void integrate_moments( double dt )
  {
    /* Remember to manually reset it */
    ntk.foreach_node( [&]( auto n ){
      vector_t<double> & p = placement[n].get_moment();
      vector_t<double> & F = placement[n].get_force();
      vector_t<double> dp = F.times( dt );
      p = p + dp;
      return true;
    } );
  }

  bool is_descending()
  {
    double prod = 0;
    ntk.foreach_node( [&]( auto n ){
      vector_t<double> & p = placement[n].get_moment();
      vector_t<double> & F = placement[n].get_force();
      prod += p.dot( F );
      return true;
    } );
    return prod > 0;
  }

  double compute_norm_moments()
  {
    double res2 = 0;
    ntk.foreach_node( [&]( auto n ){
      particle_t & u = placement[n];
      vector_t<double> p = u.get_moment();
      res2 += p.squared_norm2();
      return true;
    } );
    return sqrt( res2 );
  }

  double compute_norm_forces()
  {
    double res2 = 0;
    ntk.foreach_node( [&]( auto n ){
      particle_t & u = placement[n];
      vector_t<double> p = u.get_force();
      res2 += p.squared_norm2();
      return true;
    } );
    return sqrt( res2 );
  }

  void rescale_moments( double gamma )
  {
    double p_norm = compute_norm_moments();
    double F_norm = compute_norm_forces();
    ntk.foreach_node( [&]( auto n ){
      vector_t<double> & p = placement[n].get_moment();
      vector_t<double> & F = placement[n].get_force();
      vector_t<double> const dp1 = F.times( gamma*p_norm/F_norm );
      vector_t<double> const dp2 = p.times( 1 - gamma );
      p = dp1 + dp2;
      return true;
    } );
  }

  void integrate_positions( double dt )
  {
    /* Remember to manually reset it */
    ntk.foreach_node( [&]( auto n ){
      vector_t<double> & p = placement[n].get_moment();
      vector_t<double> & q = placement[n].get_position();
      q = q + ( p .times( dt ) );
      if ( !is_inside(q) || (ps.anchor && ( ntk.is_pi( n ) || ntk.is_po( n ) )) )
        project_to_side( placement[n] );
      return true;
    } );
  }

  void legalize_position( particle_t & u )
  {
    vector_t<double> & q = u.get_position();
    q[0] =std::max( 0.0, std::min( q[0], ps.num_bins * ps.unit_length ) );
    q[1] =std::max( 0.0, std::min( q[1], ps.num_bins * ps.unit_length ) );
  }

  void legalize_positions()
  {
    /* Remember to manually reset it */
    ntk.foreach_node( [&]( auto n ){
      legalize_position( placement[n] );
      return true;
    } );
  }

  vector_t<double> get_position( node n )
  {
    return placement[n].get_position();
  }
  
  void save_density_matrix( std::string file_path )
  {
    compute_density_matrix();
    std::ofstream p( file_path );

    for ( int x = 0; x < ps.num_bins; ++x )
    {
      for ( int y = 0; y < ps.num_bins; ++y )
      {
        p << density_matrix[x][y] << " ";
      }
      p << std::endl;
    }
    p.close();
  }

  #pragma region list

  vector_t<double> get_baricenter( std::vector<particle_t> & parts, std::vector<uint32_t> & lits )
  {
    vector_t<double> q { 0, 0 };
    for ( int lit : lits )
    {
      vector_t<double> & qu = parts[lit].get_position();
      q = q + qu; 
    }
    q.times( 1/( ( double )lits.size() ) );
    return q;
  }

  template<class Leaves_t>
  void init_place_list( std::vector<particle_t>& parts, mapped_list const& list, Leaves_t const& leaves, node const& n, std::set<node> const& erased )
  {
    parts.clear();
    parts.reserve( list.size() );
    // add constants
    parts.emplace_back();
    parts.emplace_back();
    // add the leaves with the correct charge

    for( int i = 0; i < list.num_pis(); ++i )
    {
      node l = leaves[i];
      if( !ntk.is_null( l ) )
      {
        assert( ( erased.find( l ) == erased.end() ) );
        particle_t u( placement[l] );
        auto Qu = ntk.get_degree( l );
        u.set_charge( Qu );
        ntk.foreach_fanout( l, [&]( auto fo, auto io ){
          auto no = ntk.get_node( fo );
          if ( !ntk.is_dead( no ) && !ntk.is_dead( l ) )
          {
            if ( erased.find( no ) != erased.end() )
              u.add_charge(-1);
          }
        } );
        if ( ps.anchor && ( ntk.is_pi( l ) || ntk.is_po( l ) ) )
          u.anchor();
        parts.emplace_back( u );
      }
    }

    while( parts.size() < ( list.num_pis() + 2 ) )
      parts.emplace_back();

    auto const& lib = ntk.get_bindings();
    uint32_t lit = list.num_pis() + 2;
    list.foreach_gate( [&]( auto children, auto id ) {
      double R = ntk.get_range_from_id( id );
      double Q = children.size();
      vector_t<double> q = get_baricenter( parts, children );
      vector_t<double> p { 0, 0 };
      vector_t<double> F { 0, 0 };
      parts.emplace_back( q, p, F, Q, R  );
      for ( auto c : children )
      {
        parts[c].add_charge( +1 );
      }
      lit++;
    } );
    parts[list.po_at(0)].add_charge( ntk.fanout_size( n ) );
    if ( ps.anchor && ( ntk.is_pi( n ) || ntk.is_po( n ) ) )
      parts[list.po_at(0)].anchor();

  }

  void erase_from_grid( node n )
  {
    particle_t & u = placement[n];
    bin_t B = get_bin( u );
    grid[B.x][B.y].erase( n );
  }

  void addback_to_grid( node n )
  {
    particle_t & u = placement[n];
    bin_t B = get_bin( u );
    grid[B.x][B.y].insert( n );
  }  

  void reset_moments( std::vector<particle_t> & parts )
  {
    for ( particle_t & u : parts )
      u.reset_moment();
  }

  template<class Leaves_t>
  double compute_costs( std::vector<particle_t> & parts, mapped_list const & list, Leaves_t const & leaves, node n )
  {
    double cost = 0;
    /* 1.   Interactions of the particles with the other particles in the list */
    /* 1.1. Route */
    for ( int lit_u = 2; lit_u < parts.size(); ++lit_u )
    {
      particle_t & u = parts[lit_u];
      if ( !u.is_valid() )
        continue;
      for ( int lit_v = lit_u + 1; lit_v < parts.size(); ++lit_v )
      {
        particle_t & v = parts[lit_v];
        if ( v.is_valid() )
        {
          cost += compute_cost_legal( u, v );
          cost += compute_cost_route( u, v );
        }
      }
    }
    /* 1.2. Place */
    uint32_t lit = list.num_pis() + 2;
    list.foreach_gate( [&]( auto children, auto id ){
      particle_t & u = parts[lit];
      if ( u.is_valid() )
      {
        for ( uint32_t lit_v : children )
        {
          particle_t & v = parts[lit_v];
          cost += compute_cost_place( u, v );
        }
      }
      lit += 1;
    } );

    /* 2.   Interactions of the particles with the external particles */
    /* 2.1. Placement with leaves' fanins */
    for ( int lit = 2; lit < ( 2 + list.num_pis() ); ++lit )
    {
      node l = leaves[lit];
      if ( l > ntk.size() )
        continue;
      particle_t & u = parts[lit];

      ntk.foreach_fanin( l, [&]( auto fi, auto ii ){
        node ni = ntk.get_node( fi );
        if ( !ntk.is_null( ni ) )
        {
          particle_t & v = placement[ni];
          cost += compute_cost_place( u, v );
        }
      } );
    }
    /* 2.1. Placement with root fanouts */
    particle_t & u = parts[list.po_at( 0 )];
    ntk.foreach_fanout( n, [&]( auto fo, auto io ){
      node no = ntk.get_node( fo );
      particle_t & v = placement[no];
      cost += compute_cost_place( u, v );
    } );
    /* 2.1. Routing with existing nodes */
    for ( int lit_u = 2; lit_u < parts.size(); ++lit_u )
    {
      particle_t & u = parts[lit_u];
      if ( !u.is_valid() )
        continue;
      bin_t Bi = get_bin( u );
      bin_t Bl = get_bin( Bi, -1 );
      bin_t Br = get_bin( Bi, +1 );
      for ( int x = Bl.x; x <= Br.x; ++x )
      {
        for ( int y = Bl.y; y <= Bl.y; ++y )
        {
          std::set<node> nodes_v = grid[x][y];
          for ( node nv : nodes_v )
          {
            particle_t & v = placement[nv];
            if ( v.is_valid() )
            {
              cost += compute_cost_legal( u, v );
              cost += compute_cost_route( u, v );
            }
          }
        }
      }
    }
    return cost;
  }

  template<class Leaves_t>
  void compute_forces( std::vector<particle_t> & parts, mapped_list const & list, Leaves_t const & leaves, node n )
  {
    double cost = 0;
    /* 1.   Interactions of the particles with the other particles in the list */
    /* 1.1. Route */
    for ( int lit_u = 2; lit_u < parts.size(); ++lit_u )
    {
      particle_t & u = parts[lit_u];
      vector_t<double> & Fu = u.get_force(); 
      if ( !u.is_valid() )
        continue;
      for ( int lit_v = lit_u + 1; lit_v < parts.size(); ++lit_v )
      {
        particle_t & v = parts[lit_v];
        if ( v.is_valid() )
        {
          vector_t<double> & Fv = v.get_force();
          vector_t<double> dF = compute_force_legal( u, v );
          Fu = Fu + dF;
          Fv = Fv - dF;
          dF = compute_force_route( u, v );
          Fu = Fu + dF;
          Fv = Fv - dF;
        }
      }
    }
    /* 1.2. Place */
    uint32_t lit = list.num_pis() + 2;
    list.foreach_gate( [&]( auto children, auto id ){
      particle_t & u = parts[lit];
      if ( u.is_valid() )
      {
        vector_t<double> & Fu = u.get_force();
        for ( uint32_t lit_v : children )
        {
          particle_t & v = parts[lit_v];
          vector_t<double> & Fv = v.get_force();
          vector_t<double> dF = compute_force_place( u, v );
          Fu = Fu + dF;
          Fv = Fv - dF;
        }
      }
      lit += 1;
    } );

    /* 2.   Interactions of the particles with the external particles */
    /* 2.1. Placement with leaves' fanins */
    for ( int lit = 2; lit < ( 2 + list.num_pis() ); ++lit )
    {
      node l = leaves[lit];
      if ( l > ntk.size() )
        continue;
      particle_t & u = parts[lit];
      vector_t<double> & Fu = u.get_force();
      ntk.foreach_fanin( l, [&]( auto fi, auto ii ){
        node ni = ntk.get_node( fi );
        particle_t & v = placement[ni];
        vector_t<double> dF = compute_force_place( u, v );
        Fu = Fu + dF;
      } );
    }
    /* 2.1. Placement with root fanouts */
    particle_t & u = parts[list.po_at( 0 )];
    vector_t<double> & Fu = u.get_force();
    ntk.foreach_fanout( n, [&]( auto fo, auto io ){
      node no = ntk.get_node( fo );
      particle_t & v = placement[no];
      vector_t<double> dF = compute_force_place( u, v );
      Fu = Fu + dF;
    } );
    /* 2.1. Routing with existing nodes */
    for ( int lit_u = 2; lit_u < parts.size(); ++lit_u )
    {
      particle_t & u = parts[lit_u];
      if ( !u.is_valid() )
        continue;
      bin_t Bi = get_bin( u );
      bin_t Bl = get_bin( Bi, -1 );
      bin_t Br = get_bin( Bi, +1 );
      for ( int x = Bl.x; x <= Br.x; ++x )
      {
        for ( int y = Bl.y; y <= Bl.y; ++y )
        {
          std::set<node> nodes_v = grid[x][y];
          for ( node nv : nodes_v )
          {
            particle_t & v = placement[nv];
            if ( v.is_valid() )
            {
              vector_t<double> dF = compute_force_legal( u, v );
              Fu = Fu + dF;
              dF = compute_force_route( u, v );
              Fu = Fu + dF;
            }
          }
        }
      }
    }
  }

  void integrate_moments( std::vector<particle_t> & parts, double dt )
  {
    for ( particle_t & u : parts )
    {
      if ( !u.is_valid() )
        continue;
      vector_t<double> & p = u.get_moment();
      vector_t<double> & F = u.get_force();
      vector_t<double> dp = F.times( dt );
      p = p + dp;
    }
  }

  bool is_descending( std::vector<particle_t> & parts )
  {
    double prod = 0;
    for ( particle_t & u : parts )
    {
      if ( !u.is_valid() )
        continue;
      vector_t<double> & p = u.get_moment();
      vector_t<double> & F = u.get_force();
      prod += p.dot( F );
    }
    return prod > 0;
  }

  double compute_norm_moments( std::vector<particle_t> & parts )
  {
    double res2 = 0;
    for ( particle_t & u : parts )
    {
      if ( !u.is_valid() )
        continue;
      vector_t<double> p = u.get_moment();
      res2 += p.squared_norm2();
    }
    return sqrt( res2 );
  }

  double compute_norm_forces( std::vector<particle_t> & parts )
  {
    double res2 = 0;
    for ( particle_t & u : parts )
    {
      vector_t<double> F = u.get_force();
      res2 += F.squared_norm2();
    }
    return sqrt( res2 );
  }

  void rescale_moments( std::vector<particle_t> & parts, double gamma )
  {
    double p_norm = compute_norm_moments( parts );
    double F_norm = compute_norm_forces( parts );
    for ( particle_t & u : parts )
    {
      vector_t<double> & p = u.get_moment();
      vector_t<double> & F = u.get_force();
      vector_t<double> const dp1 = F.times( gamma*p_norm/F_norm );
      vector_t<double> const dp2 = p.times( 1 - gamma );
      p = dp1 + dp2;
    }
  }

  void integrate_positions( std::vector<particle_t> & parts, double dt )
  {
    for ( particle_t & u : parts )
    {
      vector_t<double> & p = u.get_moment();
      vector_t<double> & q = u.get_position();
      q = q + ( p .times( dt ) );
      if ( ps.anchor && u.is_anchored() )
        project_to_side(u);
    }
  }

  #pragma endregion list

  double compute_cost( node n )
  {
    if ( ntk.is_dead( n ) )
      return 0;
    double cost_legal = compute_cost_legal( n );
    double cost_place = compute_cost_place( n );
    double cost_route = compute_cost_route( n );
    return cost_legal + cost_place + cost_route;
  }


private:
  Ntk & ntk;
  std::array<std::array<double, Ny>, Nx> density_matrix;
  std::array<std::array<std::set<node>, Ny>, Nx> grid;
    /*! \brief Hash table connecting each node to a placement element */
  incomplete_node_map<particle_t, Ntk> placement;
  gaussian_kernel_t<size_kernel> kernel;
  
  placement_params ps;
  std::mt19937 gen; // mersenne_twister_engine seeded with rd()
  int seed;

  /* events */
  std::shared_ptr<typename network_events<Ntk>::add_event_type> add_event;
  std::shared_ptr<typename network_events<Ntk>::modified_event_type> modified_event;
  std::shared_ptr<typename network_events<Ntk>::delete_event_type> delete_event;

};

} // namespace mockturtle
