/* mockturtle: C++ logic network library
 * Copyright (C) 2018-2022  EPFL
 *
 * Permission is hereby granted, free of charge, to any person
 * obtaining a copy of this software and associated documentation
 * files (the "Software"), to deal in the Software without
 * restriction, including without limitation the rights to use,
 * copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following
 * conditions:
 *
 * The above copyright notice and this permission notice shall be
 * included in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
 * OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
 * HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
 * WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 */

/*!
  \file timing.hpp
  \brief Compute timing information of a network.

  This engine can be used for power analysis of mapped network.
  For each node, the following information is stored:
  - The sensing time : the first time at which a transition can happen
  - The arrival time : the first time at which the output is stable
  - A vector of simulation patterns identifying quantized timesteps in this interval
  The class has the following template parameters:
  \param N : number of timesteps used for simulating each signal
  \param I : number of inputs to be used for simulating the static truth table ( 2^I input pairs )

  \author Andrea Costamagna
*/

#pragma once

#include "../../utils/node_map.hpp"
#include "../database/mapped_list.hpp"
#include <math.h>
#include <set>
#include <queue>
#include <array>
#include <SFML/Graphics.hpp>

namespace mockturtle
{


class particle_t
{
public:
  particle_t( std::array<double, 2> const& positions, std::array<double, 2> const& moments, double charge )
    : q( positions ), p( moments ), F( { 0, 0 } ), Q( charge )
    {}

  particle_t( particle_t const& other )
    : q( other.get_positions() ), p( other.get_moments() ), F( other.get_forces() ), Q( other.get_charge() )
  {}

  particle_t()
    : q( { 0, 0 } ), p( { 0, 0 } ), F( { 0, 0 } ), Q( 0 )
  {}

  void reset_force()
  {
    F = std::array<double, 2>{ 0, 0 };
  }

  void update_forces( std::array<double, 2> const& dF, double sign = 1 )
  {
    F[0] += sign * dF[0];
    F[1] += sign * dF[1];
  }

  void update_positions( std::array<double, 2> const& qnew )
  {
    q = qnew;
  }

  void update_charge( double Qnew )
  {
    Q = Qnew;
  }

  double get_position( int i ) const
  {
    return q[i];
  }

  /*! \brief Returns the position vector */
  std::array<double, 2> const& get_positions() const
  {
    return q;
  }

  /*! \brief Returns the moments vector */
  std::array<double, 2> const& get_moments() const
  {
    return p;
  }

  /*! \brief Returns the moments vector */
  std::array<double, 2> const& get_forces() const
  {
    return F;
  }

  /*! \brief Returns the moments vector */
  std::array<double, 2> & get_forces_m()
  {
    return F;
  }

  /*! \brief Returns the position vector */
  std::array<double, 2> & get_positions_m()
  {
    return q;
  }

  /*! \brief Returns the position vector */
  std::array<double, 2> & get_moments_m()
  {
    return p;
  }

  /*! \brief Returns the moments vector */
  std::array<double, 2> get_forces_c()
  {
    return F;
  }

  /*! \brief Returns the position vector */
  std::array<double, 2> get_positions_c()
  {
    return q;
  }

  /*! \brief Returns the position vector */
  std::array<double, 2> get_moments_c()
  {
    return p;
  }

  /*! \brief Returns the charge */
  double const& get_charge() const
  {
    return Q;
  }

private:
  /*! \brief position vector */
  std::array<double, 2> q;
  /*! \brief moments vector */
  std::array<double, 2> p;
  /*! \brief forces */
  std::array<double, 2> F;
  /*! \brief charge */
  double Q;

};

struct placement_stats 
{
};

struct placement_params 
{
  /*! \brief Maximum initial moments of the cells */
  double max_initial_moments { 0.5 };

  /*! \brief Stiffness/Repulsion ration */
  double stiffness { 1 };

  /*! \brief Stiffness/Repulsion ration */
  double dielectric { 0.01 };

  /*! \brief Stiffness/Repulsion ration */
  double eps { 0.01 };

  /*! \brief Constraint the PIs and POs to the boundaries */
  bool constraint_terminal{ true };

  double beta{ 100 };
  double sigma_velocity{ 0.5 };
  double sigma_position{ 0.5 };
  int num_steps_mc{ 100 }; 
  int num_steps_md{ 10 }; 
  double time_step{ 0.01 }; 
  bool verbose{ false };
  bool graphic{ true };

};

template<class Ntk, int Nx, int Ny>
class placement_analyzer
{
public:
  using node = typename Ntk::node;
  using signal = typename Ntk::signal;

  placement_analyzer( Ntk & ntk, placement_params ps = {} )
    : ntk( ntk ),
      placement( ntk ),
      gen( 336u ),
      ps( ps )
  {
    _init();


    std::uniform_real_distribution<> Upx( 0, ps.max_initial_moments );
    std::uniform_real_distribution<> Upy( -ps.max_initial_moments, ps.max_initial_moments );

    std::array<double, 2> q;
    std::array<double, 2> p;
    double Q;

    add_event = ntk.events().register_add_event( [&]( const auto& n ) {
      placement.resize();
      if ( coords.size() > 0 )
      {
        placement[n] = coords.front();
        coords.pop();
      }
      else
      {
        Q = ntk.get_area( n );
        q[0] = 0;
        q[1] = 0;
        double count = 0;
        ntk.foreach_fanin( n, [&]( auto fi, auto ii ){
          node ni = ntk.get_node( fi );
          auto const& qi = placement[ni].get_positions();
          q[0] += qi[0];
          q[1] += qi[1];
          count += 1;
        } );
        q[0] /= count;
        q[1] /= count;

        p = { Upx( gen ), Upy( gen ) };
        if ( ps.constraint_terminal && ( ntk.is_pi( n ) || ntk.is_po( n ) ) )
        {
          std::array<double, 4> dists { q[0], Nx - 1 - q[0], q[1], Ny - 1 - q[1] };
          std::array<int, 4> ids { 0, 1, 2, 3 };

          std::sort( ids.begin(), ids.end(), [&]( auto a, auto b ){
            return dists[a] < dists[b];
          } );
          if ( ids[0] == 0 )
            q[0] = 0;
          else if ( ids[0] == 1 )
            q[0] = Nx - 1;
          else if ( ids[0] == 2 )
            q[1] = 0;
          else if ( ids[0] == 3 )
            q[0] = Ny - 1;
          else
            std::cerr << "[e] wrong index in node addition" << std::endl;
        }
        placement[n] = particle_t( q, p, Q );
      }
    } );

    modified_event = ntk.events().register_modified_event( [&]( const auto& n, auto old_children ) {
      placement.resize();
      if ( coords.size() > 0 )
      {
        placement[n] = coords.front();
        coords.pop();
      }
      else
      {
        Q = ntk.get_area( n );
        q[0] = 0;
        q[1] = 0;
        double count = 0;
        ntk.foreach_fanin( n, [&]( auto fi, auto ii ){
          node ni = ntk.get_node( fi );
          auto const& qi = placement[ni].get_positions();
          q[0] += qi[0];
          q[1] += qi[1];
          count += 1;
        } );
        q[0] /= count;
        q[1] /= count;

        p = { Upx( gen ), Upy( gen ) };
        if ( ps.constraint_terminal && ( ntk.is_pi( n ) || ntk.is_po( n ) ) )
        {
          std::array<double, 4> dists { q[0], Nx - 1 - q[0], q[1], Ny - 1 - q[1] };
          std::array<int, 4> ids { 0, 1, 2, 3 };

          std::sort( ids.begin(), ids.end(), [&]( auto a, auto b ){
            return dists[a] < dists[b];
          } );
          if ( ids[0] == 0 )
            q[0] = 0;
          else if ( ids[0] == 1 )
            q[0] = Nx - 1;
          else if ( ids[0] == 2 )
            q[1] = 0;
          else if ( ids[0] == 3 )
            q[0] = Ny - 1;
          else
            std::cerr << "[e] wrong index in node addition" << std::endl;
        }
        placement[n] = particle_t( q, p, Q );
      }
      ( void )old_children;
    } );

  }

  ~placement_analyzer()
  {
    if ( add_event )
    {
      ntk.events().release_add_event( add_event );
    }

    if ( modified_event )
    {
      ntk.events().release_modified_event( modified_event );
    }
  }

  void project_position( std::array<double, 2> & q )
  {
    std::array<int, 4> id{ 0, 1, 2, 3 };
    std::array<double, 4> dq;
    dq[0] = std::abs( q[0] - 0 );
    dq[1] = std::abs( q[0] - Nx + 1 );
    dq[2] = std::abs( q[1] - 0 );
    dq[3] = std::abs( q[1] - Ny + 1 );

    std::sort( id.begin(), id.end(), [&]( auto a, auto b ){
      return dq[a] < dq[b];
    } );
    if ( id[0] == 0 )
      q[0] = 0;
    else if ( id[0] == 1 )
      q[0] = Nx - 1;
    else if ( id[0] == 2 )
      q[1] = 0;
    else if ( id[0] == 3 )
      q[1] = Ny - 1;
    else
      std::cerr << "[e] Invalid" << std::endl;
  }

  void project_moments( std::array<double, 2> const & q, std::array<double, 2> & p )
  {
      if ( q[0] == 0 )
        p[0] = +std::abs( p[0] );
      else if ( q[0] == ( Nx - 1 ) )
        p[0] = -std::abs( p[0] );
      if ( q[1] == 0 )
        p[1] = +std::abs( p[1] );
      else if ( q[1] == ( Ny - 1 ) )
        p[1] = -std::abs( p[1] );
  }

  void monte_carlo_sweep_placer( double beta = -1 )
  {
    if ( beta == -1 )
      beta = ps.beta;
    if ( ps.verbose )
    {
      fmt::print( "Performing Monte-Carlo Sweep with parameters : \n" );
      fmt::print( "  Number of steps     : {:5d}\n", ps.num_steps_mc );
      fmt::print( "  Inverse temperature : {:>5.2f}\n", beta );
      fmt::print( "  Step size           : {:>5.2f}\n", ps.sigma_position );
    }

    std::uniform_real_distribution<> R( 0, 1 );
    std::uniform_int_distribution<> U( 0, 1 );


    auto Ui = compute_potential_energy();
    for ( int istep = 0; istep < ps.num_steps_mc; ++istep )
    {
      ntk.foreach_node( [&]( auto n ){
        if ( ntk.is_dead( n ) )
          return true;
        auto q = placement[n].get_positions_c();
        auto qtry = q;
        while( qtry == q )
        {
          qtry[0] = std::max( std::min( (double)(Nx - 1), qtry[0] + ps.sigma_position*( 2*U( gen ) - 1 )), (double)0 );
          qtry[1] = std::max( std::min( (double)(Ny - 1), qtry[1] + ps.sigma_position*( 2*U( gen ) - 1 )), (double)0 );
          if (  ps.constraint_terminal && ( ntk.is_pi( n ) || ntk.is_po( n ) ) )
          {
            project_position( qtry );
          }
        }
        auto Uf = compute_potential_energy( Ui, n, qtry );

        double alpha = std::min( 1.0, exp( -beta*( Uf - Ui ) ) );
        if ( alpha > R( gen ) )
        {
          placement[n].update_positions( qtry ); 
          Ui = Uf;
        }
        return true;
      } );
    }
  }

void place_from_children( std::vector<particle_t>& parts, std::vector<uint32_t> const& children, uint32_t lit, node n )
{
  double count = children.size() + 1;
  auto q = placement[n].get_positions_c();
  for ( auto c : children )
  {
    q[0] = q[0] + parts[c].get_position( 0 ) / count;
    q[1] = q[1] + parts[c].get_position( 1 ) / count;
  }
  parts[lit].update_positions( q );
}

template<class Leaves_t>
void place_list( std::vector<particle_t>& parts, mapped_list const& list, Leaves_t const& leaves, node const& n )
{
  parts.reserve( list.size() );
  parts.emplace_back();
  parts.emplace_back();
  uint32_t lit = 1;
  for( int i = 0; i < list.num_pis(); ++i )
  {
    lit++;
    node l = leaves[i];
    if( !ntk.is_null( l ) )
    {
      parts.emplace_back( placement[l] );
    }
  }

  while( parts.size() < ( list.num_pis() + 2 ) )
  {
    parts.emplace_back();
  }
  auto const& lib = ntk.get_bindings();
  list.foreach_gate( [&]( auto children, auto id ) {
    lit++;
    particle_t vnew { std::array<double, 2>{ 0, 0 }, std::array<double, 2>{ 0, 0 }, lib[id].area };
    parts.push_back( vnew );
    place_from_children( parts, children, lit, n );
  } );
}

double compute_potential_energy( mapped_list const& list, std::vector<particle_t> const& parts, std::set<node> const& removed, node const& n )
{
  double U = 0;
  uint32_t lit = list.num_pis() + 2;
  list.foreach_gate( [&]( auto children, auto id ) {
    for ( auto c : children )
    {
      U += compute_elastic_energy( parts[lit].get_positions(), parts[c].get_positions() );
    }
    lit++;
  } );

  auto const& qi = parts[list.po_at(0)].get_positions();
  ntk.foreach_fanout( n, [&]( auto fo, auto io ){
    auto no = ntk.get_node( fo );
    auto const& qj = placement[no].get_positions();
    U += compute_elastic_energy( qi, qj );
  } );

  ntk.foreach_node( [&]( auto nj ){
    if ( ntk.is_dead( nj ) || ( ( removed.find( nj ) == removed.end() ) ) )
    {
      return true;
    }

    uint32_t lit = list.num_pis() + 2;
    list.foreach_gate( [&]( auto children, auto id ) {
      U += compute_electro_energy( parts[lit], placement[nj] );
      lit++;
    } );

    return true;
  } );

  for ( int i = list.num_pis() + 2; i < parts.size(); ++i )
  {
    for ( int j = i+1; j < parts.size(); ++j )
    {
        U += compute_electro_energy( parts[i], parts[j] );
    } 
  }
  return U;
}

template<class Leaves_t>
double monte_carlo_sweep_placer( mapped_list const& list, Leaves_t const& leaves, node const& n, std::set<node> const& removed, double beta = -1 )
{
  std::vector<particle_t> parts;
  place_list<Leaves_t>( parts, list, leaves, n );

  if ( beta == -1 )
    beta = ps.beta;
  if ( ps.verbose )
  {
    fmt::print( "Performing Monte-Carlo Sweep with parameters : \n" );
    fmt::print( "  Number of steps     : {:5d}\n", ps.num_steps_mc );
    fmt::print( "  Inverse temperature : {:>5.2f}\n", beta );
    fmt::print( "  Step size           : {:>5.2f}\n", ps.sigma_position );
  }

  std::uniform_real_distribution<> R( 0, 1 );
  std::uniform_int_distribution<> U( 0, 1 );

  auto Ui = compute_potential_energy( list, parts, removed, n );

  for ( int istep = 0; istep < ps.num_steps_mc; ++istep )
  {
    uint32_t lit = list.num_pis() + 2;
    list.foreach_gate( [&]( auto children, auto id ){
      auto q = parts[lit].get_positions_c();
      auto qtry = q;
      while( qtry == q )
      {
        qtry[0] = std::max( std::min( (double)(Nx - 1), qtry[0] + ps.sigma_position*( 2*U( gen ) - 1 )), (double)0 );
        qtry[1] = std::max( std::min( (double)(Ny - 1), qtry[1] + ps.sigma_position*( 2*U( gen ) - 1 )), (double)0 );
        if (  ps.constraint_terminal && ( ntk.is_po( n ) && ( list.po_at( 0 ) == lit ) ) )
        {
          project_position( qtry );
        }
      }
      auto Uf = compute_potential_energy( list, parts, removed, lit, qtry, n );

      double alpha = std::min( 1.0, exp( -beta*( Uf - Ui ) ) );
      if ( alpha > R( gen ) )
      {
        parts[lit].update_positions( qtry ); 
        Ui = Uf;
      }
      lit++;
    } );
  }
  return compute_potential_energy( list, parts, removed, n );

}

  void simulated_annealing_placer( double betai = 0.1, double betaf = 1000, int num_steps = 1000 )
  {
    for ( int i = 0; i < num_steps; ++i )
    {
      double beta = betai + ( betaf - betai )*i/( num_steps - 1 );
      monte_carlo_sweep_placer( beta );
      if ( ps.verbose )
        std::cout << i << " " << beta << " " << compute_potential_energy() << std::endl;
    }
  }

  /*! \brief NOT WORKING */
  void hybrid_monte_carlo_placer( )
  {
    if ( ps.verbose )
    {
      fmt::print( "Performing Hybrid Monte-Carlo with parameters : \n" );
      fmt::print( "  Number of steps MC  : {:5d}\n", ps.num_steps_mc );
      fmt::print( "  Number of steps MD  : {:5d}\n", ps.num_steps_md );
      fmt::print( "  Inverse temperature : {:>5.2f}\n", ps.beta );
      fmt::print( "  Step size           : {:>5.2f}\n", ps.sigma_position );
    }

    incomplete_node_map<particle_t, Ntk> old_placement( ntk );

    std::uniform_real_distribution<> R( 0, 1 );
    std::uniform_int_distribution<> U( 0, 1 );
    
    for ( int istep = 0; istep < ps.num_steps_mc; ++istep )
    {
      /* randomize the velocities */
      randomize_velocities();
      auto Hi = compute_potential_energy();
      /* save the previous state */
      ntk.foreach_node( [&]( auto n ){
        if ( ntk.is_dead( n ) )
          return true;
        old_placement[n] = placement[n];
        return true;
      } );

      for ( int jstep = 0; jstep < ps.num_steps_md; ++jstep )
      {
        compute_forces();
        ntk.foreach_node( [&]( auto n ){
          if ( ntk.is_dead( n ) )
            return true;
          auto & q = placement[n].get_positions_m();
          auto qold = q;
          auto & p = placement[n].get_moments_m();
          auto pold = p;
          auto const & F = placement[n].get_forces();

          for ( int i = 0; i < 2; ++i )
          {
            p[i] += 0.5*F[i]*ps.time_step;
            q[i] += p[i]*ps.time_step;
            p[i] += 0.5*F[i]*ps.time_step;
          }

          if ( ps.constraint_terminal && ( ntk.is_pi( n ) || ntk.is_po( n ) ) )
          {
            project_position( q );
          }
          project_moments( q, p );
          auto Hf = compute_potential_energy();
          std::cout << Hi << "->" << Hf << std::endl;
          double alpha = std::min( 1.0, exp( -ps.beta*( Hf - Hi ) ) );
          if ( alpha < R( gen ) )
          {
            p = pold;
            q = qold;
          }
          else
          {
            Hi = Hf;
            compute_forces();
          }
          return true;
        } );
      }
    }
  }

  void _init()
  {
    std::uniform_real_distribution<> R( 0, 1 );
    std::uniform_real_distribution<> Uqx( 0, Nx - 1 );
    std::uniform_real_distribution<> Uqy( 0, Ny - 1 );
    std::uniform_real_distribution<> Upx( 0, ps.max_initial_moments );
    std::uniform_real_distribution<> Upy( -ps.max_initial_moments, ps.max_initial_moments );

    std::array<double, 2> q;
    std::array<double, 2> p;
    double Q;

    ntk.foreach_node( [&]( auto n ){
      Q = ntk.get_area( n );
      q = { Uqx( gen ), Uqy( gen ) };
      p = { Upx( gen ), Upy( gen ) };
      if ( ps.constraint_terminal && ( ntk.is_pi( n ) || ntk.is_po( n ) ) )
      {
        double const r1 = R( gen );
        double const r2 = R( gen );
        if ( r1 > 0.5 )
        {
          q[0] = r2 > 0.5 ? Nx - 1 : 0;
          p[0] = 0;
        }
        else
        {
          q[1] = r2 > 0.5 ? Ny - 1 : 0;
          p[1] = 0;
        }
      }
      placement[n] = particle_t( q, p, Q );
    } );
  }

  void randomize_velocities()
  {
    std::uniform_real_distribution<> R( 0, 1 );

    ntk.foreach_node( [&]( auto n ){
      if ( ntk.is_dead( n ) )
        return true;

      auto & p = placement[n].get_moments_m();

      p[0] += ps.sigma_velocity*R( gen );
      p[1] += ps.sigma_velocity*R( gen );

      if ( ps.constraint_terminal && ( ntk.is_pi( n ) || ntk.is_po( n ) ) )
      {
        auto const & q = placement[n].get_positions();
        if ( ( q[0] == 0 ) || ( q[0] == ( Nx - 1 ) ) )
        {
          p[0] = 0;
        }
        else if ( ( q[1] == 0 ) || ( q[1] == ( Ny - 1 ) ) )
        {
          p[1] = 0;
        }
      }
      else
      {
        auto const & q = placement[n].get_positions();
        if ( ( q[0] == 0 )  )
          p[0] = std::abs( p[0] );
        if ( ( q[0] == ( Nx - 1 ) )  )
          p[0] = -std::abs( p[0] );
        if ( ( q[1] == 0 )  )
          p[1] = std::abs( p[1] );
        if ( ( q[1] == ( Ny - 1 ) )  )
          p[1] = -std::abs( p[1] );
      }

      return true;
    } );
  }

  double evaluate_removal( node const& n )
  {
    double const elastic = evaluate_removal_elastic( n );
    double const electro = evaluate_removal_electro( n );
    return elastic + electro;
  }

  double evaluate_replacement( node const& n, node const& ncurr )
  {
    double const elastic = evaluate_replacement_elastic( n, ncurr );
    double const electro = evaluate_replacement_electro( n, ncurr );
    return elastic + electro;
  }

  double compute_potential_energy()
  {
    double const elastic = compute_elastic_energy();
    double const electro = compute_electro_energy();
    return elastic + electro;
  }

  double compute_total_energy()
  {
    double const K = compute_kinetic_energy();
    double const U = compute_potential_energy();
    return K + U;
  }

  double compute_potential_energy( double Ui, node n, std::array<double, 2> const& qtry )
  {
    update_elastic_energy( Ui, n, qtry );
    update_electro_energy( Ui, n, qtry );
    return Ui;
  }


  double compute_potential_energy( mapped_list const& list, std::vector<particle_t> const& parts, std::set<node> const& removed, uint32_t const& lit_mod, std::array<double, 2> const& qtry, node const& n )
  {
    double U = 0;
    uint32_t lit = list.num_pis() + 2;
    list.foreach_gate( [&]( auto children, auto id ) {
      for ( auto c : children )
      {
        if ( c == lit_mod )
          U += compute_elastic_energy( parts[lit].get_positions(), qtry );
        else if ( lit == lit_mod )
          U += compute_elastic_energy( qtry, parts[c].get_positions() );
        else
          U += compute_elastic_energy( parts[lit].get_positions(), parts[c].get_positions() );
      }
      lit++;
    } );
  
    ntk.foreach_fanout( n, [&]( auto fo, auto io ){
      auto no = ntk.get_node( fo );
      if ( list.po_at(0) == lit_mod )
        U += compute_elastic_energy( qtry, placement[no].get_positions() );
      else
        U += compute_elastic_energy( parts[list.po_at(0)].get_positions(), placement[no].get_positions() );
    } );
  
    ntk.foreach_node( [&]( auto nj ){
      if ( ntk.is_dead( nj ) || ( removed.find( nj ) == removed.end() ) )
      {
        return true;
      }
  
      uint32_t lit = list.num_pis() + 2;
      list.foreach_gate( [&]( auto children, auto id ) {
        if ( lit == lit_mod )
          U += compute_electro_energy( parts[lit], placement[nj], qtry );
        else
          U += compute_electro_energy( parts[lit], placement[nj] );
        lit++;
      } );

      
      return true;
    } );

    for ( int i = list.num_pis() + 2; i < parts.size(); ++i )
    {
      for ( int j = i+1; j < parts.size(); ++j )
      {
        if ( i == lit_mod )
          U += compute_electro_energy( parts[i], parts[j], qtry );
        else if( j == lit_mod )
          U += compute_electro_energy( parts[j], parts[i], qtry );
        else
          U += compute_electro_energy( parts[i], parts[j] );
      }
    }
  }

  double squared_distance( particle_t const& i, particle_t const& j )
  {
    auto const& qi = i.get_positions();
    auto const& qj = j.get_positions();
    return squared_distance( qi, qj );
  }

  double squared_distance( std::array<double, 2> const& qi, std::array<double, 2> const& qj )
  {
    return pow( qi[0] - qj[0], 2 ) + pow( qi[1] - qj[1], 2 );
  }

  double distance( particle_t const& i, particle_t const& j )
  {
    return sqrt( squared_distance( i, j ) );
  }

  /*! \brief Computes the energy using Hooke's law on the connected nodes */
  double compute_kinetic_energy()
  {
    double energy = 0;
    ntk.foreach_gate( [&]( auto ni ){
      if ( ntk.is_dead( ni ) )
        return true;
      auto const & pi = placement[ni].get_moments();
      energy += ( pow( pi[0], 2 ) + pow( pi[1], 2 ) );
      return true;
    } );
    return energy * 0.5;
  }

  /*! \brief Computes the energy using Hooke's law on the connected nodes */
  double compute_elastic_energy()
  {
    double energy = 0;
    ntk.foreach_gate( [&]( auto ni ){
      if ( ntk.is_dead( ni ) )
        return true;
      auto const & vi = placement[ni];
      ntk.foreach_fanin( ni, [&]( auto fj ){
        node nj = ntk.get_node( fj );
        if ( !ntk.is_dead( nj ) )
        {
          auto const & vj = placement[nj];
          double const dist2 = squared_distance( vi, vj );
          energy += dist2;
        }
      } );
      return true;
    } );
    return energy * ps.stiffness * 0.5;
  }

  double compute_elastic_energy( std::array<double, 2> const& qi, std::array<double, 2> const& qj )
  {
    double const dist2 = squared_distance( qi, qj );
    return dist2 * ps.stiffness * 0.5 ;
  }

  double compute_electro_energy( particle_t const& vi, particle_t const& vj )
  {
    auto const & Qi = vi.get_charge();
    auto const & Qj = vj.get_charge();
    double const dist2 = squared_distance( vi, vj );
    return ps.dielectric * Qi*Qj/dist2;
  }

  double compute_electro_energy( particle_t const& vi, particle_t const& vj, std::array<double, 2> const& qitry )
  {
    auto const & Qi = vi.get_charge();
    auto const & Qj = vj.get_charge();
    double const dist2 = squared_distance( qitry, vj.get_positions() );
    return ps.dielectric * Qi*Qj/dist2;
  }

  /*! \brief Computes the repulsive energy coming from the electrostatic repulsion */
  double compute_electro_energy()
  {
    double energy = 0;
    ntk.foreach_node( [&]( auto ni ){
      if ( ntk.is_dead( ni ) )
        return true;
      auto const & vi = placement[ni];
      auto const & Qi = vi.get_charge();

      ntk.foreach_node( ni, [&]( auto nj ){
        if ( ntk.is_dead( nj ) || ( ni == nj ) )
          return true;

        auto const & vj = placement[nj];
        auto const & Qj = vj.get_charge();
        double const dist2 = squared_distance( vi, vj );

        energy += Qi*Qj/dist2;
        return true;
      } );
      return true;
    } );
    return ps.dielectric * energy;
  }


  /*! \brief Computes the energy using Hooke's law on the connected nodes */
  double evaluate_removal_elastic( node n )
  {
    double energy = 0;

    auto const & vi = placement[n];

    if ( !ntk.is_pi( n ) )
    {
      ntk.foreach_fanin( n, [&]( auto fj ){
        node nj = ntk.get_node( fj );
        if ( !ntk.is_dead( nj ) )
        {
          auto const & vj = placement[nj];
          double dist2 = squared_distance( vi, vj );
          energy += dist2;
        }
      } );
    }

    ntk.foreach_fanout( n, [&]( auto fj ){
      node nj = ntk.get_node( fj );
      if ( !ntk.is_dead( nj ) )
      {
        auto const & vj = placement[nj];
        double dist2 = squared_distance( vi, vj );
        energy += dist2;
      }
    } );

    return energy * ps.stiffness * 0.5;
  }

  /*! \brief Computes the repulsive energy coming from the electrostatic repulsion */
  double evaluate_removal_electro( node n )
  {
    double energy = 0;

    auto const & vi = placement[n];
    auto const & Qi = vi.get_charge();

    ntk.foreach_node( [&]( auto nj ){
      if ( ntk.is_dead( nj ) || ( nj == n ) )
        return true;

      auto const & vj = placement[nj];
      auto const & Qj = vj.get_charge();
      double dist2 = squared_distance( vi, vj );
      energy += Qi*Qj/dist2;
      return true;
    } );

    return ps.dielectric * energy;

  }

  /*! \brief Computes the energy using Hooke's law on the connected nodes */
  double evaluate_replacement_elastic( node n, node ncurr )
  {
    double energy = 0;

    auto const & vi = placement[n];

    if ( !ntk.is_pi( ncurr ) )
    {
      ntk.foreach_fanin( ncurr, [&]( auto fj ){
        node nj = ntk.get_node( fj );
        if ( !ntk.is_dead( nj ) )
        {
          auto const & vj = placement[nj];
          double dist2 = squared_distance( vi, vj );
          energy += dist2;
        }
      } );
    }

    ntk.foreach_fanout( ncurr, [&]( auto fj ){
      node nj = ntk.get_node( fj );
      if ( !ntk.is_dead( nj ) )
      {
        auto const & vj = placement[nj];
        double dist2 = squared_distance( vi, vj );
        energy += dist2;
      }
    } );

    return energy * ps.stiffness * 0.5;
  }

  /*! \brief Computes the repulsive energy coming from the electrostatic repulsion */
  double evaluate_replacement_electro( node n, node ncurr )
  {
    double energy = 0;

    auto const & vi = placement[n];
    auto const & Qi = vi.get_charge();

    ntk.foreach_node( [&]( auto nj ){
      if ( ntk.is_dead( nj ) || ( nj == ncurr ) )
        return true;

      auto const & vj = placement[nj];
      auto const & Qj = vj.get_charge();
      double dist2 = squared_distance( vi, vj );
      energy += Qi*Qj/dist2;
      return true;
    } );

    return ps.dielectric * energy;

  }


  /*! \brief Computes the energy using Hooke's law on the connected nodes */
  void update_elastic_energy( double & Ui, node n, std::array<double, 2> const& qtry )
  {
    double energy = 0;

    auto const & vi = placement[n];
    auto vitry = vi;
    vitry.update_positions( qtry );

    if ( !ntk.is_pi( n ) )
    {
      ntk.foreach_fanin( n, [&]( auto fj ){
        node nj = ntk.get_node( fj );
        if ( !ntk.is_dead( nj ) )
        {
          auto const & vj = placement[nj];
          double dist2 = squared_distance( vi, vj );
          energy -= dist2;
          dist2 = squared_distance( vitry, vj );
          energy += dist2;
        }
      } );
    }

    ntk.foreach_fanout( n, [&]( auto fj ){
      node nj = ntk.get_node( fj );
      if ( !ntk.is_dead( nj ) )
      {
        auto const & vj = placement[nj];
        double dist2 = squared_distance( vi, vj );
        energy -= dist2;
        dist2 = squared_distance( vitry, vj );
        energy += dist2;
      }
    } );

    Ui += energy * ps.stiffness * 0.5;
  }

  /*! \brief Computes the repulsive energy coming from the electrostatic repulsion */
  void update_electro_energy( double & Ui, node n, std::array<double, 2> const& qtry )
  {
    double energy = 0;

    auto const & vi = placement[n];
    auto vitry = vi;
    vitry.update_positions( qtry );
    auto const & Qi = vi.get_charge();

    ntk.foreach_node( [&]( auto nj ){
      if ( ntk.is_dead( nj ) || ( nj == n ) )
        return true;

      auto const & vj = placement[nj];
      auto const & Qj = vj.get_charge();
      double dist2 = squared_distance( vi, vj );
      energy -= Qi*Qj/dist2;
      dist2 = squared_distance( vitry, vj );
      energy += Qi*Qj/dist2;
      return true;
    } );

    Ui += ps.dielectric * energy;

  }

  /* force acting on particle i due to its interaction with j */
  std::array<double, 2> compute_electro_force( particle_t const& vi, particle_t const& vj )
  {
    auto const& qi = vi.get_positions();
    auto const& qj = vj.get_positions();
    double const dx = qi[0] - qj[0];
    double const dy = qi[1] - qj[1];

    double const Qi = vi.get_charge();
    double const Qj = vj.get_charge();
    double const dr = distance( vi, vj );
    double const electro_x = 2*ps.dielectric*dx*Qi*Qj/( pow( dr, 3 ) );
    double const electro_y = 2*ps.dielectric*dy*Qi*Qj/( pow( dr, 3 ) );
    return std::array<double, 2> { electro_x, electro_y };
  }

  /* force acting on particle i due to its interaction with j */
  std::array<double, 2> compute_elastic_force( particle_t const& vi, particle_t const& vj )
  {
    auto const & qi = vi.get_positions(); 
    auto const & qj = vj.get_positions(); 
    double const dx = qi[0] - qj[0];
    double const dy = qi[1] - qj[1];
    double const elastic_x = -ps.stiffness * dx;
    double const elastic_y = -ps.stiffness * dy;

    return std::array<double, 2> { elastic_x, elastic_y };
  }

  void compute_forces()
  {
    ntk.foreach_node( [&]( auto n ){
      placement[n].reset_force();
    } );

    ntk.foreach_node( [&]( auto ni ){
      if ( ntk.is_dead( ni ) )
        return true;

      auto & vi = placement[ni];
      auto const & qi = vi.get_positions();
      auto const & Qi = vi.get_charge();
      
      if ( !ntk.is_pi( ni ) )
      {
        ntk.foreach_fanin( ni, [&]( auto fj, auto ij ){
          node nj = ntk.get_node( fj );
          if ( !ntk.is_dead( nj ) )
          {
            auto & vj = placement[nj];
            /* force acting on particle i due to its interaction with j */
            auto Fij = compute_elastic_force( vi, vj );
            vi.update_forces( Fij, +1 );
            vj.update_forces( Fij, -1 );
          }
        } );
      }

      ntk.foreach_node( ni + 1, [&]( auto nj ){
        if ( ntk.is_dead( nj ) )
          return true;
        auto & vj = placement[nj];

        auto Fij = compute_electro_force( vi, vj );

        vi.update_forces( Fij, +1 );
        vj.update_forces( Fij, -1 );
        return true;
      } );
      return true;
    } );
  }

  void to_dot( std::string file_name )
  {
    std::ofstream p( file_name );
    p << "digraph {" << std::endl;
    p << "  graph [pad=\"0.0555\" bgcolor=lightgray]" << std::endl;
    p << "  node [style=filled]" << std::endl;
    int i = 0;
    ntk.foreach_pi( [&]( auto n ){
      auto field = placement[n];
      p << "  " << n << " [fillcolor=\"#d62728\" pos=\""<< field.get_position(0) << "," << field.get_position(1) << "!\"]" << std::endl;
    } );

    ntk.foreach_gate( [&]( auto n ){
      auto field = placement[n];
      if ( ntk.is_po( n ) )
      {
        p << "  " << n << " [fillcolor=\"#1f77b4\" pos=\""<< field.get_position(0) << "," << field.get_position(1) << "!\"]" << std::endl;
      }
      else
      {
        p << "  " << n << " [fillcolor=\"#ff7f0e\" pos=\""<< field.get_position(0) << "," << field.get_position(1) << "!\"]" << std::endl;
      }
    } );

    ntk.foreach_gate( [&]( auto n ){
      ntk.foreach_fanin( n, [&]( auto fi, auto ii ){
        auto ni = ntk.get_node( fi );
        p << "  " << ni << " -> " << n << std::endl;
      } );
    } );

    p << "}" << std::endl;
    p.close();
  }

  void print()
  {
    std::array<std::array<node, Ny>, Nx> matrix;
    for ( int x = 0; x < Nx; ++x )
    {
      for ( int y = 0; y < Ny; ++y )
      {
        matrix[x][y] = ntk.get_null();
      }
    }

    ntk.foreach_node( [&]( auto n ){
      auto const& q = placement[n].get_positions();
      int x = floor( q[0] );
      int y = floor( q[1] );
      std::cout << x << " " << y << std::endl;
      int t = 1;
      if ( ntk.is_null( matrix[x][y] ) )
      {
        matrix[x][y] = n;
      }
      else
      {
        bool found = false;
        while( !found )
        {
          if( !ntk.is_null( matrix[x][y] ) )
          {
            for ( int i = x - t; i <= x + t; ++i )
            {
              if ( (i < 0) || (i > (Nx - 1) ) || ( y > (Ny - 1) ) )
                continue;
              if ( ntk.is_null( matrix[i][y+t] ) )
              {
                x = i;
                y = y+t;
                matrix[x][y] = n;
                found = true;
                break;
              }
            }
          }
          if( !found )
          {
            for ( int i = x - t; i <= x + t; ++i )
            {
              if ( (i < 0) || (i > (Nx - 1)) || ( y < 0 ) )
                continue;
              if ( ntk.is_null( matrix[i][y-t] ) )
              {
                x = i;
                y = y-t;
                matrix[x][y] = n;
                found = true;
                break;
              }
            }
          }
          if( !found )
          {
            for ( int i = y - t; i <= y + t; ++i )
            {
              if ( (i < 0) || (i > Ny - 1) || ( x > (Nx - 1) ) )
                continue;
              if ( ntk.is_null( matrix[x+t][i] ) )
              {
                y = i;
                x = x+t;
                matrix[x][y] = n;
                found = true;
                break;
              }
            }
          }
          if( !found )
          {
            for ( int i = y - t; i <= y + t; ++i )
            {
              if ( (i < 0) || (i > Ny - 1) || ( x < 0 ) )
                continue;
              if ( ntk.is_null( matrix[x-t][i] ) )
              {
                y = i;
                x = x-t;
                matrix[x][y] = n;
                found = true;
                break;
              }
            }
          }
          t++;
        }
      }
    } );


    for ( int y = 0; y < Ny; ++y )
    {
      printf( "%d : ", y );
      for ( int x = 0; x < Nx; ++x )
      {
        node n = matrix[x][y];
        if ( ntk.is_null( n ) )
          printf( "      " );
        else
          printf( "%5d ", n );
      }
      printf("\n");
    }
  }


private:
  /*! \brief Pointer to the network to be placed */
  Ntk & ntk;

  /*! \brief Hash table connecting each node to a placement element */
  incomplete_node_map<particle_t, Ntk> placement;
  std::queue<particle_t> coords;

  std::mt19937 gen; // mersenne_twister_engine seeded with rd()
  double lambda;

  placement_stats st;
  placement_params ps;

  /* events */
  std::shared_ptr<typename network_events<Ntk>::add_event_type> add_event;
  std::shared_ptr<typename network_events<Ntk>::modified_event_type> modified_event;
};


} // namespace mockturtle