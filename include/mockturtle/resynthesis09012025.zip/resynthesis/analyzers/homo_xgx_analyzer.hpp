/* mockturtle: C++ logic network library
 * Copyright (C) 2018-2023  EPFL
 *
 * Permission is hereby granted, free of charge, to any person
 * obtaining a copy of this software and associated documentation
 * files (the "Software"), to deal in the Software without
 * restriction, including without limitation the rights to use,
 * copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following
 * conditions:
 *
 * The above copyright notice and this permission notice shall be
 * included in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
 * OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
 * HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
 * WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 */

/*!
  \file homo_xgx_analyzer.hpp
  \brief Inplace rewrite

  \author Andrea Costamagna
*/

#pragma once

#include "../database/mapped_list.hpp"

#include "../windowing/window_manager.hpp"
#include "../../algorithms/simulation.hpp"
#include "../list_simulator.hpp"
#include "../timing/sensing_analyzer.hpp"
#include "../timing/arrival_analyzer.hpp"
#include "../timing/switch_analyzer.hpp"
#include "../power/node_simulator.hpp"
#include "../power/analyzers/convo_analyzer.hpp"
#include "../../algorithms/detail/resub_utils.hpp"
#include "../../algorithms/reconv_cut.hpp"

#include <fmt/format.h>
#include <kitty/dynamic_truth_table.hpp>
#include <kitty/npn.hpp>
#include <kitty/operations.hpp>
#include <kitty/static_truth_table.hpp>

#include <set>

bool VERBOSEg = false;

namespace mockturtle
{

struct xgx_resyn_params
{
  bool only_critical = false;
  bool hot_wires = true;
  bool preserve_depth = true;
  bool preserve_window = false;
  bool preserve_flow = false;
  bool use_fanouts = true;
};


template<class Ntk, uint32_t num_vars, uint32_t num_steps, uint32_t cube_size, uint32_t max_leaves>
class homo_xgx_analyzer
{
public:
  using node = typename Ntk::node;
  using signal = typename Ntk::signal;
  using cost = double;
  static constexpr bool pass_manager = true;
  static constexpr cost zero_cost = 0.01;
  static constexpr cost min_cost = std::numeric_limits<cost>::min();
  static constexpr cost max_cost = std::numeric_limits<cost>::max();

  using truth_table_t = kitty::static_truth_table<cube_size>;
  using node_simulator_t = node_simulator<Ntk, num_steps, cube_size>;
  using list_simulator_t = aig_list_simulator<truth_table_t>;

public:
  homo_xgx_analyzer( Ntk& ntk )
    : pntk( std::make_shared<Ntk>( ntk ) ),
      lib( pntk->get_bindings() ),
      node_to_sim( *pntk ),
      sensing( ntk ),
      arrival( ntk ),
      switch_flow( ntk ),
      zero_delay( 0 ),
      dyn_switch( 0 )
  {
    size_t extra_space = 1000;
    nodes_sims.reserve( pntk->size() + extra_space );
    nodes.reserve( pntk->size() + extra_space );
    mlist_sims.reserve( 20 );
    init();
  }

  void update()
  {
  }

  void init()
  {
    std::vector<double> input_sensing( pntk->num_pis(), -1 );
    std::vector<double> input_arrival( pntk->num_pis(), 0 );
    sensing.compute_sensing_times( input_sensing );
    arrival.compute_arrival_times( input_arrival );
    double const delay = arrival.worst_delay();
    truth_table_t const0;
    /* initialize the constants */
    std::array<truth_table_t, 2> const pair0 = {  const0,  const0 };
    std::array<truth_table_t, 2> const pair1 = { ~const0, ~const0 };
    node const n0 = pntk->get_node( pntk->get_constant( false ) );
    node const n1 = pntk->get_node( pntk->get_constant( true ) );
    double const start = 0;
    node_simulator_t sim0( n0, pair0, start, start, delay );
    node_simulator_t sim1( n1, pair1, start, start, delay );
    nodes_sims.push_back( sim0 );
    nodes_sims.push_back( sim1 );
    mlist_sims.push_back( sim0 );
    mlist_sims.push_back( sim1 );

    node_to_sim[pntk->get_node( pntk->get_constant( false ) )] = 0;
    node_to_sim[pntk->get_node( pntk->get_constant( true ) )] = 1;

    pntk->set_visited( 0, pntk->trav_id() );
    pntk->set_visited( 1, pntk->trav_id() );

    std::array<kitty::static_truth_table<cube_size>, 2> workload;
    std::default_random_engine::result_type seed = 1;
    for( int i = 0; i < max_leaves; ++i )
    {
      kitty::create_random( workload[0], seed++ );
      kitty::create_random( workload[1], seed++ );
      node_simulator_t sim( 0, workload, -0.5, -1, 0 );
      nodes_sims.emplace_back( sim );
    }
    //power(1);
  }

  void reset()
  {
    /* clear information */
    nodes_sims.resize( max_leaves + 2 );
    mlist_sims.resize( 2 );
    node_to_sim.resize();
    node_to_sim[pntk->get_node( pntk->get_constant( false ) )] = 0;
    node_to_sim[pntk->get_node( pntk->get_constant( true ) )] = 1;
  }

  void operator()( node const& n, window_manager<Ntk, max_leaves> const& win_manager )
  {
    reset();
    dyn_switch = 0;
    zero_delay = 0;

    for( int i = 0; i < win_manager.leaves.size(); ++i )
    {
      node const l = win_manager.leaves[i];
//std::cout << l << std::endl;

      node_to_sim[l] = i + 2;
      if( pntk->is_pi( l ) )
      {
        nodes_sims[i+2].set_sensing( sensing.get_time( l )-1 );
        nodes_sims[i+2].set_arrival( arrival.get_time( l ) );
      }
      else
      if( pntk->is_pi( l ) )
      {
        nodes_sims[i+2].set_sensing( sensing.get_time( l ) );
        nodes_sims[i+2].set_arrival( arrival.get_time( l ) );
      }
//std::cout << l << "-> index=" << i+2 << std::endl;
      
      //nodes_sims.emplace_back( l, sensing.get_time( l ), arrival.get_time( l ) );
//if( n == 85 )
if( VERBOSEg )
{
  std::cout << l << "l " << nodes_sims[i+2].get_dyn_switch() << " tA=" << nodes_sims[i + 2].get_arrival() << " tS=" << nodes_sims[i + 2].get_sensing() << std::endl;
}
    }

    window_nodes.clear();
    for( auto l : win_manager.leaves )
    {
      window_nodes.insert(l);
    }
    for( auto d : win_manager.divs )
    {
      window_nodes.insert(d);
    }
    for( auto d : win_manager.mffc )
    {
      window_nodes.insert(d);
    }
//std::cout << std::endl;
//std::cout << "divs" << std::endl;

    std::vector<node_simulator_t*> sim_ptrs;
    for( int i = 0; i < win_manager.divs.size() ; ++i )
    {
      if( i < win_manager.leaves.size() )
        continue; // this is a leaf node
      node const d = win_manager.divs[i];
      sim_ptrs.clear();
      pntk->foreach_fanin( d, [&]( auto f, auto j ){
        node const ni = pntk->get_node( f );
        sim_ptrs.push_back( &nodes_sims[node_to_sim[ni]] );
      } );
      uint32_t const index { nodes_sims.size() };
      node_to_sim[d] = index;
//std::cout << d << "-> index=" << index << std::endl;
      nodes_sims.emplace_back( d, sensing.get_time( d ), arrival.get_time( d ) );
      auto const bind = pntk->get_binding( d );
      nodes_sims[index]( bind, list_simulator, sim_ptrs );
//if( n == 85 )
if( VERBOSEg )
{
  std::cout << d << "d " << nodes_sims[index].get_dyn_switch() << " tA=" << 
  nodes_sims[index].get_arrival() << " tS=" << nodes_sims[index].get_sensing() << std::endl;
}
//      assert( nodes_sims[index].get_dyn_switch() > 0 );
//std::cout << "size aft " << nodes_sims.size() << std::endl;
    }
//std::cout << std::endl;
//std::cout << "mffc" << std::endl;

    for( int i = 0; i < win_manager.mffc.size() ; ++i )
    {
      node const d = win_manager.mffc[i];

      sim_ptrs.clear();
      pntk->foreach_fanin( d, [&]( auto f, auto j ){
        node const ni = pntk->get_node( f );
        sim_ptrs.push_back( &nodes_sims[node_to_sim[ni]] );
      } );
      uint32_t const index { nodes_sims.size() };
      node_to_sim[d] = index;
//std::cout << d << "-> index=" << index << std::endl;
      nodes_sims.emplace_back( d, sensing.get_time( d ), arrival.get_time( d ) );
      auto const bind = pntk->get_binding( d );
      nodes_sims[index]( bind, list_simulator, sim_ptrs );
    }
//std::cout << std::endl;

  }

  cost evaluate( mapped_list const& list, std::array<node, num_vars> const& leaves, node const& n )
  {
    for( int i = 0; i < num_vars; ++i )
    {
      node const l = leaves[i];
      if( !pntk->is_null( l ) )
      {
        if( window_nodes.find( l ) == window_nodes.end() )
        {
          return 1u << 20;
        }
      }
    }

    if( ps.preserve_depth )
    {
      auto time = evaluate_arrival( list, leaves );
      if( time > arrival.get_required( n ) )
        return std::numeric_limits<double>::max() - 1000;
    }

    if( ps.preserve_window )
    {
      auto tS = evaluate_sensing( list, leaves );
      auto tA = evaluate_arrival( list, leaves );

      //std::cout << time << " <? " << sensing.get_time( n ) << std::endl;
      
      if( (tS < sensing.get_time( n )) || (tA > arrival.get_time( n )) )
      {
        return std::numeric_limits<double>::max() - 1000;
      }
    }

//    if( ps.preserve_flow )
//    {
//      auto flow = evaluate_flow( list, leaves );
      
//      std::cout << flow << " <? " << switch_flow.get_flow( n ) << std::endl;
      
//      if( flow > switch_flow.get_flow( n ) )
//      {
//        return std::numeric_limits<double>::max() - 1000;
//      }
//    }

//list.print();
    mlist_sims.resize( 2 );

    std::set<uint32_t> null_set;

    for( int i = 0; i < num_vars; ++i )
    {
      node const l = leaves[i];
      if( pntk->is_null( l ) )
      {
        mlist_sims.push_back( nodes_sims[0] );
        null_set.insert( i + 2 );
      }
      else
      {
        
        uint32_t const index = node_to_sim[l];
        mlist_sims.push_back( nodes_sims[index] );
      }
    }
    cost switching = zero_cost;

    mlist_sims.reserve( list.num_gates() + list.num_pis() + 10 );
    std::vector<uint32_t> fanout_sizes( list.size(), 0u );
    list.foreach_gate( [&]( auto children, auto id ) {
      for( auto lit : children )
        fanout_sizes[lit] += 1;
    });
    fanout_sizes[list.po_at(0)] = pntk->fanout_size(n);
    fanout_sizes[list.po_at(0)] = std::max( 1u, fanout_sizes[list.po_at(0)] );
// std::cout << fanout_sizes[list.po_at(0)] << " = |FO|" << std::endl;

for( int i = 0; i < num_vars; ++i )
{
  node const l = leaves[i];
  if( !pntk->is_null( l ) )
  {
    if( ps.use_fanouts && !pntk->is_pi( l ) && VERBOSEg )
    {
      std::cout << i+2 << " l: "<< mlist_sims[i+2].get_dyn_switch() << "x" << fanout_sizes[2+i] << "=" << mlist_sims[i+2].get_dyn_switch()*fanout_sizes[2+i] << std::endl;
    }
    }
  }


    list.foreach_gate( [&]( auto children, auto id ) {

      std::vector<node_simulator_t*> sim_ptrs(children.size());
      //sim_ptrs.emplace_back( &mlist_sims[0] );
      //sim_ptrs.emplace_back( &mlist_sims[1] );

      auto const g = lib[id];
      double sensing = std::numeric_limits<double>::max();
      double arrival = std::numeric_limits<double>::min();
      bool is_invalid = false;
      for( int i = 0; i < children.size(); ++i )
      {
        uint32_t const index = children[i];
        if( null_set.find( index ) != null_set.end() )
          is_invalid = true;
  
        sim_ptrs[i] = &mlist_sims[index];
        double const rise = g.pins[i].rise_block_delay;
        double const fall = g.pins[i].fall_block_delay;
        auto psim = sim_ptrs[children[i]];
        double const child_sensing = mlist_sims[index].get_sensing();
        double const child_arrival = mlist_sims[index].get_arrival();
        sensing = std::min( sensing, child_sensing + std::min( rise, fall ) );
        arrival = std::max( arrival, child_arrival + std::max( rise, fall ) );
      }

      uint32_t const index = mlist_sims.size();
      mlist_sims.emplace_back( pntk->get_null(), sensing, arrival );

      mlist_sims[index]( g, list_simulator, sim_ptrs );
      auto contr = mlist_sims[index].get_dyn_switch();
if( VERBOSEg )
  std::cout << index << " g: " << contr << "x" << std::max(1u, fanout_sizes[index]) << "=" << contr*std::max(1u, fanout_sizes[index]) << std::endl;
      switching += ps.use_fanouts ? contr*std::max(1u, fanout_sizes[index]) : contr;
      if( is_invalid )
        switching = (1u << 30);
    } );

    for( int i = 0; i < num_vars; ++i )
    {
      node const l = leaves[i];
      if( !pntk->is_null( l ) )
      {
        if( ps.use_fanouts && !pntk->is_pi( l ) )
        {
          switching += mlist_sims[i+2].get_dyn_switch()*fanout_sizes[2+i];
          if( VERBOSEg )
            std::cout << mlist_sims[i+2].get_dyn_switch()*fanout_sizes[2+i] << "+ ";
        }
//std::cout << mlist_sims[i+2].get_dyn_switch()*fanout_sizes[2+i] << "(l "<< l << ")+";
      }
    }
if( VERBOSEg )
  std::cout << "cand = " << switching << std::endl;

    //return list.get_area( lib );
    return switching;
  }


  cost evaluate( mapped_list const& list, std::vector<node> const& leaves, node const& n )
  {
    for( int i = 0; i < leaves.size(); ++i )
    {
      node const l = leaves[i];
      if( !pntk->is_null( l ) )
      {
        if( window_nodes.find( l ) == window_nodes.end() )
        {
          return 1u << 20;
        }
      }
    }

    if( ps.preserve_depth )
    {
      auto time = evaluate_arrival( list, leaves );
      if( time > arrival.get_required( n ) )
        return std::numeric_limits<double>::max() - 1000;
    }

    if( ps.preserve_window )
    {
      auto tS = evaluate_sensing( list, leaves );
      auto tA = evaluate_arrival( list, leaves );

      //std::cout << time << " <? " << sensing.get_time( n ) << std::endl;
      
      if( (tS < sensing.get_time( n )) || (tA > arrival.get_time( n )) )
      {
        return std::numeric_limits<double>::max() - 1000;
      }
    }

//    if( ps.preserve_flow )
//    {
//      auto flow = evaluate_flow( list, leaves );
      
//      std::cout << flow << " <? " << switch_flow.get_flow( n ) << std::endl;
      
//      if( flow > switch_flow.get_flow( n ) )
//      {
//        return std::numeric_limits<double>::max() - 1000;
//      }
//    }

//list.print();
    mlist_sims.resize( 2 );

    std::set<uint32_t> null_set;

    for( int i = 0; i < leaves.size(); ++i )
    {
      node const l = leaves[i];
      if( pntk->is_null( l ) )
      {
        mlist_sims.push_back( nodes_sims[0] );
        null_set.insert( i + 2 );
      }
      else
      {
        uint32_t const index = node_to_sim[l];
        mlist_sims.push_back( nodes_sims[index] );
      }
    }
    cost switching = zero_cost;

    mlist_sims.reserve( list.num_gates() + list.num_pis() + 10 );
    std::vector<uint32_t> fanout_sizes( list.size(), 0u );
    list.foreach_gate( [&]( auto children, auto id ) {
      for( auto lit : children )
        fanout_sizes[lit] += 1;
    });
    fanout_sizes[list.po_at(0)] = pntk->fanout_size(n);
    fanout_sizes[list.po_at(0)] = std::max( 1u, fanout_sizes[list.po_at(0)] );
// std::cout << fanout_sizes[list.po_at(0)] << " = |FO|" << std::endl;

for( int i = 0; i < leaves.size(); ++i )
{
  node const l = leaves[i];
  if( !pntk->is_null( l ) )
  {
    if( ps.use_fanouts && !pntk->is_pi( l ) && VERBOSEg )
    {
      std::cout << i+2 << " l: "<< mlist_sims[i+2].get_dyn_switch() << "x" << fanout_sizes[2+i] << "=" << mlist_sims[i+2].get_dyn_switch()*fanout_sizes[2+i] << std::endl;
    }
    }
  }


    list.foreach_gate( [&]( auto children, auto id ) {

      std::vector<node_simulator_t*> sim_ptrs(children.size());
      //sim_ptrs.emplace_back( &mlist_sims[0] );
      //sim_ptrs.emplace_back( &mlist_sims[1] );

      auto const g = lib[id];
      double sensing = std::numeric_limits<double>::max();
      double arrival = std::numeric_limits<double>::min();
      bool is_invalid = false;
      for( int i = 0; i < children.size(); ++i )
      {
        uint32_t const index = children[i];
        if( null_set.find( index ) != null_set.end() )
          is_invalid = true;
  
        sim_ptrs[i] = &mlist_sims[index];
        double const rise = g.pins[i].rise_block_delay;
        double const fall = g.pins[i].fall_block_delay;
        auto psim = sim_ptrs[children[i]];
        double const child_sensing = mlist_sims[index].get_sensing();
        double const child_arrival = mlist_sims[index].get_arrival();
        sensing = std::min( sensing, child_sensing + std::min( rise, fall ) );
        arrival = std::max( arrival, child_arrival + std::max( rise, fall ) );
      }

      uint32_t const index = mlist_sims.size();
      mlist_sims.emplace_back( pntk->get_null(), sensing, arrival );

      mlist_sims[index]( g, list_simulator, sim_ptrs );
      auto contr = mlist_sims[index].get_dyn_switch();
if( VERBOSEg )
  std::cout << index << " g: " << contr << "x" << std::max(1u, fanout_sizes[index]) << "=" << contr*std::max(1u, fanout_sizes[index]) << std::endl;
      switching += ps.use_fanouts ? contr*std::max(1u, fanout_sizes[index]) : contr;
      if( is_invalid )
        switching = (1u << 30);
    } );

    for( int i = 0; i < leaves.size(); ++i )
    {
      node const l = leaves[i];
      if( !pntk->is_null( l ) )
      {
        if( ps.use_fanouts && !pntk->is_pi( l ) )
        {
          switching += mlist_sims[i+2].get_dyn_switch()*fanout_sizes[2+i];
          if( VERBOSEg )
            std::cout << mlist_sims[i+2].get_dyn_switch()*fanout_sizes[2+i] << "+ ";
        }
//std::cout << mlist_sims[i+2].get_dyn_switch()*fanout_sizes[2+i] << "(l "<< l << ")+";
      }
    }
if( VERBOSEg )
  std::cout << "cand = " << switching << std::endl;

    //return list.get_area( lib );
    return switching;
  }



  double get_sensing( node n )
  {
    return sensing.get_time( n );
  }

  double get_arrival( node n )
  {
    return arrival.get_time( n );
  }

  template<class Cut_t>
  cost evaluate_arrival( mapped_list const& list, Cut_t const& leaves )
  {
    std::vector<double> times( list.size(), 0 );
    times[0] = 0;
    times[1] = 0;
    list.foreach_pi( [&]( auto v ) {
      node n = leaves[ v - 2 ];
      if( pntk->is_null( n ) )
        times[v] = 1 << 20;
      else
        times[v] = arrival.get_time( n );
//std::cout << "t[" << v << ", " << leaves[v] << "]=" << times[v] << std::endl;
    } );
    
    uint32_t index = 2 + list.num_pis();
    
    double node_arrival;
    list.foreach_gate( [&]( auto children, auto id ){
      node_arrival = std::numeric_limits<double>::min();
      for( int i = 0; i < children.size(); ++i )
      {
        auto const g = lib[id];
        uint32_t const child = children[i];
//std::cout << " t_c" << i << " " << times[child] << std::endl;
        double const rise = g.pins[i].rise_block_delay;
        double const fall = g.pins[i].fall_block_delay;
        double const child_arrival = times[child];
        node_arrival = std::max( node_arrival, child_arrival + std::max( rise, fall ) );
      }
      times[index++] = node_arrival;
//std::cout << "t[" << index-1 << "]=" << times[index-1] << std::endl;

    } );
//std::cout << "t[" << list.po_at(0) << "]=" << times[list.po_at(0)] << std::endl;
    return times[list.po_at(0)];
  }

  template<class Cut_t>
  cost evaluate_sensing( mapped_list const& list, Cut_t const& leaves )
  {
    std::vector<double> times( list.size(), 0 );
    times[0] = 0;
    times[1] = 0;
    list.foreach_pi( [&]( auto v ) {
      node n = leaves[ v - 2 ];
      if( pntk->is_null( n ) )
        times[v] = 1 << 20;
      else
        times[v] = sensing.get_time( n );
//std::cout << "t[" << v << ", " << leaves[v] << "]=" << times[v] << std::endl;
    } );
    
    uint32_t index = 2 + list.num_pis();
    
    double node_arrival;
    list.foreach_gate( [&]( auto children, auto id ){
      node_arrival = std::numeric_limits<double>::max();
      for( int i = 0; i < children.size(); ++i )
      {
        auto const g = lib[id];
        uint32_t const child = children[i];
//std::cout << " t_c" << i << " " << times[child] << std::endl;
        double const rise = g.pins[i].rise_block_delay;
        double const fall = g.pins[i].fall_block_delay;
        double const child_arrival = times[child];
        node_arrival = std::min( node_arrival, child_arrival + std::max( rise, fall ) );
      }
      times[index++] = node_arrival;
//std::cout << "t[" << index-1 << "]=" << times[index-1] << std::endl;

    } );
//std::cout << "t[" << list.po_at(0) << "]=" << times[list.po_at(0)] << std::endl;
    return times[list.po_at(0)];
  }

  template<class Bind>
  double gate_switching( Bind const& b ) const
  {
    auto tt = b.function;
    double const n0 = kitty::count_zeros( tt );
    double const nb = tt.num_bits();
    double const n1 = nb - n0;
    return 2*n1*n0/( nb*nb );
  }

  cost evaluate_flow( mapped_list const& list, std::array<node, num_vars> const& leaves )
  {
    std::vector<double> flows( list.size(), 0 );
    flows[0] = 0;
    flows[1] = 0;
    list.foreach_pi( [&]( auto v ) {
      node n = leaves[ v - 2 ];
      if( pntk->is_null( n ) )
        flows[v] = 1 << 20;
      else
        flows[v] = switch_flow.get_flow( n );
//std::cout << "t[" << v << ", " << leaves[v] << "]=" << flows[v] << std::endl;
    } );
    
    uint32_t index = 2 + list.num_pis();
    
    double node_arrival;
    list.foreach_gate( [&]( auto children, auto id ){
      double dflow = 0;
      auto const g = lib[id];
      for( int i = 0; i < children.size(); ++i )
      {
        uint32_t const child = children[i];
        dflow += flows[child];
      }
      flows[index++] = dflow + gate_switching( g );
//std::cout << "t[" << index-1 << "]=" << flows[index-1] << std::endl;
    } );
//std::cout << "t[" << list.po_at(0) << "]=" << times[list.po_at(0)] << std::endl;
    return flows[list.po_at(0)];
  }

  template<class Leaves_t>
  cost evaluate( node const& n, Leaves_t const& leaves )
  {
//std::cout << std::endl;
    cost cost_deref = measure_mffc_deref( n, leaves );
    cost cost_ref = measure_mffc_ref( n, leaves );
    if( cost_ref != cost_deref )
      std::cerr << "[e] different costs " << cost_ref << " " << cost_deref << std::endl;
    return cost_deref;
  }

  cost evaluate_rewiring( node const& n, node const& ncurr )
  {
    uint32_t index = node_to_sim[n];
    if( ps.preserve_depth )
    {
      if( arrival.get_arrival( n ) > arrival.get_required( ncurr ) )
      {
        return std::numeric_limits<double>::max() - 1000;
      }
    }
    if( ps.preserve_window )
    {
      if( sensing.get_time( n ) < sensing.get_time( ncurr ) )
      {
        return std::numeric_limits<double>::max() - 1000;
      }
    }
    return ps.use_fanouts ? nodes_sims[index].get_dyn_switch()*( pntk->fanout_size(ncurr)+pntk->fanout_size(n) ) : nodes_sims[index].get_dyn_switch();
  }

  template<class Leaves_t>
  cost measure_mffc_deref( node const& n, Leaves_t const& leaves )
  {
    /* reference cut leaves */
    for ( auto leaf : leaves )
    {
      if( pntk->is_null( leaf ) )
        continue;
      pntk->incr_fanout_size( leaf );
    }

    cost mffc_cost = recursive_deref( n );

    /* dereference leaves */
    for ( auto leaf : leaves )
    {
      if( pntk->is_null( leaf ) )
        continue;
      pntk->decr_fanout_size( leaf );
     // mffc_cost += nodes_sims[node_to_sim[leaf]].get_dyn_switch();
    }

    return mffc_cost;
  }

  template<class Leaves_t>
  cost measure_mffc_ref( node const& n, Leaves_t const& leaves )
  {
    /* reference cut leaves */
    for ( auto leaf : leaves )
    {
      if( pntk->is_null( leaf ) )
        continue;
      pntk->incr_fanout_size( leaf );
    }

    cost mffc_cost = recursive_ref( n );

    /* dereference leaves */
    for ( auto leaf : leaves )
    {
      if( pntk->is_null( leaf ) )
        continue;
      pntk->decr_fanout_size( leaf );
     // mffc_cost += nodes_sims[node_to_sim[leaf]].get_dyn_switch();
    }

    return mffc_cost;
  }

  cost recursive_deref( node const& n )
  {
    /* terminate? */
    if ( pntk->is_constant( n ) || pntk->is_pi( n ) )
      return zero_cost;
    
    if( !node_to_sim.has( n ) )
    {
  //    std::cerr << "[e] mffc node not simulated" << std::endl;
    }

    /* recursively collect nodes */
    uint32_t fanout_size = pntk->_storage->nodes[n].fanout.size();
    fanout_size = std::max( 1u, fanout_size );
    cost value = ps.use_fanouts ? nodes_sims[node_to_sim[n]].get_dyn_switch()*fanout_size : nodes_sims[node_to_sim[n]].get_dyn_switch();
//std::cout << n << " |FO|=" << fanout_size << " C=" << value << std::endl;
if( VERBOSEg )
  std::cout << "(r " << n << " : " << nodes_sims[node_to_sim[n]].get_dyn_switch()<<"x"<< fanout_size << "=" << nodes_sims[node_to_sim[n]].get_dyn_switch()*fanout_size << ")" << std::endl;
    pntk->foreach_fanin( n, [&]( auto const& s ) {
      if ( pntk->decr_fanout_size( pntk->get_node( s ) ) == 0 )
      {
        value += recursive_deref( pntk->get_node( s ) );
      }
      else
      {
        auto ni = pntk->get_node( s );
        if( ps.use_fanouts && !pntk->is_pi( ni ) )
          value += nodes_sims[node_to_sim[ni]].get_dyn_switch();
if( VERBOSEg )
  std::cout << "(l " << ni << " : " << nodes_sims[node_to_sim[ni]].get_dyn_switch() << ")" << std::endl;
      }
    } );
    return value;
  }

  cost recursive_ref( node const& n )
  {
    /* terminate? */
    if ( pntk->is_constant( n ) || pntk->is_pi( n ) )
      return zero_cost;

    /* recursively collect nodes */
    uint32_t fanout_size = pntk->_storage->nodes[n].fanout.size();
    fanout_size = std::max( 1u, fanout_size );
    cost value = ps.use_fanouts ? nodes_sims[node_to_sim[n]].get_dyn_switch()*fanout_size : nodes_sims[node_to_sim[n]].get_dyn_switch();

    pntk->foreach_fanin( n, [&]( auto const& s ) {
      if ( pntk->incr_fanout_size( pntk->get_node( s ) ) == 0 )
      {
        value += recursive_ref( pntk->get_node( s ) );
      }
      else
      {
        auto ni = pntk->get_node( s );
        if( ps.use_fanouts && !pntk->is_pi( ni ))
          value += nodes_sims[node_to_sim[ni]].get_dyn_switch();
      }
    } );
    return value;
  }

  double compare( cost const& current, cost const& candidate )
  {
    return current - candidate;
  }

  double get_time( node const& n )
  {
    return arrival.get_time( n );
  }

  template<typename Fn>
  void foreach_gate( Fn&& fn ) const
  {
    for ( int i = 0; i < nodes.size(); i++ )
    {
      fn( nodes[i] );
    }
  }

  void choose_gates()
  {

    if( ps.hot_wires )
    {
      choose_hot_gates();
    }
    else
    {
      choose_simple();
    }
  }

  void choose_hot_gates()
  {

    convo_analyzer<Ntk, num_steps, cube_size, max_leaves> power( *pntk );
    power( 1 );

    if( ps.only_critical )
    {
      arrival.compute_required_times();
    }
    uint32_t const size = pntk->size();

    std::vector<std::pair<node, double>> nodes_with_hotness;

    pntk->foreach_gate( [&]( auto n, auto i ) {
      if( i > size )
      {
        return false;
      }
      if( pntk->is_pi( n ) || pntk->is_constant( n ) )
      {
        return true;
      }

      if ( pntk->is_dead( n ) )
      {
        return true;
      }
      
      if( !ps.only_critical || ( arrival.is_critical( n ) ) )
      {
        double cost = 0;
        //pntk->foreach_fanin( n, [&]( auto fi, auto ii ){
        //  auto ni = pntk->get_node( fi );
        //  cost += power.get_dyn_switch( ni )*pntk->_storage->nodes[ni].fanout.size();
        //} );
        cost += ps.use_fanouts ? power.get_dyn_switch( n )*pntk->fanout_size( n ) : power.get_dyn_switch( n );
        nodes_with_hotness.push_back( std::make_pair( n, cost ) );
      }
      return true;
    } );
    std::sort( nodes_with_hotness.begin(), nodes_with_hotness.end(), []( auto a, auto b ){
      return a.second > b.second;
    } );

    for( auto n : nodes_with_hotness )
      nodes.push_back( n.first );
  }

  void choose_simple()
  {
    if( ps.only_critical )
    {
      arrival.compute_required_times();
    }
    uint32_t const size = pntk->size();
    pntk->foreach_gate( [&]( auto n, auto i ) {
      if( i > size )
      {
        return false;
      }
      if( pntk->is_pi( n ) || pntk->is_constant( n ) )
      {
        return true;
      }

      if ( pntk->is_dead( n ) )
      {
        return true;
      }
      
      if( !ps.only_critical || ( arrival.is_critical( n ) ) )
      {
        nodes.push_back( n );
      }
      return true;
    } );
  }

public:
  //double get_power()
  //{
  //  return power.get_dyn_power();
  //}

private:
  std::shared_ptr<Ntk> pntk;
  bindings const lib;

//  window_manager<Ntk> win_manager;
  std::array<node_simulator_t, max_leaves> input_sims;
  std::vector<node_simulator_t> nodes_sims;
  std::vector<node_simulator_t> mlist_sims;
  //convo_analyzer<Ntk, num_steps, cube_size> power; //uint32_t num_vars, uint32_t num_steps, uint32_t cube_size, uint32_t max_leaves
  incomplete_node_map<uint32_t, Ntk> node_to_sim;
  sensing_analyzer<Ntk> sensing;
  arrival_analyzer<Ntk> arrival;
  switch_analyzer<Ntk> switch_flow;
  std::vector<typename Ntk::node> nodes;
  std::set<typename Ntk::node> window_nodes;

  double dyn_switch;
  double zero_delay;
  list_simulator_t list_simulator;
  xgx_resyn_params ps;

};

} /* namespace mockturtle */