/* mockturtle: C++ logic network library
 * Copyright (C) 2018-2022  EPFL
 *
 * Permission is hereby granted, free of charge, to any person
 * obtaining a copy of this software and associated documentation
 * files (the "Software"), to deal in the Software without
 * restriction, including without limitation the rights to use,
 * copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following
 * conditions:
 *
 * The above copyright notice and this permission notice shall be
 * included in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
 * OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
 * HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
 * WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 */

/*!
  \file timing.hpp
  \brief Compute timing information of a network.

  This engine can be used for power analysis of mapped network.
  For each node, the following information is stored:
  - The sensing time : the first time at which a transition can happen
  - The arrival time : the first time at which the output is stable
  - A vector of simulation patterns identifying quantized timesteps in this interval
  The class has the following template parameters:
  \param N : number of timesteps used for simulating each signal
  \param I : number of inputs to be used for simulating the static truth table ( 2^I input pairs )

  \author Andrea Costamagna
*/

#pragma once

#include "../../utils/node_map.hpp"


namespace mockturtle
{

template<class Ntk>
class arrival_analyzer
{
public:
  using node = typename Ntk::node;
  using signal = typename Ntk::signal;

  arrival_analyzer( Ntk & ntk )
    : pntk( std::make_shared<Ntk>( ntk ) ),
      arrivals( ntk ),
      required( ntk )
  {
    rev_topo_order.reserve( pntk->size() );
    compute_arrival_times();
    add_event = pntk->events().register_add_event( [&]( const auto& n ) {
      arrivals.resize();
      signal const f = pntk->make_signal( n );
      //compute_arrival_tfi( f );
      compute_arrival_times();
    } );

    modified_event = pntk->events().register_modified_event( [&]( const auto& n, auto children ) {
      arrivals.resize();
      pntk->incr_trav_id();
      //compute_arrival_tfo( n );
      compute_arrival_times();
    } );
  }

  ~arrival_analyzer()
  {
    if ( add_event )
    {
      pntk->events().release_add_event( add_event );
    }

    if ( modified_event )
    {
      pntk->events().release_modified_event( modified_event );
    }
  }

#pragma region Arrival
void compute_arrival_times( std::vector<double> const& input_arrivals )
{
  pntk->incr_trav_id();
  arrivals.reset();
  int index = 0;
  pntk->foreach_pi( [&]( auto n ){
    arrivals[n] = input_arrivals[index++];
  } );
  pntk->foreach_po( [&]( auto f ){
    compute_arrival_tfi( f );
  } );
}

void compute_arrival_times()
{
  arrivals.reset();
  std::vector<double> input_arrivals( pntk->num_pis(), 0 );
  compute_arrival_times( input_arrivals );
}

void topo_sort()
{
  rev_topo_order.clear();
  pntk->incr_trav_id();
  pntk->foreach_po( [&]( auto fo, auto io ){
    topo_sort_rec( fo );
  } );
  std::reverse( rev_topo_order.begin(), rev_topo_order.end() );
}

void topo_sort_rec( signal f )
{
  node n = pntk->get_node( f );
  if( pntk->visited( n ) == pntk->trav_id() )
    return;
  if( pntk->is_pi( n ) )
    return;
  
  pntk->set_visited( n, pntk->trav_id() );
  pntk->foreach_fanin( n, [&]( auto fi, auto ii ){
    topo_sort_rec( fi );
  } );
  rev_topo_order.push_back( n );
}

void compute_required_times()
{
  topo_sort();
  required.reset();

  pntk->foreach_po( [&]( auto fo, auto io ){
    auto no = pntk->get_node( fo );
    required[no] = arrivals[no];
  } );

  for( auto n : rev_topo_order )
  {
    pntk->foreach_fanout( n, [&]( auto fo, auto io ){
      node no = pntk->get_node( fo );
      auto go = pntk->get_binding( no );
      uint32_t index = -1;
      pntk->foreach_fanin( no, [&]( auto fi, auto ii ){
        if( pntk->get_node( fi ) == n )
        {
          index = ii;
        }
      } );
      assert( index != -1 && "Node not found in the FIs of the FO node" );
      double const rise_time = go.pins[index].rise_block_delay;
      double const fall_time = go.pins[index].fall_block_delay;
      double const delta = std::max( rise_time, fall_time );
      required[n] = std::min( required[n], required[no] - delta );
    } );
  }
}

void compute_arrival_tfi( signal const& f )
{
  node n = pntk->get_node( f );

  if( n > pntk->size() )
  {
    return;
  }

  if( pntk->is_pi( n ) )
  {
    arrivals[n] = 0;
    return;
  }
  if( pntk->visited( n ) == pntk->trav_id() )
  {
    return;
  }
  auto g = pntk->get_binding( n );
  arrivals[n] = 0;
  pntk->foreach_fanin( n, [&]( auto fi, auto ii ){
    node ni = pntk->get_node( fi );
    compute_arrival_tfi( fi );
    double const rise_time = g.pins[ii].rise_block_delay;
    double const fall_time = g.pins[ii].fall_block_delay;
    double const max_delay = std::max( rise_time, fall_time );
    arrivals[n] = std::max( arrivals[n], arrivals[ni] + max_delay );    
  } );
  pntk->set_visited( n, pntk->trav_id() );
}

void compute_arrival_tfo( node const& n )
{
  if( pntk->visited( n ) == pntk->trav_id() )
    return;
  pntk->set_visited( n, pntk->trav_id() );

  auto g = pntk->get_binding( n );
  arrivals[n] = 0;
  pntk->foreach_fanin( n, [&]( auto fi, auto ii ){
    node ni = pntk->get_node( fi );
    double const rise_time = g.pins[ii].rise_block_delay;
    double const fall_time = g.pins[ii].fall_block_delay;
    double const max_delay = std::max( rise_time, fall_time );
    arrivals[n] = std::max( arrivals[n], arrivals[ni] + max_delay );    
  } );

  pntk->foreach_fanout( n, [&]( auto no ){
    compute_arrival_tfo( no );
  } );

}

double worst_delay()
{
  double worst_delay = 0;
  pntk->foreach_po( [&]( auto f ){
    worst_delay = std::max( worst_delay, arrivals[f] );
  } );
  return worst_delay;
}

double get_time( node n ) const
{
  return pntk->is_null( n ) ? 1.0*(1u << 20u) : arrivals[n];
}

double get_time( signal f )
{
  node const n = pntk->get_node( f );
  return get_time( n );
}

bool has( node n ) const
{
  return arrivals.has( n );
}

bool is_critical( node n ) const
{
  return std::abs( required[n] - arrivals[n] ) <= 0.01;
}

#pragma endregion

private:
  std::shared_ptr<Ntk> pntk;
  incomplete_node_map<double, Ntk> arrivals;
  incomplete_node_map<double, Ntk> required;
  std::vector<node> rev_topo_order;
  /* events */
  std::shared_ptr<typename network_events<Ntk>::add_event_type> add_event;
  std::shared_ptr<typename network_events<Ntk>::modified_event_type> modified_event;
};

} // namespace mockturtle