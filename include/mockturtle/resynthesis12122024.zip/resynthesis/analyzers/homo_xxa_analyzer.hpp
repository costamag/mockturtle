/* mockturtle: C++ logic network library
 * Copyright (C) 2018-2023  EPFL
 *
 * Permission is hereby granted, free of charge, to any person
 * obtaining a copy of this software and associated documentation
 * files (the "Software"), to deal in the Software without
 * restriction, including without limitation the rights to use,
 * copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following
 * conditions:
 *
 * The above copyright notice and this permission notice shall be
 * included in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
 * OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
 * HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
 * WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 */

/*!
  \file homo_xxa_analyzer.hpp
  \brief Inplace rewrite

  \author Andrea Costamagna
*/

#pragma once

#include "../database/mapped_list.hpp"
#include "../timing/arrival_analyzer.hpp"

#include <fmt/format.h>
#include <kitty/dynamic_truth_table.hpp>
#include <kitty/npn.hpp>
#include <kitty/operations.hpp>
#include <kitty/static_truth_table.hpp>

namespace mockturtle
{

template<class Ntk, uint32_t num_vars>
class homo_xxa_analyzer
{
public:
  using node = typename Ntk::node;
  using cost = double;
  static constexpr cost zero_cost = 0;
  static constexpr cost min_cost = std::numeric_limits<cost>::min();
  static constexpr cost max_cost = std::numeric_limits<cost>::max();

public:
  homo_xxa_analyzer( Ntk& ntk )
      : pntk( std::make_shared<Ntk>(ntk) ),
      lib( ntk.get_bindings() ),
      arrival( ntk )
  {
    init();
  }

  void init()
  {
    std::vector<double> input_arrival( pntk->num_pis(), +0.00 );
    arrival.compute_arrival_times( input_arrival );
    double const delay = arrival.worst_delay();
  }

  void operator()( node const& n )
  {
  }

  cost evaluate( mapped_list const& list, std::array<node, num_vars> const& leaves )
  {
    return list.get_area( lib );
  }

  template<class Leaves_t>
  cost evaluate( node const& n, Leaves_t const& leaves )
  {
    cost cost_deref = measure_mffc_deref( n, leaves );
    cost cost_ref = measure_mffc_ref( n, leaves );
    if( std::abs( cost_ref - cost_deref ) > 0.01 )
    {
      std::cout << cost_ref << " != " << cost_deref << std::endl;
      std::cerr << "[e] different costs " << std::endl;
      assert( cost_ref == cost_deref );
    }
    return cost_deref;
  }

  cost evaluate_rewiring( node const& n )
  {
    (void)n;
    return zero_cost;
  }


  template<class Leaves_t>
  cost measure_mffc_deref( node const& n, Leaves_t const& leaves )
  {
    /* reference cut leaves */
    for ( auto leaf : leaves )
    {
      if( !pntk->is_null( leaf ) )
        pntk->incr_fanout_size( leaf );
    }

    cost mffc_cost = recursive_deref( n );

    /* dereference leaves */
    for ( auto leaf : leaves )
    {
      pntk->decr_fanout_size( leaf );
    }

    return mffc_cost;
  }

  template<class Leaves_t>
  cost measure_mffc_ref( node const& n, Leaves_t const& leaves )
  {
    /* reference cut leaves */
    for ( auto leaf : leaves )
    {
      pntk->incr_fanout_size( leaf );
    }

    cost mffc_cost = recursive_ref( n );

    /* dereference leaves */
    for ( auto leaf : leaves )
    {
      pntk->decr_fanout_size( leaf );
    }

    return mffc_cost;
  }

  cost recursive_deref( node const& n )
  {
    /* terminate? */
    if ( pntk->is_constant( n ) || pntk->is_pi( n ) )
      return zero_cost;

    /* recursively collect nodes */
    cost value{ pntk->get_area( n ) };
    pntk->foreach_fanin( n, [&]( auto const& s ) {
      if ( pntk->decr_fanout_size( pntk->get_node( s ) ) == 0 )
      {
        value += recursive_deref( pntk->get_node( s ) );
      }
    } );
    return value;
  }

  cost recursive_ref( node const& n )
  {
    /* terminate? */
    if ( pntk->is_constant( n ) || pntk->is_pi( n ) )
      return zero_cost;

    /* recursively collect nodes */
    cost value{ pntk->get_area( n ) };

    pntk->foreach_fanin( n, [&]( auto const& s ) {
      if ( pntk->incr_fanout_size( pntk->get_node( s ) ) == 0 )
      {
        value += recursive_ref( pntk->get_node( s ) );
      }
    } );
    return value;
  }

  double compare( cost const& current, cost const& candidate )
  {
    return current - candidate;
  }

  double get_time( node const& n )
  {
    return arrival.get_time( n );
  }

  template<typename Fn>
  void foreach_gate( Fn&& fn ) const
  {
    for ( int i = 0; i < nodes.size(); i++ )
    {
      fn( nodes[i] );
    }
  }

  void choose_gates()
  {
    if( ps.only_critical )
    {
      arrival.compute_required_times();
    }

    uint32_t const size = pntk->size();
    pntk->foreach_gate( [&]( auto n, auto i ) {
      if( i > size )
      {
        return false;
      }
      if( pntk->is_pi( n ) || pntk->is_constant( n ) )
      {
        return true;
      }

      if ( pntk->is_dead( n ) )
      {
        return true;
      }
      
      if( !ps.only_critical || ( arrival.is_critical( n ) ) )
      {
        nodes.push_back( n );
      }
      return true;
    } );
  }

private:
  std::shared_ptr<Ntk> pntk;
  std::vector<node> nodes;
  bindings const lib;
  arrival_analyzer<Ntk> arrival;

};

} /* namespace mockturtle */