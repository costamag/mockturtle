/* mockturtle: C++ logic network library
 * Copyright (C) 2018-2023  EPFL
 *
 * Permission is hereby granted, free of charge, to any person
 * obtaining a copy of this software and associated documentation
 * files (the "Software"), to deal in the Software without
 * restriction, including without limitation the rights to use,
 * copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following
 * conditions:
 *
 * The above copyright notice and this permission notice shall be
 * included in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
 * OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
 * HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
 * WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 */

/*!
  \file homo_xpx_analyzer.hpp
  \brief Inplace rewrite

  \author Andrea Costamagna
*/

#pragma once

#include "../database/mapped_list.hpp"

#include "../windowing/window_manager.hpp"
#include "../../algorithms/simulation.hpp"
#include "../list_simulator.hpp"
#include "../timing/sensing_analyzer.hpp"
#include "../timing/arrival_analyzer.hpp"
#include "../power/node_simulator.hpp"
#include "../../algorithms/detail/resub_utils.hpp"
#include "../../algorithms/reconv_cut.hpp"

#include <fmt/format.h>
#include <kitty/dynamic_truth_table.hpp>
#include <kitty/npn.hpp>
#include <kitty/operations.hpp>
#include <kitty/static_truth_table.hpp>

namespace mockturtle
{

template<class Ntk, uint32_t num_vars>
class homo_xpx_analyzer
{
public:
  using node = typename Ntk::node;
  using signal = typename Ntk::signal;
  using cost = double;
  static constexpr cost zero_cost = 0;
  static constexpr cost min_cost = std::numeric_limits<cost>::min();
  static constexpr cost max_cost = std::numeric_limits<cost>::max();

  static constexpr uint32_t num_steps = 20;
  static constexpr uint32_t cube_size = 10;
  static constexpr uint32_t max_leaves = 12;

  using truth_table_t = kitty::static_truth_table<cube_size>;
  using node_simulator_t = node_simulator<Ntk, num_steps, cube_size>;
  using list_simulator_t = aig_list_simulator<truth_table_t>;

public:
  homo_xpx_analyzer( Ntk& ntk )
    : ntk( ntk ),
      lib( ntk.get_bindings() ),
      win_manager( ntk ),
      node_to_sim( ntk ),
      sensing( ntk ),
      arrival( ntk ),
      zero_delay( 0 ),
      dyn_switch( 0 )
  {
    size_t extra_space = 1000;
    nodes_sims.reserve( ntk.size() + extra_space );
    mlist_sims.reserve( 20 );
    init();
  }

  void init()
  {
    std::vector<double> input_sensing( ntk.num_pis(), -0.01 );
    std::vector<double> input_arrival( ntk.num_pis(), +0.00 );
    sensing.compute_sensing_times( input_sensing );
    arrival.compute_arrival_times( input_arrival );
    double const delay = arrival.worst_delay();
    truth_table_t const0;
    /* initialize the constants */
    std::array<truth_table_t, 2> const pair0 = {  const0,  const0 };
    std::array<truth_table_t, 2> const pair1 = { ~const0, ~const0 };
    node const n0 = ntk.get_node( ntk.get_constant( false ) );
    node const n1 = ntk.get_node( ntk.get_constant( true ) );
    double const start = 0;
    node_simulator_t sim0( n0, pair0, start, start, delay );
    node_simulator_t sim1( n1, pair1, start, start, delay );
    nodes_sims.push_back( sim0 );
    nodes_sims.push_back( sim1 );
    mlist_sims.push_back( sim0 );
    mlist_sims.push_back( sim1 );

    node_to_sim[ntk.get_node( ntk.get_constant( false ) )] = 0;
    node_to_sim[ntk.get_node( ntk.get_constant( true ) )] = 1;
    ntk.set_visited( 0, ntk.trav_id() );
    ntk.set_visited( 1, ntk.trav_id() );

    std::array<kitty::static_truth_table<cube_size>, 2> workload;
    std::default_random_engine::result_type seed = 1;
    for( int i = 0; i < max_leaves; ++i )
    {
      kitty::create_random( workload[0], seed++ );
      kitty::create_random( workload[1], seed++ );
      node_simulator_t sim( 0, workload, -0.01, -0.02, 0 );
      nodes_sims.emplace_back( sim );
    }
  }

  void reset()
  {
    /* clear information */
    nodes_sims.resize( max_leaves + 2 );
    mlist_sims.resize( 2 );
    node_to_sim.resize();
    node_to_sim[ntk.get_node( ntk.get_constant( false ) )] = 0;
    node_to_sim[ntk.get_node( ntk.get_constant( true ) )] = 1;
  }

  void operator()( node const& n )
  {
    reset();
    dyn_switch = 0;
    zero_delay = 0;

    if( !win_manager.run( n ) )
    {
      std::cerr << "[e] window construction failed" << std::endl;
      return;
    }


    for( int i = 0; i < win_manager.leaves.size(); ++i )
    {
      node const l = win_manager.leaves[i];
      node_to_sim[l] = i + 2;
      nodes_sims.emplace_back( l, sensing.get_time( l ), arrival.get_time( l ) );
    }

    std::vector<node_simulator_t*> sim_ptrs;
    for( int i = 0; i < win_manager.divs.size() ; ++i )
    {
      if( i < win_manager.leaves.size() )
        continue; // this is a leaf node
      node const d = win_manager.divs[i];
      sim_ptrs.clear();
      ntk.foreach_fanin( d, [&]( auto f, auto j ){
        node const ni = ntk.get_node( f );
        sim_ptrs.push_back( &nodes_sims[node_to_sim[ni]] );
      } );
      uint32_t const index { nodes_sims.size() };
      node_to_sim[d] = index;
      nodes_sims.emplace_back( d, sensing.get_time( d ), arrival.get_time( d ) );
      auto const bind = ntk.get_binding( d );
      nodes_sims[index]( bind, list_simulator, sim_ptrs );
    }

    for( int i = 0; i < win_manager.mffc.size() ; ++i )
    {
      node const d = win_manager.mffc[i];
      sim_ptrs.clear();
      ntk.foreach_fanin( d, [&]( auto f, auto j ){
        node const ni = ntk.get_node( f );
        sim_ptrs.push_back( &nodes_sims[node_to_sim[ni]] );
      } );
      uint32_t const index { nodes_sims.size() };
      node_to_sim[d] = index;
      nodes_sims.emplace_back( d, sensing.get_time( d ), arrival.get_time( d ) );
      auto const bind = ntk.get_binding( d );
      nodes_sims[index]( bind, list_simulator, sim_ptrs );
    }
  }

  cost evaluate( mapped_list const& list, std::array<node, num_vars> const& leaves )
  {
    list.print();
    mlist_sims.resize( 2 );

    for( int i = 0; i < num_vars; ++i )
    {
      node const l = leaves[i];
      if( ntk.is_null( l ) )
      {
        mlist_sims.push_back( nodes_sims[0] );
      }
      else
      {
        uint32_t const index = node_to_sim[l];
        mlist_sims.push_back( nodes_sims[index] );
      }
    }

    cost switching = zero_cost;
    mlist_sims.reserve( list.num_gates() + list.num_pis() + 10 );
    list.foreach_gate( [&]( auto children, auto id ) {

      std::vector<node_simulator_t*> sim_ptrs(children.size());
      //sim_ptrs.emplace_back( &mlist_sims[0] );
      //sim_ptrs.emplace_back( &mlist_sims[1] );

      auto const g = lib[id];
      double sensing = std::numeric_limits<double>::max();
      double arrival = std::numeric_limits<double>::min();
      for( int i = 0; i < children.size(); ++i )
      {
        uint32_t const index = children[i];
        sim_ptrs[i] = &mlist_sims[index];
        double const rise = g.pins[i].rise_block_delay;
        double const fall = g.pins[i].fall_block_delay;
        auto psim = sim_ptrs[children[i]];
        double const child_sensing = mlist_sims[index].get_sensing();
        double const child_arrival = mlist_sims[index].get_arrival();
        sensing = std::min( sensing, child_sensing + std::min( rise, fall ) );
        arrival = std::max( arrival, child_arrival + std::max( rise, fall ) );
      }

      uint32_t const index = mlist_sims.size();
      mlist_sims.emplace_back( ntk.get_null(), sensing, arrival );

      mlist_sims[index]( g, list_simulator, sim_ptrs );
      auto contr = mlist_sims[index].get_dyn_switch();
      switching += contr;
    } );

    //return list.get_area( lib );
    return switching;
  }

  template<class Leaves_t>
  cost evaluate( node const& n, Leaves_t const& leaves )
  {
    cost cost_deref = measure_mffc_deref( n, leaves );
    cost cost_ref = measure_mffc_ref( n, leaves );
    if( cost_ref != cost_deref )
      std::cerr << "[e] different costs " << std::endl;
    return cost_deref;
  }

  cost evaluate_rewiring( node const& n )
  {
    uint32_t index = node_to_sim[n];
    return nodes_sims[index].get_dyn_switch();
  }

  template<class Leaves_t>
  cost measure_mffc_deref( node const& n, Leaves_t const& leaves )
  {
    /* reference cut leaves */
    for ( auto leaf : leaves )
    {
      if( !ntk.is_null( leaf ) )
        ntk.incr_fanout_size( leaf );
    }

    cost mffc_cost = recursive_deref( n );

    /* dereference leaves */
    for ( auto leaf : leaves )
    {
      ntk.decr_fanout_size( leaf );
    }

    return mffc_cost;
  }

  template<class Leaves_t>
  cost measure_mffc_ref( node const& n, Leaves_t const& leaves )
  {
    /* reference cut leaves */
    for ( auto leaf : leaves )
    {
      ntk.incr_fanout_size( leaf );
    }

    cost mffc_cost = recursive_ref( n );

    /* dereference leaves */
    for ( auto leaf : leaves )
    {
      ntk.decr_fanout_size( leaf );
    }

    return mffc_cost;
  }

  cost recursive_deref( node const& n )
  {
    /* terminate? */
    if ( ntk.is_constant( n ) || ntk.is_pi( n ) )
      return zero_cost;
    
    if( !node_to_sim.has( n ) )
    {
      std::cerr << "[e] mffc node not simulated" << std::endl;
    }

    /* recursively collect nodes */

    cost value{ nodes_sims[node_to_sim[n]].get_dyn_switch() };
    ntk.foreach_fanin( n, [&]( auto const& s ) {
      if ( ntk.decr_fanout_size( ntk.get_node( s ) ) == 0 )
      {
        value += recursive_deref( ntk.get_node( s ) );
      }
    } );
    return value;
  }

  cost recursive_ref( node const& n )
  {
    /* terminate? */
    if ( ntk.is_constant( n ) || ntk.is_pi( n ) )
      return zero_cost;

    /* recursively collect nodes */
    cost value{ nodes_sims[node_to_sim[n]].get_dyn_switch() };

    ntk.foreach_fanin( n, [&]( auto const& s ) {
      if ( ntk.incr_fanout_size( ntk.get_node( s ) ) == 0 )
      {
        value += recursive_ref( ntk.get_node( s ) );
      }
    } );
    return value;
  }

  double compare( cost const& current, cost const& candidate )
  {
    return current - candidate;
  }

  double get_time( node const& n ) const
  {
    return arrival.get_time( n );
  }

  template<typename Fn>
  void foreach_gate( Fn&& fn ) const
  {
    for ( int i = 0; i < nodes.size(); i++ )
    {
      fn( nodes[i] );
    }
  }

  void choose_gates()
  {
    if( ps.only_critical )
    {
      arrival.compute_required_times();
    }

    uint32_t const size = pntk->size();
    pntk->foreach_gate( [&]( auto n, auto i ) {
      if( i > size )
      {
        return false;
      }
      if( pntk->is_pi( n ) || pntk->is_constant( n ) )
      {
        return true;
      }

      if ( pntk->is_dead( n ) )
      {
        return true;
      }
      
      if( !ps.only_critical || ( arrival.is_critical( n ) ) )
      {
        nodes.push_back( n );
      }
      return true;
    } );
  }

private:
  Ntk& ntk;
  bindings const lib;

  window_manager<Ntk> win_manager;
  std::array<node_simulator_t, max_leaves> input_sims;
  std::vector<node_simulator_t> nodes_sims;
  std::vector<node_simulator_t> mlist_sims;
  incomplete_node_map<uint32_t, Ntk> node_to_sim;
  std::vector<node> nodes;
  sensing_analyzer<Ntk> sensing;
  arrival_analyzer<Ntk> arrival;

  double dyn_switch;
  double zero_delay;
  list_simulator_t list_simulator;

};

} /* namespace mockturtle */