/* mockturtle: C++ logic network library
 * Copyright (C) 2018-2022  EPFL
 *
 * Permission is hereby granted, free of charge, to any person
 * obtaining a copy of this software and associated documentation
 * files (the "Software"), to deal in the Software without
 * restriction, including without limitation the rights to use,
 * copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following
 * conditions:
 *
 * The above copyright notice and this permission notice shall be
 * included in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
 * OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
 * HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
 * WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 */

/*!
  \file timing.hpp
  \brief Compute timing information of a network.

  This engine can be used for power analysis of mapped network.
  For each node, the following information is stored:
  - The sensing time : the first time at which a transition can happen
  - The sensing time : the first time at which the output is stable
  - A vector of simulation patterns identifying quantized timesteps in this interval
  The class has the following template parameters:
  \param N : number of timesteps used for simulating each signal
  \param I : number of inputs to be used for simulating the static truth table ( 2^I input pairs )

  \author Andrea Costamagna
*/

#pragma once

#include "../../utils/node_map.hpp"
#include "../../algorithms/detail/resub_utils.hpp"
#include "../../algorithms/reconv_cut.hpp"


namespace mockturtle
{

struct window_manager_params
{
  uint32_t skip_fanout_limit_for_divisors{ 100 };
  uint32_t max_num_divisors{ 1000 };
};

template<class Ntk, uint32_t max_pis = 8>
class window_manager
{
public:
  using node = typename Ntk::node;
  using cut_comp = detail::reconvergence_driven_cut_impl<Ntk>;
  using cut_comp_parameters_type = typename cut_comp::parameters_type;
  using cut_comp_statistics_type = typename cut_comp::statistics_type;

public:
  explicit window_manager( Ntk & ntk, window_manager_params ps = {} )
    : ntk( ntk ),
      ps( ps ),
      cuts( ntk, cut_comp_parameters_type{ max_pis }, cuts_st ),
      valid( false )
  {
  }

  bool run( node const& n )
  {
    root = n;
    divs.clear();
    mffc.clear();
    leaves.clear();
    valid = true;

    /* set the flags for storage: visited should be trav_id(),
     * value should be
     * leaves : 0 | ( trav_id() << 2u )
     * mffc : 1 | ( trav_id() << 2u )
     * divs : 2 | ( trav_id() << 2u )
     */
    ntk.incr_trav_id();
    /* find a reconvergence-driven cut */
    leaves = cuts.run( { n } ).first;
    for( auto const& l : leaves )
    {
      make_leaf( l );
      divs.emplace_back( l );
    }

    /* collect the maximum fanout free cone */
    if( !collect_mffc( n ) )
    {
      valid = false;
      return false;
    }

    /* collect the divisors in the tfi */
    if( !collect_divs_tfi( n ) )
    {
      valid = false;
      return false;
    }
    /* TODO: expand divisors */

    if( !collect_divs_sides( n ) )
    {
      valid = false;
      return false;
    }

    return true;
  }

  std::vector<node> const & get_divisors() const
  {
    std::vector<node> const & res = divs;
    return res;
  }

  bool is_leaf( node const& n ) const
  {
    return ntk.value( n ) == ( 0u | ( ntk.trav_id() << 2u ) );
  }

  void make_leaf( node const& n ) const
  {
    ntk.set_value( n, ( 0u | ( ntk.trav_id() << 2u ) ));
  }

  bool is_mffc( node const& n ) const
  {
    return ntk.value( n ) == ( 1u | ( ntk.trav_id() << 2u ) );
  }

  void make_mffc( node const& n ) const
  {
    ntk.set_value( n, ( 1u | ( ntk.trav_id() << 2u ) ));
  }

  bool is_divisor( node const& n ) const
  {
    return ntk.value( n ) == ( 2u | ( ntk.trav_id() << 2u ) );
  }

  void make_divisor( node const& n ) const
  {
    ntk.set_value( n, ( 2u | ( ntk.trav_id() << 2u ) ));
  }

#pragma region Mffc
private:

  bool collect_mffc( node const& n )
  {
    for ( const auto& l : leaves )
      ntk.incr_fanout_size( l );
    /* dereference the node */
    node_deref_rec( n );
    /* reference it back */
    node_ref_rec( n );
    for ( const auto& l : leaves )
      ntk.decr_fanout_size( l );

    return true;
  }

  /* ! \brief Dereference the node's MFFC */
  void node_deref_rec( node const& n )
  {
    if ( ntk.is_pi( n ) )
      return;

    ntk.foreach_fanin( n, [&]( const auto& f ) {
      auto const& p = ntk.get_node( f );

      ntk.decr_fanout_size( p );
      if ( ntk.fanout_size( p ) == 0 )
      {
        node_deref_rec( p );
      }
    } );
    mffc.emplace_back( n );
    make_mffc( n );
  }

  /* ! \brief Reference the node's MFFC */
  void node_ref_rec( node const& n )
  {
    if ( ntk.is_pi( n ) )
      return;

    ntk.foreach_fanin( n, [&]( const auto& f ) {
      auto const& p = ntk.get_node( f );

      auto v = ntk.fanout_size( p );
      ntk.incr_fanout_size( p );
      if ( v == 0 )
      {
        node_ref_rec( p );
      }
    } );
  }
#pragma endregion

#pragma region Divisors
  bool collect_divs_tfi( node const& n )
  {    
    if( is_leaf( n ) )
    {
      return true;
    }
    /* PI and not leaf means error */
    if( ntk.is_pi( n ) )
    {
      return false;
    }
    bool error = false;
    ntk.foreach_fanin( n, [&]( auto fi ){
      node const ni = ntk.get_node( fi );
      error |= collect_divs_tfi( ni );
    } );
    if( !is_mffc( n ) && !is_leaf( n ) )
    {
      divs.emplace_back( n );
      make_divisor( n );
    }
    return error;
  }

  bool collect_divs_sides( node const& n )
  {
    bool quit = false;
    for ( auto i = 0u; i < divs.size(); ++i )
    {
      auto const d = divs.at( i );

      if ( ntk.fanout_size( d ) > ps.skip_fanout_limit_for_divisors )
      {
        continue;
      }
      if ( divs.size() >= ps.max_num_divisors )
      {
        break;
      }

      /* if the fanout has all fanins in the set, add it */
      ntk.foreach_fanout( d, [&]( node const& p ) {
        if ( is_leaf( p ) || is_divisor( p ) )
        {
          return true; /* next fanout */
        }

        bool all_fanins_visited = true;
        ntk.foreach_fanin( p, [&]( const auto& g ) {
          if ( !is_leaf( g ) && !is_divisor( g ) )
          {
            all_fanins_visited = false;
            return false; /* terminate fanin-loop */
          }
          return true; /* next fanin */
        } );

        if ( !all_fanins_visited )
          return true; /* next fanout */

        bool has_root_as_child = false;
        ntk.foreach_fanin( p, [&]( const auto& g ) {
          if ( ntk.get_node( g ) == root )
          {
            has_root_as_child = true;
            return false; /* terminate fanin-loop */
          }
          return true; /* next fanin */
        } );

        if ( has_root_as_child )
        {
          return true; /* next fanout */
        }

        divs.emplace_back( p );
        make_divisor( p );

        /* quit computing divisors if there are too many of them */
        if ( divs.size() >= ps.max_num_divisors )
        {
          quit = true;
          return false; /* terminate fanout-loop */
        }

        return true; /* next fanout */
      } );

      if ( quit )
      {
        break;
      }
    }
    return true;
  }
#pragma endregion

public:
  /*! \brief iterator to apply a lambda to all the nodes */
  template<typename Fn>
  void foreach_leaf( Fn&& fn ) const
  {
    for ( uint32_t i = 0; i < leaves.size(); i ++ )
    {
      fn( leaves[i], i );
    }
  }

  /*! \brief iterator to apply a lambda to all the nodes */
  template<typename Fn>
  void foreach_divisor( Fn&& fn ) const
  {
    for ( uint32_t i = 0; i < divs.size(); i ++ )
    {
      fn( divs[i], i );
    }
  }

  /*! \brief iterator to apply a lambda to all the nodes */
  template<typename Fn>
  void foreach_mffc( Fn&& fn ) const
  {
    for ( uint32_t i = 0; i < mffc.size(); i ++ )
    {
      fn( mffc[i], i );
    }
  }

  bool is_valid() const
  {
    return valid;
  }

private:
  Ntk & ntk;
  cut_comp cuts;
  cut_comp_statistics_type cuts_st;
  window_manager_params ps;

public:
  std::vector<node> leaves;
  std::vector<node> divs;
  std::vector<node> mffc;
  node root;
  bool valid; 
};

} // namespace mockturtle