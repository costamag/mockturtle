/* mockturtle: C++ logic network library
 * Copyright (C) 2018-2023  EPFL
 *
 * Permission is hereby granted, free of charge, to any person
 * obtaining a copy of this software and associated documentation
 * files (the "Software"), to deal in the Software without
 * restriction, including without limitation the rights to use,
 * copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following
 * conditions:
 *
 * The above copyright notice and this permission notice shall be
 * included in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
 * OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
 * HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
 * WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 */

/*!
  \file resynthesize.hpp
  \brief Inplace rewrite

  \author Andrea Costamagna
*/

#pragma once

#include "../windowing/window_manager.hpp"
#include "struct_optimizer.hpp"
#include "window_optimizer.hpp"
#include "simula_optimizer.hpp"
#include "../analyzers/homo_pxx_analyzer.hpp"
#include "../analyzers/homo_xpx_analyzer.hpp"
#include "../analyzers/homo_xxa_analyzer.hpp"
#include "../analyzers/homo_ppa_analyzer.hpp"
#include "../../algorithms/circuit_validator.hpp"
#include "../../views/depth_view.hpp"

#include <fmt/format.h>
#include <kitty/dynamic_truth_table.hpp>
#include <kitty/npn.hpp>
#include <kitty/operations.hpp>
#include <kitty/static_truth_table.hpp>

namespace mockturtle
{

/*! \brief Parameters for Rewrite.
 *
 * The data structure `rewrite_params` holds configurable parameters with
 * default arguments for `rewrite`.
 */
struct resynthesis_params
{
  resynthesis_params()
  {
    /* 0 < Cut limit < 16 */
    cut_enumeration_ps.cut_limit = 8;
    cut_enumeration_ps.minimize_truth_table = true;
  }

  /*! \brief Cut enumeration parameters. */
  cut_enumeration_params cut_enumeration_ps{};

  /*! \brief If true, candidates are only accepted if they do not increase logic depth. */
  bool preserve_depth{ false };

  /*! \brief Allow rewrite with multiple structures */
  bool allow_multiple_structures{ true };

  /*! \brief Allow zero-gain substitutions */
  bool allow_zero_gain{ false };

  /*! \brief Use satisfiability don't cares for optimization. */
  bool use_dont_cares{ false };

  /*! \brief Window size for don't cares calculation. */
  uint32_t window_size{ 8u };

  /*! \brief Be verbose. */
  bool verbose{ false };


  uint32_t max_clauses{ 1000 };
  int32_t odc_levels{ 0 };
  uint32_t conflict_limit{ 1000 };
  uint32_t random_seed{5};

  bool try_struct{true};
  bool try_window{true};
  bool try_simula{true};

  bool dynamic_database{ false };

};

/*! \brief Statistics for rewrite.
 *
 * The data structure `rewrite_stats` provides data collected by running
 * `rewrite`.
 */
struct resynthesis_stats
{
  /*! \brief Total runtime. */
  stopwatch<>::duration time_total{ 0 };

  /*! \brief Expected gain. */
  uint32_t estimated_gain{ 0 };

  /*! \brief Candidates */
  uint32_t candidates{ 0 };

  void report() const
  {
    std::cout << fmt::format( "[i] total time       = {:>5.2f} secs\n", to_seconds( time_total ) );
  }
};

namespace detail
{

template<class Ntk, class Database_t, class Analyzer_t, uint32_t num_vars = 4, uint32_t cube_size = 10, uint32_t max_leaves = 10>
class resynthesize_impl
{
  using node = typename Ntk::node;
  using signal = typename Ntk::signal;
  using network_cuts_t = dynamic_network_cuts<Ntk, num_vars, true, cut_enumeration_rewrite_cut>;
  using cut_manager_t = detail::dynamic_cut_enumeration_impl<Ntk, num_vars, true, cut_enumeration_rewrite_cut>;
  using cut_t = typename network_cuts_t::cut_t;
  using node_data = typename Ntk::storage::element_type::node_type;
  using truth_table_t = kitty::static_truth_table<num_vars>;
  using validator_t = circuit_validator<Ntk, bill::solvers::bsat2, false, true, false>;//last is false

  using struct_optimizer_t = struct_optimizer<Ntk, Database_t, Analyzer_t, num_vars>;
  using window_optimizer_t = window_optimizer<Ntk, Database_t, Analyzer_t, num_vars, max_leaves>;
  using simula_optimizer_t = simula_optimizer<Ntk, Database_t, Analyzer_t, num_vars, cube_size>;

public:
  resynthesize_impl( Ntk& ntk, Database_t & database, resynthesis_params ps )
      : pntk( std::make_shared<Ntk>( ntk ) ),
        database( database ),
        ps( ps ),
        analyzer( ntk ),
        win_manager( ntk ),
        validator( ntk, { ps.max_clauses, ps.odc_levels, ps.conflict_limit, ps.random_seed } )
  {
  }

  void run()
  {
    /* specifications for structural exploration */
    struct_optimizer_params struct_ps;
    struct_ps.dynamic_database = ps.dynamic_database;
    struct_optimizer_stats struct_st;
    struct_optimizer_t struct_opto( (*pntk), database, analyzer, struct_ps, struct_st );

    /* specifications for window-based exploration */
    window_optimizer_params window_ps;
    window_optimizer_stats window_st;
    window_optimizer_t window_opto( (*pntk), database, analyzer, window_ps, window_st );

    /* specifications for window-based exploration */
    simula_optimizer_params simula_ps;
    simula_optimizer_stats simula_st;
    simula_optimizer_t simula_opto( (*pntk), database, analyzer, simula_ps, simula_st );

    int cnt = 0;
    uint32_t size = pntk->size();
    pntk->foreach_gate( [&]( auto n, auto i ) {
      if( cnt > 1 )
      {
        return false;
      }

      if( i > size )
      {
        return false;
      }
      if( pntk->is_pi( n ) || pntk->is_constant( n ) )
      {
        return true;
      }

      if ( pntk->is_dead( n ) )
      {
        return true;
      }

      analyzer( n );

      if( ps.try_struct )
      {
        struct_opto.analyze( n );
        if( struct_opto.has_candidate() )
        {
          uint32_t const entry = struct_opto.get_entry();
          uint32_t const index = struct_opto.get_list();
          auto const leaves = struct_opto.get_leaves();
          signal fnew = database[entry][index].insert( (*pntk), leaves );
          //for( auto l : leaves )
          //  std::cout << l << " ";
          //std::cout << std::endl;
          std::cout << "substitute " << fnew.index << " to " << n << std::endl; 
          pntk->substitute_node( n, fnew );
          update();
          cnt++;
          return true;
        }
      }

      if( ( ps.try_window || ps.try_simula ) && !win_manager.run( n ) )
      {
        std::cerr << "[e] window construction failed" << std::endl;
        return true;
      }

      if( ps.try_window )
      {
        window_opto.analyze( n, win_manager );
        if( window_opto.has_candidate() )
        {
          //std::cout << "window has candidate" << std::endl;
          uint32_t const entry = window_opto.get_entry();
          uint32_t const index = window_opto.get_list();
          auto const leaves = window_opto.get_leaves();
          signal fnew;
          if( entry == -2 )
            fnew = pntk->make_signal( leaves[index] );
          else
            fnew = database[entry][index].insert( (*pntk), leaves );
          //std::cout << "substitute " << fnew << " to " << n << std::endl; 
          pntk->substitute_node( n, fnew );
          update();
          return true;
        }
      }

      if( ps.try_simula )
      {
        simula_opto.analyze( n, win_manager );
        if( simula_opto.has_candidate() )
        {
          //std::cout << "simula has candidate" << std::endl;
          uint32_t const entry = simula_opto.get_entry();
          uint32_t const index = simula_opto.get_list();
          auto const leaves = simula_opto.get_leaves();
          signal fnew = database[entry][index].insert( (*pntk), leaves );
          node nnew = pntk->get_node( fnew );
          if( pntk->is_function( nnew ) )
          {
            auto valid = validator.validate( pntk->make_signal( n ), fnew );
            if( valid )
            {
              if( *valid && n != fnew.index )
              { 
                pntk->substitute_node( n, fnew );
              }
              else
              {
                simula_opto.add_pattern( validator.cex );
                node nnew = pntk->get_node( fnew );
                pntk->take_out_node( nnew );
              }
              update();
            }
          }
          return true;
        }
      }
      return true;
      /* window-based optimization */
      /* signatures-based optimization */
    } );
  }

  void run( std::vector<node> const& nodes )
  {
    /* specifications for structural exploration */
    struct_optimizer_params struct_ps;
    struct_ps.dynamic_database = ps.dynamic_database;
    struct_optimizer_stats struct_st;
    struct_optimizer_t struct_opto( (*pntk), database, analyzer, struct_ps, struct_st );

    /* specifications for window-based exploration */
    window_optimizer_params window_ps;
    window_optimizer_stats window_st;
    window_optimizer_t window_opto( (*pntk), database, analyzer, window_ps, window_st );

    /* specifications for window-based exploration */
    simula_optimizer_params simula_ps;
    simula_optimizer_stats simula_st;
    simula_optimizer_t simula_opto( (*pntk), database, analyzer, simula_ps, simula_st );

    int cnt = 0;
    uint32_t size = pntk->size();
    for( auto n : nodes ) {

      if( pntk->is_pi( n ) || pntk->is_constant( n ) )
      {
        continue;
      }

      if ( pntk->is_dead( n ) )
      {
        continue;
      }

      analyzer( n );

      if( ps.try_struct )
      {
        struct_opto.analyze( n );
        if( struct_opto.has_candidate() )
        {
          uint32_t const entry = struct_opto.get_entry();
          uint32_t const index = struct_opto.get_list();
          auto const leaves = struct_opto.get_leaves();
          signal fnew = database[entry][index].insert( (*pntk), leaves );
          //for( auto l : leaves )
          //  std::cout << l << " ";
          //std::cout << std::endl;
          //std::cout << "substitute " << fnew.index << " to " << n << std::endl; 
          pntk->substitute_node( n, fnew );
          update();
          cnt++;
          continue;
        }
      }

      if( ( ps.try_window || ps.try_simula ) && !win_manager.run( n ) )
      {
        std::cerr << "[e] window construction failed" << std::endl;
        continue;
      }

      if( ps.try_window )
      {
        window_opto.analyze( n, win_manager );
        if( window_opto.has_candidate() )
        {
          //std::cout << "window has candidate" << std::endl;
          uint32_t const entry = window_opto.get_entry();
          uint32_t const index = window_opto.get_list();
          auto const leaves = window_opto.get_leaves();
          signal fnew;
          if( entry == -2 )
            fnew = pntk->make_signal( leaves[index] );
          else
            fnew = database[entry][index].insert( (*pntk), leaves );
          //std::cout << "substitute " << fnew << " to " << n << std::endl; 
          pntk->substitute_node( n, fnew );
          update();
          continue;
        }
      }

      if( ps.try_simula )
      {
        simula_opto.analyze( n, win_manager );
        if( simula_opto.has_candidate() )
        {
          //std::cout << "simula has candidate" << std::endl;
          uint32_t const entry = simula_opto.get_entry();
          uint32_t const index = simula_opto.get_list();
          auto const leaves = simula_opto.get_leaves();
          signal fnew = database[entry][index].insert( (*pntk), leaves );
          node nnew = pntk->get_node( fnew );
          if( pntk->is_function( nnew ) )
          {
            auto valid = validator.validate( pntk->make_signal( n ), fnew );
            if( valid )
            {
              if( *valid && n != fnew.index )
              { 
                pntk->substitute_node( n, fnew );
              }
              else
              {
                simula_opto.add_pattern( validator.cex );
                node nnew = pntk->get_node( fnew );
                pntk->take_out_node( nnew );
              }
              update();
            }
          }
          continue;
        }
      }
      /* window-based optimization */
      /* signatures-based optimization */
    }
  }

  void update()
  {
    if( ps.try_simula )
      validator.update();
  }

private:
  std::shared_ptr<Ntk> pntk;
  Database_t & database;
  Analyzer_t analyzer;
  window_manager<Ntk> win_manager;
  validator_t validator;

  resynthesis_params ps;

};

} /* namespace detail */

/*! \brief Boolean rewrite.
 *
 * This algorithm rewrites enumerated cuts using new network structures from a database.
 * The algorithm performs changes in-place and keeps the substituted structures dangling
 * in the network.
 *
 * **Required network functions:**
 * - `get_node`
 * - `size`
 * - `make_signal`
 * - `foreach_gate`
 * - `substitute_node`
 * - `clear_visited`
 * - `clear_values`
 * - `fanout_size`
 * - `set_value`
 * - `foreach_node`
 *
 * \param ntk Input network (will be changed in-place)
 * \param library Exact library containing pre-computed structures
 * \param ps Rewrite params
 * \param pst Rewrite statistics
 * \param cost_fn Node cost function (a functor with signature `uint32_t(Ntk const&, node<Ntk> const&)`)
 */
template<class Ntk, class Database_t, class Analyzer_t>
void resynthesize( Ntk& ntk, Database_t & database )
{
  resynthesis_params ps;
  using dNtk = depth_view<Ntk>;
  dNtk dntk{ ntk };
  detail::resynthesize_impl<dNtk, Database_t, Analyzer_t> p( dntk, database, ps );
  p.run();
}

template<class Ntk, class Database_t, uint32_t num_vars>
void power_resynthesize( Ntk& ntk, Database_t & database )
{
  using dNtk = depth_view<Ntk>;
  dNtk dntk{ ntk };
  resynthesis_params ps;
  using Analyzer_t = homo_xpx_analyzer<dNtk, num_vars>;
  detail::resynthesize_impl<dNtk, Database_t, Analyzer_t, num_vars> p( dntk, database, ps );
  p.run();
}

template<class Ntk, class Database_t, uint32_t num_vars, uint32_t num_steps, uint32_t cube_size, uint32_t max_leaves>
void delay_resynthesize( Ntk& ntk, Database_t & database, resynthesis_params ps = {} )
{
  using dNtk = depth_view<Ntk>;
  dNtk dntk{ ntk };
  using Analyzer_t = homo_pxx_analyzer<dNtk, num_vars, num_steps, cube_size, max_leaves>;
  detail::resynthesize_impl<dNtk, Database_t, Analyzer_t, num_vars, cube_size, max_leaves> p( dntk, database, ps );
  p.run();
}

template<class Ntk, class Database_t, uint32_t num_vars>
void area_resynthesize( Ntk& ntk, Database_t & database, resynthesis_params ps = {} )
{
  using dNtk = depth_view<Ntk>;
  dNtk dntk{ ntk };
  using Analyzer_t = homo_xxa_analyzer<dNtk, num_vars>;
  detail::resynthesize_impl<dNtk, Database_t, Analyzer_t, num_vars> p( dntk, database, ps );
  p.run();
}

template<class Ntk, class Database_t, uint32_t num_vars, uint32_t num_steps, uint32_t cube_size, uint32_t max_leaves>
void ppa_resynthesize( Ntk& ntk, Database_t & database, resynthesis_params ps = {} )
{
  using dNtk = depth_view<Ntk>;
  dNtk dntk{ ntk };
  using Analyzer_t = homo_ppa_analyzer<dNtk, num_vars, num_steps, cube_size, max_leaves>;
  detail::resynthesize_impl<dNtk, Database_t, Analyzer_t, num_vars, cube_size, max_leaves> p( dntk, database, ps );
  p.run();
}

template<class Ntk, class Database_t, uint32_t num_vars, uint32_t num_steps, uint32_t cube_size, uint32_t max_leaves>
void ppa_resynthesize( Ntk& ntk, Database_t & database, std::vector<typename Ntk::node> const& nodes, resynthesis_params ps = {} )
{
  using dNtk = depth_view<Ntk>;
  dNtk dntk{ ntk };
  using Analyzer_t = homo_ppa_analyzer<dNtk, num_vars, num_steps, cube_size, max_leaves>;
  detail::resynthesize_impl<dNtk, Database_t, Analyzer_t, num_vars> p( dntk, database, ps );
  p.run( nodes );
}



} /* namespace mockturtle */