/* mockturtle: C++ logic network library
 * Copyright (C) 2018-2023  EPFL
 *
 * Permission is hereby granted, free of charge, to any person
 * obtaining a copy of this software and associated documentation
 * files (the "Software"), to deal in the Software without
 * restriction, including without limitation the rights to use,
 * copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following
 * conditions:
 *
 * The above copyright notice and this permission notice shall be
 * included in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
 * OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
 * HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
 * WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 */
 
/*!
  \file struct_optimizer.hpp
  \brief Inplace rewrite

  \author Andrea Costamagna
*/

#pragma once

#include "../../algorithms/cut_enumeration.hpp"
#include "../../algorithms/cut_enumeration/rewrite_cut.hpp"

#include <fmt/format.h>
#include <kitty/dynamic_truth_table.hpp>
#include <kitty/npn.hpp>
#include <kitty/operations.hpp>
#include <kitty/static_truth_table.hpp>

namespace mockturtle
{

/*! \brief Parameters for Rewrite.
 *
 * The data structure `rewrite_params` holds configurable parameters with
 * default arguments for `rewrite`.
 */
struct struct_optimizer_params
{
  struct_optimizer_params()
  {
    /* 0 < Cut limit < 16 */
    cut_enumeration_ps.cut_limit = 8;
    cut_enumeration_ps.minimize_truth_table = true;
  }

  /*! \brief Cut enumeration parameters. */
  cut_enumeration_params cut_enumeration_ps{};

  /*! \brief If true, candidates are only accepted if they do not increase logic depth. */
  bool preserve_depth{ false };

  /*! \brief Allow rewrite with multiple structures */
  bool allow_multiple_structures{ true };

  /*! \brief Allow zero-gain substitutions */
  bool allow_zero_gain{ false };

  /*! \brief Use satisfiability don't cares for optimization. */
  bool use_dont_cares{ false };

  /*! \brief Window size for don't cares calculation. */
  uint32_t window_size{ 8u };

  /*! \brief Be verbose. */
  bool verbose{ false };

  /*! \brief Use satisfiability don't cares for optimization. */
  bool dynamic_database{ false };
};

/*! \brief Statistics for rewrite.
 *
 * The data structure `rewrite_stats` provides data collected by running
 * `rewrite`.
 */
struct struct_optimizer_stats
{
  /*! \brief Total runtime. */
  stopwatch<>::duration time_total{ 0 };

  /*! \brief Expected gain. */
  uint32_t estimated_gain{ 0 };

  /*! \brief Candidates */
  uint32_t candidates{ 0 };

  void report() const
  {
    std::cout << fmt::format( "[i] total time       = {:>5.2f} secs\n", to_seconds( time_total ) );
  }
};

template<class Ntk, class Database_t, class Analyzer_t, uint32_t num_vars>
class struct_optimizer
{
  using node = typename Ntk::node;
  using cost = typename Analyzer_t::cost;
  static constexpr cost zero_cost = Analyzer_t::zero_cost;
  static constexpr cost max_cost = Analyzer_t::max_cost;
  using network_cuts_t = dynamic_network_cuts<Ntk, num_vars, true, cut_enumeration_rewrite_cut>;
  using cut_manager_t = detail::dynamic_cut_enumeration_impl<Ntk, num_vars, true, cut_enumeration_rewrite_cut>;
  using cut_t = typename network_cuts_t::cut_t;
  using node_data = typename Ntk::storage::element_type::node_type;
  using truth_table_t = kitty::static_truth_table<num_vars>;

public:
  struct_optimizer( Ntk & ntk, Database_t & database, Analyzer_t & analyzer, struct_optimizer_params const& ps, struct_optimizer_stats& st )
    : pntk( std::make_shared<Ntk>( ntk ) ),
      database( database ),
      analyzer( analyzer ),
      ps( ps ),
      st( st ),
      cuts( ntk.size() + ( ntk.size() >> 1 ) ),
      cut_manager( ntk, ps.cut_enumeration_ps, cst, cuts ),
      best_list( { -1, -1 } ),
      best_reward( zero_cost )
  {
    init();
  }

  void init()
  {
    cut_manager.init_cuts();
  }

  void analyze( node const& n )
  {
    /* structural optimization */
    cut_manager.clear_cuts( n );
    cut_manager.compute_cuts( n );
    std::array<node, num_vars> leaves;
    std::array<node, num_vars> perm_leaves;
    best_reward = zero_cost;
    for ( auto& cut : cuts.cuts( pntk->node_to_index( n ) ) )
    {
      cost worst_reward = 0;
      /* skip trivial cut */
      if ( ( cut->size() == 1 && *cut->begin() == pntk->node_to_index( n ) ) )
      {
        continue;
      }

      /* extract the cut leaves and functionality */
      fill_leaves( leaves, *cut );
      //auto const heur_curr = analyzer.heuristic_cost( n, leaves );
      auto const cost_curr = analyzer.evaluate( n, leaves );
      std::cout << "cost_curr " << cost_curr << std::endl;
      auto const& func = cuts.truth_table( *cut );
      truth_table_t tt;
      kitty::extend_to_inplace( tt, func );

      /* extract the database entries */
      auto res = database.get_entry( tt );
      if( res )
      {
        auto perm = std::get<0>( *res );
        auto entry = std::get<1>( *res );
        for( int i = 0; i < num_vars; ++i )
        {
          perm_leaves[i] = leaves[perm[i]];
        }

        std::vector<double> times;
        for( int i = 0; i < num_vars; ++i )
        {
          times.push_back( analyzer.get_time( perm_leaves[i] ) );
        }

        database.foreach_list( entry, [&]( auto list, auto index ){
          auto const symm = database.get_symm( entry );
          list.match_times( times, symm );

          //auto heur_cand = analyzer.heuristic_cost( list, perm_leaves );
          cost cost_cand = analyzer.evaluate( list, perm_leaves );
          cost reward = analyzer.compare( cost_curr, cost_cand );
          std::cout << "cost_cand " << cost_cand << std::endl;
          std::cout << "reward    " << reward << std::endl;

          if( ( reward > best_reward ) )
          {
            best_reward = reward;
            best_list = std::make_pair( entry, index );
            best_leaves = perm_leaves;
          }
          else if( reward < worst_reward )
          {
            worst_reward = reward;
          }
        } );
        if( ps.dynamic_database && worst_reward < 0 )
        {
          database.add_entry( *pntk, leaves, pntk->make_signal( n ) );
        }

        if ( cut->size() == 0 || ( cut->size() == 1 && *cut->begin() != pntk->node_to_index( n ) ) )
          break;
      }
      else if( ps.dynamic_database )
      {
        database.add_entry( *pntk, leaves, pntk->make_signal( n ) );
      }
    }

    if( has_candidate() )
    {
     // std::cout << " at node " << n << " R = " << best_reward << std::endl;
    }
  }

  void fill_leaves( std::array<node, num_vars>& leaves, cut_t const& cut )
  {
    int i=0;
    for ( auto const leaf : cut )
    {
      leaves[i++] = pntk->index_to_node( leaf );
    }
    while( i < num_vars )
    {
      leaves[i++] = pntk->get_null();
    }
  }

  void reset()
  {
  }

  bool has_candidate()
  {
    return best_reward > zero_cost;
  }

  cost get_reward() const
  {
    best_reward;
  }

  uint32_t get_entry() const
  {
    return best_list.first;
  }

  uint32_t get_list() const
  {
    return best_list.second;
  }

  std::array<node, num_vars> get_leaves() const
  {
    return best_leaves;
  }

private:
  std::shared_ptr<Ntk> pntk;
  Database_t & database;
  Analyzer_t & analyzer;
  struct_optimizer_params const& ps;
  struct_optimizer_stats & st;
  network_cuts_t cuts;
  cut_manager_t cut_manager;
  cut_enumeration_stats cst;

  std::array<node, num_vars> best_leaves;
  std::pair<uint32_t, uint32_t> best_list;
  cost best_reward;

};

} /* namespace mockturtle */