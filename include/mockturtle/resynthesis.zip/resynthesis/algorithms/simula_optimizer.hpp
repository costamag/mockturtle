/* mockturtle: C++ logic network library
 * Copyright (C) 2018-2023  EPFL
 *
 * Permission is hereby granted, free of charge, to any person
 * obtaining a copy of this software and associated documentation
 * files (the "Software"), to deal in the Software without
 * restriction, including without limitation the rights to use,
 * copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following
 * conditions:
 *
 * The above copyright notice and this permission notice shall be
 * included in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
 * OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
 * HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
 * WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 */
 
/*!
  \file simula_optimizer.hpp
  \brief Inplace rewrite

  \author Andrea Costamagna
*/

#pragma once

#include "../boolean/dependency_cut.hpp"
#include "../boolean/spfd_manager.hpp"
#include "../../algorithms/cut_enumeration.hpp"
#include "../../algorithms/cut_enumeration/rewrite_cut.hpp"

#include <fmt/format.h>
#include <kitty/dynamic_truth_table.hpp>
#include <kitty/npn.hpp>
#include <kitty/operations.hpp>
#include <kitty/static_truth_table.hpp>

namespace mockturtle
{

/*! \brief Parameters for Rewrite.
 *
 * The data structure `rewrite_params` holds configurable parameters with
 * default arguments for `rewrite`.
 */
struct simula_optimizer_params
{
  simula_optimizer_params()
  {
    /* 0 < Cut limit < 16 */
    cut_enumeration_ps.cut_limit = 8;
    cut_enumeration_ps.minimize_truth_table = true;
  }

  /*! \brief Cut enumeration parameters. */
  cut_enumeration_params cut_enumeration_ps{};

  /*! \brief If true, candidates are only accepted if they do not increase logic depth. */
  bool preserve_depth{ false };

  /*! \brief Allow rewrite with multiple structures */
  bool allow_multiple_structures{ true };

  /*! \brief Allow zero-gain substitutions */
  bool allow_zero_gain{ false };

  /*! \brief Use satisfiability don't cares for optimization. */
  bool use_dont_cares{ false };

  /*! \brief Window size for don't cares calculation. */
  uint32_t window_size{ 8u };

  /*! \brief Be verbose. */
  bool verbose{ false };
};

/*! \brief Statistics for rewrite.
 *
 * The data structure `rewrite_stats` provides data collected by running
 * `rewrite`.
 */
struct simula_optimizer_stats
{
  /*! \brief Total runtime. */
  stopwatch<>::duration time_total{ 0 };

  /*! \brief Expected gain. */
  uint32_t estimated_gain{ 0 };

  /*! \brief Candidates */
  uint32_t candidates{ 0 };

  void report() const
  {
    std::cout << fmt::format( "[i] total time       = {:>5.2f} secs\n", to_seconds( time_total ) );
  }
};

template<class Ntk, class Database_t, class Analyzer_t, uint32_t num_vars, uint32_t cube_size>
class simula_optimizer
{
  using node = typename Ntk::node;
  using signal = typename Ntk::signal;
  using cost = typename Analyzer_t::cost;
  static constexpr cost zero_cost = Analyzer_t::zero_cost;
  static constexpr uint32_t extra_space = 20;
  static constexpr uint32_t offset = 2;
  using cut_t = static_dependency_cut<Ntk, num_vars>;
  using network_cuts_t = std::vector<cut_t>;
  using truth_table_t = kitty::static_truth_table<num_vars>;
  using signature_t = kitty::static_truth_table<cube_size>;
  using word_t = kitty::static_truth_table<6u>;

public:
  simula_optimizer( Ntk & ntk, Database_t & database, Analyzer_t & analyzer, simula_optimizer_params const& ps, simula_optimizer_stats& st )
    : ntk( ntk ),
      database( database ),
      analyzer( analyzer ),
      ps( ps ),
      st( st ),
      cuts( extra_space ),
      spfd_manager(),
      best_list( { -1, -1 } ),
      best_reward( zero_cost ),
      node_to_sim( ntk ),
      node_to_word( ntk )
  {
    add_event = ntk.events().register_add_event( [&]( const auto& n ) {
      signal f = ntk.make_signal( n );
      node_to_sim.resize();
      node_to_word.resize();
      simulate_rec( f, node_to_sim, list_simulator_sign );
    } );

    modified_event = ntk.events().register_modified_event( [&]( const auto& n, auto children ) {
      signal f = ntk.make_signal( n );
      node_to_sim.resize();
      node_to_word.resize();
      simulate_rec( f, node_to_sim, list_simulator_sign );
    } );
    init();
  }

  void init()
  {
    /* reserve and initialize the signatures for exhaustive window simulation */
    node_to_sim.resize();
    node_to_word.resize();
    node const n0 = ntk.get_node( ntk.get_constant( false ) );
    node const n1 = ntk.get_node( ntk.get_constant( true ) );
    signature_t sig0;
    word_t word0;
    node_to_sim[n0] = sig0;
    node_to_sim[n1] = ~sig0;
    node_to_word[n0] = word0;
    node_to_word[n1] = ~word0;
    
    std::default_random_engine::result_type seed = 1;

    ntk.foreach_pi( [&]( auto pi, auto ii ){
      kitty::create_random( node_to_sim[pi], seed++ );
      kitty::create_random( node_to_word[pi], seed++ );
    } );

    for( int i = 0; i < num_vars; ++i )
    {
      kitty::create_nth_var( proj_functions[i], i );
    }

    simulate_network( node_to_sim, list_simulator_sign );
  }

  template<class Tt_t>
  void simulate_network( incomplete_node_map<Tt_t, Ntk> & sims, aig_list_simulator<Tt_t> & simulator )
  {
    ntk.incr_trav_id();
    ntk.foreach_po( [&]( auto fo, auto io ){
      simulate_rec( fo, sims, simulator );
    } );  
  }

  template<class Tt_t>
  void simulate_rec( signal f, incomplete_node_map<Tt_t, Ntk> & sims, aig_list_simulator<Tt_t> & simulator )
  {
    node n = ntk.get_node( f );

    if( sims.has( n ) )
      return;

    if( ntk.is_pi( n ) || ( ntk.visited( n ) == ntk.trav_id() ) )
      return;

    std::vector<Tt_t*> sim_ptrs;
    ntk.foreach_fanin( n, [&]( auto fi, auto ii ){
      node ni = ntk.get_node( fi );
      simulate_rec( fi, sims, simulator );

      sim_ptrs.push_back( &sims[ni] );
    } );
    
    auto const alist = ntk.get_binding( n ).list;
    simulator( sims[n], alist, sim_ptrs );
    ntk.set_visited( n, ntk.trav_id() );
  }

  template<class WinManager_t>
  void analyze( node const& n, WinManager_t const& window_manager )
  {
    std::array<node, num_vars> leaves;
    std::array<node, num_vars> perm_leaves;
    best_reward = zero_cost;
    /* terminate if the window is not valid */
    if( !window_manager.is_valid() )
    {
      return;
    }
    if( window_manager.leaves.size() < 2 )
    {
      return;
    }
    if( window_manager.mffc.size() == 1 )
    {
      return;
    }
    if( window_manager.leaves.size() == window_manager.divs.size() )
    {
      return;
    }
    if( !compute_dependency_cuts( n, window_manager ) )
    {
      return;
    }

    for ( auto const& cut : cuts )
    {
      /* extract the cut leaves and functionality */
      auto const leaves = cut.get_leaves();
      auto cost_curr = analyzer.evaluate( n, leaves );
     // std::cout << "cost curr " << cost_curr << std::endl;

      auto const& func = cut.get_function();
      auto const& care = cut.get_careset();

//kitty::print_binary( func );
//std::cout << std::endl;

      /* extract the database entries */
      auto res = database.get_entry( func, care );
      if( res )
      {
        auto perm = std::get<0>( *res );
        auto entry = std::get<1>( *res );

        std::array<uint8_t, num_vars> permutation;
        for ( auto j = 0u; j < num_vars; ++j )
        {
          permutation[perm[j]] = j;
        }

        for( int i = 0; i < num_vars; ++i )
        {
          perm_leaves[permutation[i]] = leaves[i];
        }

      //  for( int i = 0; i < num_vars; ++i )
      //  {
      //    perm_leaves[i] = leaves[perm[i]];
      //  }

//for( int i = 0; i<num_vars; ++i )
//{
//  std::cout << static_cast<uint32_t>( perm[i] ) << " ";
//}
//std::cout << std::endl;

        database.foreach_list( entry, [&]( auto const& list, auto index ){
          //std::cout << " list " << index << std::endl;
          cost cost_cand = analyzer.evaluate( list, leaves );
          //std::cout << "cost cand " << cost_cand << std::endl;
          cost reward = analyzer.compare( cost_curr, cost_cand );
          //std::cout << "R=" << reward << std::endl;
          if( ( reward > best_reward ) )
          {
            best_reward = reward;
            best_list = std::make_pair( entry, index );
            best_leaves = perm_leaves;
          }
        } );
      }

//std::cout << "best reward " << best_reward << std::endl;
    }
  
  
  }

  template<class WinManager_t>
  bool compute_dependency_cuts( node n, WinManager_t const& window_manager )
  {
    /* prepare the data */
    cuts.clear();
    /* call greedy support selection */
    return greedy_support_selection( n, window_manager );
  }

  template<class WinManager_t>
  bool greedy_support_selection( node const& n, WinManager_t const& window_manager )
  {
    /* initialize the spfd manager */
    signature_t const & sign = node_to_sim[n];
    spfd_manager.init( sign );
    /* prepare the data */
    std::array<node, num_vars> leaves;
    auto min_cost = spfd_manager.get_num_edges();
    node candidate = ntk.get_null();
    int cnt = 0;
    while( !spfd_manager.is_covered() && !spfd_manager.is_saturated() )
    {
      window_manager.foreach_divisor( [&]( auto d, auto i ){
        signature_t const& sig = node_to_sim[d];
        auto const cost_div = spfd_manager.evaluate( sig );
        if( cost_div < min_cost )
        {
          min_cost = cost_div;
          candidate = d;
        }
      } );
      signature_t const& sig = node_to_sim[candidate];
      spfd_manager.update( sig );
      leaves[cnt++] = candidate;
    }
    if( spfd_manager.is_covered() )
    {
      while( cnt < num_vars )
      {
        leaves[cnt++] = ntk.get_null();
      }
      auto [func, care] = compute_function( n, leaves );
      cuts.emplace_back( n, leaves, func, care );
    }
    return true;
  }

  std::tuple<truth_table_t, truth_table_t> compute_function( node const& n, std::array<node, num_vars> const& leaves )
  {
    signature_t const& root_signature = node_to_sim[n];

    uint32_t num_minterms = 1u << num_vars;
    truth_table_t func;
    truth_table_t care;
    truth_table_t temp;
    func ^= func;
    care ^= care;
    signature_t mask;
    for( uint32_t m = 0; m < num_minterms; ++m )
    {
      mask |= ~mask;
      temp |= ~temp;
      for( uint32_t v = 0; v < num_vars; ++v )
      {
        if( !ntk.is_null( leaves[v] ) )
        {
          signature_t const& sig = node_to_sim[leaves[v]];
          bool polarity = ( m >> v ) & 0x1 > 0;
          mask &= polarity ? sig : ~sig;
          temp &= polarity ? proj_functions[v] : ~proj_functions[v];
        }
      }
      if( kitty::count_ones( mask ) == 0 )
      {
        care |= temp;
      }
      if( kitty::count_ones( mask & root_signature ) > 0 )
      {
        func |= temp;
      }
    }
    return std::make_tuple( func, care );
  }

public:
  bool has_candidate()
  {
    return best_reward > zero_cost;
  }

  cost get_reward() const
  {
    best_reward;
  }

  uint32_t get_entry() const
  {
    return best_list.first;
  }

  uint32_t get_list() const
  {
    return best_list.second;
  }

  std::array<node, num_vars> get_leaves() const
  {
    return best_leaves;
  }

  void add_pattern( std::vector<bool> const& cex )
  {
    uint32_t bit = num_cex - 1;
    ntk.foreach_pi( [&]( auto pi, auto ii ){
      if( cex[ii] )
        kitty::set_bit( node_to_word[pi], bit );
      else
        kitty::clear_bit( node_to_word[pi], bit );
    } );
    num_cex++;
    if( ( num_cex % 64u ) == 0 )
    {
      simulate_network( node_to_word, list_simulator_word );
    }
    uint32_t const num_blocks = 1u << ( cube_size - 6u );
    uint32_t block = ( num_cex / 64 ) % num_blocks;
  }

private:
  Ntk& ntk;
  Database_t & database;
  Analyzer_t & analyzer;
  simula_optimizer_params const& ps;
  simula_optimizer_stats & st;
  network_cuts_t cuts;
  spfd_manager_t<cube_size, num_vars> spfd_manager;
  cut_enumeration_stats cst;

  incomplete_node_map<signature_t, Ntk> node_to_sim;
  incomplete_node_map<word_t, Ntk> node_to_word;

  aig_list_simulator<signature_t> list_simulator_sign;
  aig_list_simulator<word_t> list_simulator_word;

  uint32_t num_cex = 1;

  std::array<truth_table_t, num_vars> proj_functions;
  std::array<node, num_vars> best_leaves;
  std::pair<uint32_t, uint32_t> best_list;
  cost best_reward;

  /* events */
  std::shared_ptr<typename network_events<Ntk>::add_event_type> add_event;
  std::shared_ptr<typename network_events<Ntk>::modified_event_type> modified_event;

};

} /* namespace mockturtle */