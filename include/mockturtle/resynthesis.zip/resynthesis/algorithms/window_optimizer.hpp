/* mockturtle: C++ logic network library
 * Copyright (C) 2018-2023  EPFL
 *
 * Permission is hereby granted, free of charge, to any person
 * obtaining a copy of this software and associated documentation
 * files (the "Software"), to deal in the Software without
 * restriction, including without limitation the rights to use,
 * copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following
 * conditions:
 *
 * The above copyright notice and this permission notice shall be
 * included in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
 * OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
 * HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
 * WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 */
 
/*!
  \file window_optimizer.hpp
  \brief Inplace rewrite

  \author Andrea Costamagna
*/

#pragma once

#include "../boolean/dependency_cut.hpp"
#include "../boolean/spfd_manager.hpp"
#include "../../algorithms/cut_enumeration.hpp"
#include "../../algorithms/cut_enumeration/rewrite_cut.hpp"

#include <fmt/format.h>
#include <kitty/dynamic_truth_table.hpp>
#include <kitty/npn.hpp>
#include <kitty/operations.hpp>
#include <kitty/static_truth_table.hpp>

namespace mockturtle
{

/*! \brief Parameters for Rewrite.
 *
 * The data structure `rewrite_params` holds configurable parameters with
 * default arguments for `rewrite`.
 */
struct window_optimizer_params
{
  window_optimizer_params()
  {
    /* 0 < Cut limit < 16 */
    cut_enumeration_ps.cut_limit = 8;
    cut_enumeration_ps.minimize_truth_table = true;
  }

  /*! \brief Cut enumeration parameters. */
  cut_enumeration_params cut_enumeration_ps{};

  /*! \brief If true, candidates are only accepted if they do not increase logic depth. */
  bool preserve_depth{ false };

  /*! \brief Allow rewrite with multiple structures */
  bool allow_multiple_structures{ true };

  /*! \brief Allow zero-gain substitutions */
  bool allow_zero_gain{ false };

  /*! \brief Use satisfiability don't cares for optimization. */
  bool use_dont_cares{ false };

  /*! \brief Window size for don't cares calculation. */
  uint32_t window_size{ 8u };

  /*! \brief Be verbose. */
  bool verbose{ false };
};

/*! \brief Statistics for rewrite.
 *
 * The data structure `rewrite_stats` provides data collected by running
 * `rewrite`.
 */
struct window_optimizer_stats
{
  /*! \brief Total runtime. */
  stopwatch<>::duration time_total{ 0 };

  /*! \brief Expected gain. */
  uint32_t estimated_gain{ 0 };

  /*! \brief Candidates */
  uint32_t candidates{ 0 };

  void report() const
  {
    std::cout << fmt::format( "[i] total time       = {:>5.2f} secs\n", to_seconds( time_total ) );
  }
};

template<class Ntk, class Database_t, class Analyzer_t, uint32_t num_vars, uint32_t max_leaves>
class window_optimizer
{
  using node = typename Ntk::node;
  using cost = typename Analyzer_t::cost;
  static constexpr cost zero_cost = Analyzer_t::zero_cost;
  static constexpr uint32_t extra_space = 20;
  static constexpr uint32_t offset = 2;
  using cut_t = static_dependency_cut<Ntk, num_vars>;
  using network_cuts_t = std::vector<cut_t>;
  using truth_table_t = kitty::static_truth_table<num_vars>;
  using signature_t = kitty::static_truth_table<max_leaves>;

public:
  window_optimizer( Ntk & ntk, Database_t & database, Analyzer_t & analyzer, window_optimizer_params const& ps, window_optimizer_stats& st )
    : ntk( ntk ),
      database( database ),
      analyzer( analyzer ),
      ps( ps ),
      st( st ),
      cuts( extra_space ),
      spfd_manager(),
      sims( max_leaves + extra_space ),
      best_list( { -1, -1 } ),
      best_reward( zero_cost ),
      node_to_sim( ntk )
  {
    init();
  }

  void init()
  {
    /* reserve and initialize the signatures for exhaustive window simulation */
    sims.resize( max_leaves + offset );
    sims[0] = sims[0]^sims[0];
    sims[1] = ~sims[0];
    for( int i = 0; i < max_leaves; ++i )
    {
      kitty::create_nth_var( sims[offset+i], i );
    }

    for( int i = 0; i < num_vars; ++i )
    {
      kitty::create_nth_var( proj_functions[i], i );
    }
  }

  template<class WinManager_t>
  void analyze( node const& n, WinManager_t const& window_manager )
  {
    std::array<node, num_vars> leaves;
    std::array<node, num_vars> perm_leaves;
    std::array<node, num_vars> permutation;
    best_reward = zero_cost;
    /* terminate if the window is not valid */
    if( !window_manager.is_valid() )
    {
      return;
    }
    if( window_manager.leaves.size() < 2 )
    {
      return;
    }
    if( window_manager.mffc.size() == 1 )
    {
      return;
    }
    if( window_manager.leaves.size() == window_manager.divs.size() )
    {
      return;
    }
    simulate_window( window_manager );

    if( !compute_dependency_cuts( n, window_manager ) )
    {
      return;
    }

    for ( auto const& cut : cuts )
    {
      /* extract the cut leaves and functionality */
      auto const leaves = cut.get_leaves();
//      for( int i = 0; i < num_vars; ++i )
//        std::cout << leaves[i] << " ";
//      std::cout << std::endl;
      auto cost_curr = analyzer.evaluate( n, window_manager.leaves );
//      std::cout << "cost curr " << cost_curr << std::endl;

      auto const& func = cut.get_function();
      auto const& care = cut.get_careset();

      std::vector<uint32_t> dont_cares;
      for( int m = 0; m < func.num_bits(); ++m )
      {
        if( kitty::get_bit( care, m ) == 0 )
          dont_cares.push_back( m );
      }
      uint32_t const num_funcs = 1u << dont_cares.size();

      for( uint32_t m = 0; m < num_funcs; ++m )
      {
        truth_table_t onset = func & care;
        truth_table_t tmp = onset | ~onset;;
        for( int dc = 0; dc < dont_cares.size(); ++dc )
        {
          if( ( m >> dc ) & 0x1 == 0x1 )
            tmp &= proj_functions[dc];
          else
            tmp &= ~proj_functions[dc];
        }
        onset |= ( ( ~care ) & tmp );
//kitty::print_binary( onset );
//std::cout << std::endl;
        auto ttnew = onset;
        auto supp = kitty::min_base_inplace( onset );
        int cnt = 0;
        for( int j{0}; j < num_vars; ++j )
        {
          if( !ntk.is_null(leaves[j]) )
          {
            cnt++;
            uint32_t index_leaf = node_to_sim[leaves[j]];
            auto tt_leaf = sims[index_leaf];
            uint32_t index_root = node_to_sim[n];
            auto tt_root = sims[index_root];
            if( kitty::equal( tt_root, tt_leaf ) )
            {
              cost cost_cand = analyzer.evaluate_rewiring( leaves[j] );
          //    std::cout << "cost cand rew " << cost_cand << std::endl;
              cost reward = analyzer.compare( cost_curr, cost_cand );
          //    std::cout << "R rew=" << reward << std::endl;
              if( ( reward > best_reward ) )
              {
                best_reward = reward;
                best_list = std::make_pair( -2, j );
                best_leaves = leaves;
              }
            }
          }
        }
        if( cnt != supp.size() )
        {
         // printf("this is an optimization opp\n");
          continue;
        }

        /* extract the database entries */
        auto res = database.get_entry( onset );
        if( res )
        {
          auto perm = std::get<0>( *res );
          auto entry = std::get<1>( *res );

          std::array<uint8_t, num_vars> permutation;
          for ( auto j = 0u; j < num_vars; ++j )
          {
            permutation[perm[j]] = j;
          }

          for( int i = 0; i < num_vars; ++i )
          {
            perm_leaves[permutation[i]] = leaves[i];
          }

//for( int i = 0; i<num_vars; ++i )
//{
//  std::cout << static_cast<uint32_t>( perm[i] ) << " ";
//}
//std::cout << std::endl;


          database.foreach_list( entry, [&]( auto const& list, auto index ){
//            std::cout << " list " << index << std::endl;
            cost cost_cand = analyzer.evaluate( list, leaves );
//            std::cout << "cost cand " << cost_cand << std::endl;
            cost reward = analyzer.compare( cost_curr, cost_cand );
//            std::cout << "R=" << reward << std::endl;
            if( ( reward > best_reward ) )
            {
              best_reward = reward;
              best_list = std::make_pair( entry, index );
              best_leaves = perm_leaves;
            }
          } );
        }
      }

//std::cout << "best reward " << best_reward << std::endl;
    }
  
  }

private:
  template<class WinManager_t>
  bool simulate_window( WinManager_t const& window_manager )
  {
    node_to_sim.resize();
    sims.resize( max_leaves + offset );
    window_manager.foreach_leaf( [&]( node const& l, uint32_t index ){
      node_to_sim[l] = offset + index; 
    } );

    std::vector<signature_t*> sim_ptrs;
    window_manager.foreach_divisor( [&]( node const& d, uint32_t index ){
      if( !window_manager.is_leaf( d ) )
      {
        sim_ptrs.clear();
        ntk.foreach_fanin( d, [&]( auto fi, auto ii ){
          node const ni = ntk.get_node( fi );
          uint32_t const index = node_to_sim[ni];
          sim_ptrs.push_back( &sims[index] );
        } );
        uint32_t const index = sims.size();
        node_to_sim[d] = index;
        sims.emplace_back();
        auto const alist = ntk.get_binding( d ).list;
        list_simulator( sims[index], alist, sim_ptrs );
      }
    } );

    window_manager.foreach_mffc( [&]( node const& m, uint32_t index ){
      if( !window_manager.is_leaf( m ) )
      {
        sim_ptrs.clear();
        ntk.foreach_fanin( m, [&]( auto fi, auto ii ){
          node const ni = ntk.get_node( fi );
          uint32_t const index = node_to_sim[ni];
          sim_ptrs.push_back( &sims[index] );
        } );
        uint32_t const index = sims.size();
        node_to_sim[m] = index;
        sims.emplace_back();
        auto const alist = ntk.get_binding( m ).list;
        list_simulator( sims[index], alist, sim_ptrs );
      }
    } );

  }

  template<class WinManager_t>
  bool compute_dependency_cuts( node n, WinManager_t const& window_manager )
  {
    /* prepare the data */
    cuts.clear();
    /* call greedy support selection */
    return greedy_support_selection( n, window_manager );
  }

  template<class WinManager_t>
  bool greedy_support_selection( node const& n, WinManager_t const& window_manager )
  {
    /* initialize the spfd manager */
    uint32_t index = node_to_sim[n];
    signature_t const & sign = sims[index];
    spfd_manager.init( sign );
    /* prepare the data */
    std::array<node, num_vars> leaves;
    auto min_cost = spfd_manager.get_num_edges();
    node candidate = ntk.get_null();
    int cnt = 0;
    while( !spfd_manager.is_covered() && !spfd_manager.is_saturated() )
    {
      window_manager.foreach_divisor( [&]( auto d, auto i ){
        uint32_t const index = node_to_sim[d];
        signature_t const& sig = sims[index];
        auto const cost_div = spfd_manager.evaluate( sig );
        if( cost_div < min_cost )
        {
          min_cost = cost_div;
          candidate = d;
        }
      } );
      uint32_t const index = node_to_sim[candidate];
      signature_t const& sig = sims[index];
      spfd_manager.update( sig );
      leaves[cnt++] = candidate;
    }
    if( spfd_manager.is_covered() )
    {
      while( cnt < num_vars )
      {
        leaves[cnt++] = ntk.get_null();
      }
      auto [func, care] = compute_function( n, leaves );
      cuts.emplace_back( n, leaves, func, care );
    }
    return true;
  }

  template<class WinManager_t>
  bool pivot_support_selection( node const& n, WinManager_t const& window_manager )
  {

    window_manager.foreach_divisor( [&]( auto piv, auto ipiv ){
      /* initialize the spfd manager */
      uint32_t index = node_to_sim[n];
      signature_t const & sign = sims[index];
      spfd_manager.init( sign );
      /* prepare the data */
      std::array<node, num_vars> leaves;
  
      node candidate = ntk.get_null();
      int cnt = 0;
      uint32_t const piv_index = node_to_sim[piv];
      signature_t const& sig = sims[piv_index];
      leaves[cnt++] = piv;
      spfd_manager.update( sig );
      auto min_cost = spfd_manager.get_num_edges();

      while( !spfd_manager.is_covered() && !spfd_manager.is_saturated() )
      {
        window_manager.foreach_divisor( [&]( auto d, auto i ){
          uint32_t const index = node_to_sim[d];
          signature_t const& sig = sims[index];
          auto const cost_div = spfd_manager.evaluate( sig );
          if( cost_div < min_cost )
          {
            min_cost = cost_div;
            candidate = d;
          }
        } );
        uint32_t const index = node_to_sim[candidate];
        signature_t const& sig = sims[index];
        spfd_manager.update( sig );
        leaves[cnt++] = candidate;
      }
      if( spfd_manager.is_covered() )
      {
        while( cnt < num_vars )
        {
          leaves[cnt++] = ntk.get_null();
        }
        auto [func, care] = compute_function( n, leaves );
        cuts.emplace_back( n, leaves, func, care );
        return true;
      }

    } );
    return true;
  }

  std::tuple<truth_table_t, truth_table_t> compute_function( node const& n, std::array<node, num_vars> const& leaves )
  {
    uint32_t const index = node_to_sim[n];
    signature_t const& root_signature = sims[index];

    uint32_t num_minterms = 1u << num_vars;
    truth_table_t func;
    truth_table_t care;
    truth_table_t temp;
    func ^= func;
    care ^= care;
    signature_t mask;
    for( uint32_t m = 0; m < num_minterms; ++m )
    {
      mask |= ~mask;
      temp |= ~temp;
      for( uint32_t v = 0; v < num_vars; ++v )
      {
        if( !ntk.is_null( leaves[v] ) )
        {
          uint32_t index = node_to_sim[leaves[v]];
          signature_t const& sig = sims[index];
          bool polarity = ( m >> v ) & 0x1 > 0;
          mask &= polarity ? sig : ~sig;
          temp &= polarity ? proj_functions[v] : ~proj_functions[v];
        }
      }
      if( kitty::count_ones( mask ) != 0 )
      {
        care |= temp;
      }
      if( kitty::count_ones( mask & root_signature ) > 0 )
      {
        func |= temp;
      }
    }
    return std::make_tuple( func, care );
  }

public:
  bool has_candidate()
  {
    return best_reward > zero_cost;
  }

  cost get_reward() const
  {
    best_reward;
  }

  uint32_t get_entry() const
  {
    return best_list.first;
  }

  uint32_t get_list() const
  {
    return best_list.second;
  }

  std::array<node, num_vars> get_leaves() const
  {
    return best_leaves;
  }

private:
  Ntk& ntk;
  Database_t & database;
  Analyzer_t & analyzer;
  window_optimizer_params const& ps;
  window_optimizer_stats & st;
  network_cuts_t cuts;
  spfd_manager_t<max_leaves, num_vars> spfd_manager;
  std::vector<signature_t> sims;
  cut_enumeration_stats cst;
  incomplete_node_map<uint32_t, Ntk> node_to_sim;
  aig_list_simulator<signature_t> list_simulator;

  std::array<truth_table_t, num_vars> proj_functions;
  std::array<node, num_vars> best_leaves;
  std::pair<uint32_t, uint32_t> best_list;
  cost best_reward;

};

} /* namespace mockturtle */