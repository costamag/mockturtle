/* mockturtle: C++ logic network library
 * Copyright (C) 2018-2023  EPFL
 *
 * Permission is hereby granted, free of charge, to any person
 * obtaining a copy of this software and associated documentation
 * files (the "Software"), to deal in the Software without
 * restriction, including without limitation the rights to use,
 * copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following
 * conditions:
 *
 * The above copyright notice and this permission notice shall be
 * included in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
 * OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
 * HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
 * WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 */

/*!
  \file mapped_list.hpp
  \brief Index list for mapped networks

  \author Andrea Costamagna
*/

#pragma once

#include <vector>

#include <kitty/hash.hpp>
#include <kitty/constructors.hpp>

#include <parallel_hashmap/phmap.h>

#include "homo_storage.hpp"
#include "mapped_list.hpp"
#include "../list_simulator.hpp"
#include "../mapped_list_simulator.hpp"
#include "../networks/bindings.hpp"

namespace mockturtle
{
  /*! \brief Homogeneous database 
   * Homogeneous database, all the functionalities are represented
   * using static truth tables with num_vars inputs
   */
  template<uint32_t num_vars, uint32_t capacity = 1>
  class homo_database
  {
    /* each database entry  */
    using TT = kitty::static_truth_table<num_vars>;
    using tt_hash = kitty::hash<TT>;
    using simulator_t = mapped_list_simulator<bindings, TT>;
    using storage_t = homo_storage<num_vars, capacity>;
    using entry_t = typename storage_t::entry_t;
  
  public:
    homo_database( bindings const& gates )
      :  lib( gates ), simulator( gates )
    {
      proj_fns.reserve( num_vars );
      for( int i{0}; i < num_vars; ++i )
      {
        proj_fns.emplace_back();
        kitty::create_nth_var( proj_fns[i], i );
      }
    }

    homo_database<num_vars> & get_database()
    {
      return (*this);
    }

    entry_t * get_supergates( TT const& tt )
    {
      auto match = storage.find( tt );
      if ( match != storage.end() )
        return &match->second;
      return nullptr;
    }

    entry_t * get_supergates( TT const& tt, TT const& dc, uint32_t& phase, std::vector<uint8_t>& perm )
    {
      auto match = storage.find( tt );
      if ( match != storage.end() )
        return &match->second;
      return nullptr;
    }

    entry_t const& operator[]( uint32_t index ) const
    {
      return storage[index];
    }

    bindings get_bindings() const
    {
      return lib;
    }

    /*! \brief add a database entry after p-canonization */
    template<class Ntk>
    void add_entry( Ntk & ntk, std::array<typename Ntk::node, num_vars> const& cut, typename Ntk::signal f )
    {
      /* construct the mapped list */
      mapped_list list( ntk, lib, cut, f );
      TT res;
      /* get its functionaliy */
      simulator( res, list, proj_fns );
      /* P-canonization */
      auto config = kitty::exact_p_canonization( res );
      auto tt_p = std::get<0>( config );
      auto perm = std::get<2>( config );
      /* permute the inputs to match the function */
      list.permute_inputs( perm );
      /* get the new functionality */
      simulator( res, list, proj_fns );

      if( !kitty::equal( res, tt_p ) )
      {
        kitty::print_binary( res ); std::cout << std::endl;
        kitty::print_binary( tt_p ); std::cout << std::endl;
        std::cerr << "[e] different tables" << std::endl;
      }
      assert( kitty::equal( res, tt_p ) );
      /* T-canonization */
      auto tperm = t_canonization( list, res );
      list.permute_inputs( tperm );
      TT res2;
      simulator( res2, list, proj_fns );
      if( !kitty::equal( res2, res ) )
      {
        std::cerr << "[e] different tables after T-canonization" << std::endl;
      }

      /* update the database */
      storage.add_entry( tt_p, list );
    }

    std::vector<uint8_t> t_canonization( mapped_list const& mlist, TT const& tt )
    {
      std::array<uint8_t, num_vars> symm;
      for( uint8_t i{0}; i < num_vars; ++i )
      {
        symm[i] = ( 1u << i );
        for( uint8_t j{ 0 }; j < num_vars; ++j )
        {
          if( i == j )
            continue;
          TT const tt01 = kitty::cofactor0( kitty::cofactor1( tt, i ), j );
          TT const tt10 = kitty::cofactor1( kitty::cofactor0( tt, i ), j );
          if( kitty::equal( tt01, tt10 ) )
          {
            symm[i] |= ( 1u << j );
            symm[j] |= ( 1u << i );
          }
        }
      }
      /* now I have all the symmetries */
      auto pin_delays = mlist.get_pin_delays();
      std::vector<uint8_t> res;
      for( uint8_t p = 0; p < num_vars; ++p )
      {
        res.push_back( p );
      }
      for( uint8_t i{0}; i < num_vars; ++i )
      {
        std::vector<std::pair<uint8_t, double>> unsort_group;
        uint8_t simmetry = symm[i];
        for( uint8_t j{ 0 }; j < num_vars; ++j )
        {
          if( ( ( simmetry >> j ) & 0x1 ) == 0x1 )
            unsort_group.push_back( std::make_pair( j, pin_delays[j] ) );
        }
        std::vector<std::pair<uint8_t, double>> sorted_group = unsort_group;
        std::stable_sort( sorted_group.begin(), sorted_group.end(), [&]( auto a, auto b ){
          return a.second > b.second;
        } );
//for( auto p : unsort_group )
//{
//  uint32_t lit = static_cast<uint32_t>( p.first );
//  std::cout << "[" << lit << " " << p.second << "]";
//}
//std::cout << std::endl;

//        for( auto p : sorted_group )
//        {
//          uint32_t lit = static_cast<uint32_t>( p.first );
//          std::cout << "[" << lit << " " << p.second << "]";
//        }
//        std::cout << std::endl;

        for( int k = 0; k < sorted_group.size(); ++k )
        {
          res[unsort_group[k].first] = sorted_group[k].first;
        }

        for( uint8_t j{ i }; j < num_vars; ++j )
        {
          symm[j] &= ~simmetry;
        }
      }
      return res;
    }

    /*! \brief extract the database entry matching the function */
    std::optional<std::tuple<std::vector<uint8_t>, uint32_t>> get_entry( TT const& tt )
    {
      auto config = kitty::exact_p_canonization( tt );
      auto tt_p = std::get<0>( config );
      auto perm = std::get<2>( config );

      auto match = storage.find( tt_p );
      if ( match == storage.end() )
      {
        return std::nullopt;
      }
      else // TODO: add the reward-based check
      {
        uint32_t index = match->second;
        return std::make_tuple( perm, index );
      }
    }

    /*! \brief extract the database entry matching the function */
    std::optional<std::tuple<std::vector<uint8_t>, uint32_t>> get_entry( TT const& tt, TT const& care )
    {
      (void)care;

      auto config = kitty::exact_p_canonization( tt );
      auto tt_p = std::get<0>( config );
      auto perm = std::get<2>( config );

      auto match = storage.find( tt_p );
      if ( match == storage.end() )
      {
        return std::nullopt;
      }
      else // TODO: add the reward-based check
      {
        uint32_t index = match->second;
        return std::make_tuple( perm, index );
      }
    }

    /*! \brief iterator to apply a lambda to all the nodes */
    template<typename Fn>
    void foreach_list( uint32_t index, Fn&& fn ) const
    {
      storage[index].foreach_list( fn );
    }

    /*! \brief iterator to apply a lambda to all the nodes */
    template<typename Fn>
    void foreach_entry( Fn&& fn ) const
    {
      storage.foreach_entry( fn );
    }

    void print()
    {
      foreach_entry( [&]( auto entry, auto ientry ){
        std::cout << "Entry " << ientry << std::endl;
        entry.foreach_list( [&]( auto list, auto ilist ){
          list.print();
        } );
      } );
    }

    auto get_symm( uint32_t entry_index )
    {
      auto entry = storage[entry_index];
      return entry.get_symm();
    }


    /* store the nodes  */
    storage_t storage;
    std::vector<TT> proj_fns;
    simulator_t simulator;
    bindings lib;
  };

} // namespace mockturtle