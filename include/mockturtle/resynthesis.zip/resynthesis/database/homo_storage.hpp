/* mockturtle: C++ logic network library
 * Copyright (C) 2018-2023  EPFL
 *
 * Permission is hereby granted, free of charge, to any person
 * obtaining a copy of this software and associated documentation
 * files (the "Software"), to deal in the Software without
 * restriction, including without limitation the rights to use,
 * copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following
 * conditions:
 *
 * The above copyright notice and this permission notice shall be
 * included in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
 * OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
 * HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
 * WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 */

/*!
  \file mapped_list.hpp
  \brief Index list for mapped networks

  \author Andrea Costamagna
*/

#pragma once

#include <vector>

#include <kitty/hash.hpp>
#include <kitty/constructors.hpp>

#include <parallel_hashmap/phmap.h>

#include "mapped_list.hpp"
#include "../list_simulator.hpp"
#include "../mapped_list_simulator.hpp"
#include "../networks/bindings.hpp"

namespace mockturtle
{
  template<uint32_t num_vars, uint32_t capacity>
  class homo_entry
  {
    using TT = kitty::static_truth_table<num_vars>;
  public:
    homo_entry( TT const& tt ):
    cnt( 0 )
    {
      for( uint32_t i{0}; i < num_vars - 1; ++i )
      {
        symm[i] |= ( 1u << i );
        for( uint32_t j{ i + 1 }; j < num_vars; ++j )
        {
          TT const tt01 = kitty::cofactor0( kitty::cofactor1( tt, i ), j );
          TT const tt10 = kitty::cofactor1( kitty::cofactor0( tt, i ), j );
          if( kitty::equal( tt01, tt10 ) )
          {
            symm[i] |= ( 1u << j );
            symm[j] |= ( 1u << i );
          }
        }
      }
    }

    auto get_symm()
    {
      return symm;
    }

    size_t size()
    {
      return cnt;
    }

    void insert( mapped_list const& list )
    {
      if( cnt < capacity )
      {
        bool dominates = true;
        bool dominated = true;
        auto this_delays = list.get_pin_delays();

        for( int i = 0; i < cnt ; ++i )
        {
          auto other = data[i];
          auto other_delays = other.get_pin_delays();
          for( int t=0; t<this_delays.size(); ++t )
          {
            printf("-t%5.2f o%5.2f-", this_delays[t], other_delays[t] );
            if( other_delays[t] < this_delays[t] )
            {
              dominates = false;
            }
            else if( other_delays[t] > this_delays[t] )
            {
              dominated = false;
            }
          }
          if( dominated && dominates )
          {
            // we found an equivalent one. return for now
            return;
          }
          else
          {
            if( dominates && ~dominated ) // replace this and return 
            {
              printf("dominating\n");
              data[i] = list;
              return;
            }
            else if( dominated && ~dominates ) // the other is better
            {
              return;
            }
            else
            {
              // dominated and dominates, there is a miture of thisngs, one could be better for some arrival
            }
          }
        }
        /* if you are here there is some noveltyy in the function */
        data.push_back( list );
        cnt++;
      }
    }

    /*! \brief iterator to apply a lambda to all the nodes */
    template<typename Fn>
    void foreach_list( Fn&& fn ) const
    {
      for ( int i = 0; i < cnt; i++ )
      {
        fn( data[i], i );
      }
    }

  mapped_list const& operator[]( uint32_t index ) const
  {
    mapped_list const & list = data[index];
    return list;
  }

  private:
    std::vector<mapped_list> data;
    size_t cnt;
    std::array<uint32_t, num_vars> symm;
  };

  template<uint32_t num_vars, uint32_t capacity = 1>
  class homo_storage
  {
  public:
    using TT = kitty::static_truth_table<num_vars>;
    using tt_hash = kitty::hash<TT>;
    using entry_t = homo_entry<num_vars, capacity>;

  void add_entry( TT const& tt, mapped_list const& list )
  {
    auto match = find( tt );
    if ( match == end() )
    {
      uint32_t index = data.size();
      tt_to_index[tt] = index;
      data.emplace_back( tt );
      data[index].insert( list );
    }
    else // TODO: add the reward-based check
    {
      uint32_t index = match->second;
      data[index].insert( list );
    }
  }

  uint32_t get_index( TT const& tt )
  {
    uint32_t index = tt_to_index[tt];
    return index;
  }

  entry_t const& at( uint32_t index ) const
  {
    entry_t const& entry = data[index];
    return entry;
  }

  entry_t const& operator[]( uint32_t index ) const
  {
    entry_t const & entry = data[index];
    return entry;
  }

  entry_t & operator[]( TT const& tt )
  {
    uint32_t const index = get_index( tt );
    return this->at(index);
  }

  auto find( TT const& tt )
  {
    return tt_to_index.find( tt );
  }

  auto end()
  {
    return tt_to_index.end();
  }

  /*! \brief iterator to apply a lambda to all the nodes */
  template<typename Fn>
  void foreach_entry( Fn&& fn ) const
  {
    for ( int i = 0; i < data.size(); i++ )
    {
      fn( data[i], i );
    }
  }

  private:
    std::vector<entry_t> data;
    phmap::flat_hash_map<TT, uint32_t, tt_hash> tt_to_index;
  };

} // namespace mockturtle