/* mockturtle: C++ logic network library
 * Copyright (C) 2018-2023  EPFL
 *
 * Permission is hereby granted, free of charge, to any person
 * obtaining a copy of this software and associated documentation
 * files (the "Software"), to deal in the Software without
 * restriction, including without limitation the rights to use,
 * copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following
 * conditions:
 *
 * The above copyright notice and this permission notice shall be
 * included in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
 * OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
 * HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
 * WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 */

/*!
  \file mapped_list.hpp
  \brief Index list for mapped networks

  \author Andrea Costamagna
*/

#pragma once

#include "../networks/bound.hpp"

#include <vector>

namespace mockturtle
{
  class mapped_list
  {
public:
    /* space reserved for constants */
    static constexpr uint32_t offset = 2;
    using element_type = uint32_t;

private:
    /*! \brief node of a mapped index list */
    struct node
    {
      /* the default constructor creates the null node */
      node()
        :  children({}), id(0)
      {}

      /* preferred construction from children and gate identifier */
      node( std::vector<element_type>const& children, unsigned int id )
        :  children( children ), id( id )
      {}

      /* cell identifier */
      unsigned int id;
      /* indices of the fanins */
      std::vector<element_type> children;
    };

public:
    mapped_list()
      :  num_vars( 0 ), area( 0 )
    {
    }

    mapped_list( uint32_t num_vars )
      :  num_vars( num_vars ), area( 0 )
    {
    }

    mapped_list( uint32_t num_vars, size_t size )
      :  num_vars( num_vars ), area( 0 )
    {
      nodes.reserve( size );
    }

    template<class Ntk, class Bindings_t>
    mapped_list( Ntk & ntk, Bindings_t const& lib, std::vector<typename Ntk::node> const& cut, typename Ntk::signal f )
      : num_vars( 0 ), area( 0 )
    {
      /* mark the cut nodes as visited */
      ntk.incr_trav_id();
      for( auto const& n : cut )
      {
        ntk.set_visited( n, ntk.trav_id() );
        auto fi = create_pi();
        ntk.set_value( n, fi );
      }
      /* recursively construct */
      construct_rec( ntk, f );
      /* compute the longest path of each input to output */
      compute_pin_delays( lib );
    }

    template<class Ntk, class Bindings_t, auto L>
    mapped_list( Ntk & ntk, Bindings_t const& lib, std::array<typename Ntk::node, L> const& cut, typename Ntk::signal f )
      : num_vars( 0 ), area( 0 )
    {
      /* mark the cut nodes as visited */
      ntk.incr_trav_id();
      for( auto const& n : cut )
      {
        ntk.set_visited( n, ntk.trav_id() );
        auto fi = create_pi();
        ntk.set_value( n, fi );
      }
      /* recursively construct */
      construct_rec( ntk, f );
      /* compute the longest path of each input to output */
      compute_pin_delays( lib );
    }

private:

    template<class Ntk>
    unsigned int get_area( Ntk const& ntk, typename Ntk::node n )
    {
      if constexpr ( std::is_same_v<typename Ntk::base_type, bound_network> )
      {
        return ntk.get_area( n );
      }
      else
      {
        auto const cell = ntk.get_cell( n );
        return cell.gates[0].area;
      }
    }
    
    template<class Ntk>
    unsigned int get_binding_id( Ntk const& ntk, typename Ntk::node n )
    {
      if constexpr ( std::is_same_v<typename Ntk::base_type, bound_network> )
      {
        return ntk.get_binding_id( n );
      }
      else
      {
        auto const cell = ntk.get_cell( n );
        return cell.gates[0].id;
      }
    }

    /*! \brief recursively construct the list 
     * This function assumes that some nodes in the TFI of f
     * are marked as visited ( visited flag = trav_id ) and
     * their value field is set to the element type in the index list
    */
    template<class Ntk>
    void construct_rec( Ntk & ntk, typename Ntk::signal f )
    {
      auto const n = ntk.get_node( f );
      /* termination conditions */
      if( ntk.visited( n ) == ntk.trav_id() )
      {
        return;
      }
      else if( ntk.is_pi( n ) ) // not marked as visited: illegal cone
      {
        std::cerr << "[e] list construction from ntk failed" << std::endl;
        return;
      }
      /* node construction */
      std::vector<element_type> children;
      
      area += get_area( ntk, n );
      auto const id = get_binding_id( ntk, n );
      bool is_valid = true;
      ntk.foreach_fanin( n, [&]( auto fi, auto ii ){
        auto const ni = ntk.get_node( fi );
        construct_rec( ntk, fi );
        children.emplace_back( ntk.value( ni ) );
      } );
      auto v = create_node( children, id );
      ntk.set_value( n, v );
      ntk.set_visited( n, ntk.trav_id() );
    }

    template<class Bindings_t>
    void compute_pin_delays( Bindings_t const& lib )
    {
      std::vector<double> delays( offset + num_pis() + num_gates(), 0 );
      uint32_t index = offset + num_pis() + num_gates() - 1;
      foreach_gate_rev( [&]( auto const& children, unsigned int id ){
        for( int i = 0; i < children.size(); ++i )
        {
          double const fall = lib[id].pins[i].fall_block_delay;
          double const rise = lib[id].pins[i].rise_block_delay;
          double const delta = std::max( rise, fall );
          delays[children[i]] = std::max( delays[children[i]], delays[index] + delta );
        }
        index--;
      } );
      pin_delays.clear();
      foreach_pi( [&]( auto lit ){
        pin_delays.emplace_back( delays[lit] );
      } );
    }

  public:
    element_type create_pi()
    {
      if( nodes.size() > 0 )
      {
        std::cerr << "[e] illegal PI construction in the presence of nodes" << std::endl;
        return std::numeric_limits<element_type>::max();
      }
      const element_type f{ num_vars + offset };
      num_vars++;
      return f;
    }

    /*! \brief create a node in the list 
     * the element_type is an unique identifier to reference an element of the list
    */
    element_type create_node( std::vector<element_type> const& children, unsigned int id )
    {
      const element_type f = nodes.size() + num_vars + offset;
      nodes.emplace_back( children, id );
      return f;
    }

    bool is_constant( element_type f ) const
    {
      return f < 2;
    }

    bool is_input( element_type f ) const
    {
      return ( ( f >= 2 ) && f < ( 2 + num_vars ) );
    }

    uint32_t node_to_index( element_type f ) const
    {
      return f - num_vars - offset;
    }

    element_type index_to_node( auto index ) const
    {
      return index + num_vars + offset;
    }

    uint32_t num_gates() const
    {
      return nodes.size();
    }

    uint32_t size() const
    {
      return nodes.size() + num_pis() + offset;
    }

    uint32_t num_pis() const
    {
      return num_vars;
    }

    /* perm are the input permutation received by the P-canonization */
    void permute_inputs( std::vector<uint8_t> const& perm )
    {
      std::vector<uint32_t> permutation( perm.size() );
      for( int i=0; i < perm.size(); ++i )
      {
        permutation[perm[i]] = i;
      }

      if( perm.size() != num_vars )
      {
        std::cerr << "[e] permutation vector does not match the number of variables" << std::endl;
      }
      int inode = 0;
      foreach_gate( [&]( auto children, auto id ){
        for( int ichild = 0; ichild < children.size(); ++ichild )
        {
          auto const child = children[ichild];
          if( ( child < ( num_vars + offset ) ) && ( child >= offset )  )
          {
            nodes[inode].children[ichild] = permutation[child-offset] + offset;
          }
        }
        inode++;
      } );

      auto const old_delays = pin_delays;
      foreach_pi( [&]( auto lit ){
        uint32_t index = lit - offset;
        pin_delays[index] = old_delays[perm[index]];
      } );
    }

    template<class Times, class Simm>
    void match_times( Times const& times, Simm simm )
    {
      if( times.size() != simm.size() )
      {
        std::cerr << "[e] times and simm have different sizes" << std::endl;
      }
      if( times.size() != num_vars )
      {
        std::cerr << "[e] times have wrong size" << std::endl;
      }

      std::vector<uint8_t> perm;
      for( uint8_t p = 0; p < num_vars; ++p )
      {
        perm.push_back( p );
      }

      for( uint8_t i{0}; i < num_vars; ++i )
      {
        std::vector<std::pair<uint8_t, double>> unsort_group;
        uint8_t simmetry = simm[i];
        for( uint8_t j{ 0 }; j < num_vars; ++j )
        {
          if( ( ( simmetry >> j ) & 0x1 ) == 0x1 )
            unsort_group.push_back( std::make_pair( j, times[j] ) );
        }
        std::vector<std::pair<uint8_t, double>> sorted_group = unsort_group;
        std::stable_sort( sorted_group.begin(), sorted_group.end(), [&]( auto a, auto b ){
          return a.second < b.second;
        } );
//        for( auto p : unsort_group )
//        {
//          uint32_t lit = static_cast<uint32_t>( p.first );
//          std::cout << "[" << lit << " " << p.second << "]";
//        }
//        std::cout << std::endl;

//        for( auto p : sorted_group )
//        {
//          uint32_t lit = static_cast<uint32_t>( p.first );
//          std::cout << "[" << lit << " " << p.second << "]";
//        }
//        std::cout << std::endl;

        permute_inputs( perm );
      }
    }


    /*! \brief iterator to apply a lambda to all the nodes */
    template<typename Fn>
    void foreach_pi( Fn&& fn ) const
    {
      for ( uint64_t i = 0; i < num_vars; ++i )
      {
        fn( static_cast<element_type>( offset + i ) );
      }
    }

    /*! \brief iterator to apply a lambda to all the nodes */
    template<typename Fn>
    void foreach_gate( Fn&& fn ) const
    {
      for ( uint64_t i = 0; i < nodes.size(); i ++ )
      {
        fn( nodes[i].children, nodes[i].id );
      }
    }

    /*! \brief iterator to apply a lambda to all the nodes */
    template<typename Fn>
    void foreach_gate_rev( Fn&& fn ) const
    {
      for ( int i = nodes.size()-1; i >= 0 ; --i )
      {
        fn( nodes[i].children, nodes[i].id );
      }
    }

    void print() const
    {
      std::cout << "L: [";
      int i = num_pis() + offset;
      for( auto t : pin_delays )
      {
        std::cout << t << " ";
      }
      std::cout << "] ";
      foreach_gate( [&]( auto children, auto id ){
        std::cout << i++ << "= " <<"{";
        for ( auto const& x : children )
        {
          std::cout << x << " ";
        }
        std::cout << "}." << id << " ";
      } );
      std::cout << std::endl;
    }

    template<class Ntk, class Leaves_t>
    typename Ntk::signal insert( Ntk& ntk, Leaves_t const& leaves ) const
    {
      using signal = typename Ntk::signal;
      using node = typename Ntk::node;

      if( leaves.size() != num_pis() )
      {
        std::cerr << "[e] cut-size inconsistent with the list's PIs" << std::endl;
      }
      std::vector<signal> sigs( num_pis() + num_gates() + offset );
      sigs[0] = ntk.get_constant( false );
      sigs[1] = ntk.get_constant( true );
      for( int i = 0; i < num_pis(); ++i )
      {
        sigs[offset+i] = ntk.make_signal( leaves[i] );
        //std::cout << "sig[" << offset + i << "]=" << sigs[offset+i] << std::endl;
      }
      int i = num_pis() + offset;
      foreach_gate( [&]( auto children, auto id ){
        std::vector<signal> fanin;
        for( auto c : children )
        {
          //std::cout << "sigs[" << c << "] = " << sigs[c] << " ";
          fanin.push_back( sigs[c] );
        }
        auto const g = ntk.get_binding_from_id( id );
        //std::cout << "{" << g.id << "}" << std::endl;
        sigs[i] = ntk.create_node( fanin, g.name )[0];
        //std::cout << "sigs[" << i << "] = " << sigs[i] << std::endl;
        i++;
      } );
      //std::cout << "return sigs[" << i-1 << "] = " << sigs[i-1] << std::endl;

      return sigs[i-1];
    }

    template<class Bindings_t>
    double get_area( Bindings_t const& binds ) const
    {
      double area = 0;
      foreach_gate( [&]( auto children, auto id ){
        area += binds[id].area;
      } );
      return area;
    }

    std::vector<double> get_pin_delays() const
    {
      return pin_delays;
    }

    /* store the nodes  */
    std::vector<node> nodes;
    std::vector<double> pin_delays;
    element_type num_vars;
    double area;
  };
} // namespace mockturtle